<?php

namespace App\Support;

use Throwable;

/**
 * Writes a copy of application errors directly to storage, independently of
 * Laravel's configured logging channel.
 */
final class LocalErrorLog
{
    private static ?string $activePath = null;

    public static function ensureFile(): ?string
    {
        if (self::$activePath !== null && is_file(self::$activePath)) {
            return self::$activePath;
        }

        $root = dirname(__DIR__, 2);
        // Avoid storage_path() here: Laravel's global helper depends on the
        // application container, which may not be fully booted yet.
        $primary = $root.DIRECTORY_SEPARATOR.'storage'.DIRECTORY_SEPARATOR.'logs'.DIRECTORY_SEPARATOR.'laravel.log';

        $candidates = [
            $primary,
            $root.DIRECTORY_SEPARATOR.'storage'.DIRECTORY_SEPARATOR.'app'.DIRECTORY_SEPARATOR.'private'.DIRECTORY_SEPARATOR.'laravel.log',
        ];

        foreach ($candidates as $path) {
            try {
                $directory = dirname($path);
                if (!is_dir($directory) && !@mkdir($directory, 0775, true) && !is_dir($directory)) {
                    continue;
                }

                $handle = @fopen($path, 'ab');
                if ($handle === false) {
                    continue;
                }

                fclose($handle);
                self::$activePath = $path;
                return $path;
            } catch (Throwable) {
                // Try the private storage fallback before resorting to PHP's host log.
            }
        }

        error_log('Laravel local error log could not be created in storage/logs or storage/app/private.');
        return null;
    }

    public static function record(Throwable $exception): void
    {
        $details = [
            'time' => date(DATE_ATOM),
            'type' => 'exception',
            'exception' => get_class($exception),
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'url' => self::requestUrl(),
            'method' => self::requestMethod(),
            'user_id' => self::userId(),
            'trace' => $exception->getTraceAsString(),
        ];

        self::append($details);
    }

    /** @param array<string, mixed> $error */
    public static function recordFatal(array $error): void
    {
        self::append([
            'time' => date(DATE_ATOM),
            'type' => 'fatal',
            'message' => (string) ($error['message'] ?? 'Unknown fatal error'),
            'file' => (string) ($error['file'] ?? ''),
            'line' => (int) ($error['line'] ?? 0),
            'error_type' => (int) ($error['type'] ?? 0),
            'url' => self::requestUrl(),
            'method' => self::requestMethod(),
        ]);
    }

    /** @param array<string, mixed> $details */
    private static function append(array $details): void
    {
        $path = self::ensureFile();
        $line = json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
        $line = ($line === false ? '{"message":"Could not encode error details"}' : $line).PHP_EOL;

        if ($path !== null && @file_put_contents($path, $line, FILE_APPEND | LOCK_EX) !== false) {
            return;
        }

        error_log(rtrim($line));
    }

    private static function requestUrl(): ?string
    {
        try {
            return function_exists('request') && app()->bound('request')
                ? request()->getPathInfo()
                : null;
        } catch (Throwable) {
            return null;
        }
    }

    private static function requestMethod(): ?string
    {
        try {
            return function_exists('request') && app()->bound('request')
                ? request()->method()
                : null;
        } catch (Throwable) {
            return null;
        }
    }

    private static function userId(): int|string|null
    {
        try {
            return function_exists('auth') && app()->bound('auth') ? auth()->id() : null;
        } catch (Throwable) {
            return null;
        }
    }
}
