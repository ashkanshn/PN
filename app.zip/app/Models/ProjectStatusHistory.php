<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectStatusHistory extends Model
{
    protected $table = 'project_status_history';
    public $timestamps = false;
    protected $fillable = ['project_id','from_status','to_status','note','changed_by','created_at'];
}
