<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    protected $fillable = ['ambassador_id','title','customer_name','customer_mobile','province','city','estimated_amount','stage','status','manager_note','form_values','submitted_at'];
    protected function casts(): array { return ['estimated_amount'=>'decimal:2','form_values'=>'array','submitted_at'=>'datetime']; }
    public function ambassador() { return $this->belongsTo(User::class, 'ambassador_id'); }
    public function history() { return $this->hasMany(ProjectStatusHistory::class); }
}
