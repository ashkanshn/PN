<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Point extends Model
{
    protected $fillable = ['ambassador_id','project_id','points','reason','source','created_by'];
    public function ambassador() { return $this->belongsTo(User::class, 'ambassador_id'); }
}
