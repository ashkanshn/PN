<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable, SoftDeletes;

    protected $fillable = [
        'name','first_name','last_name','email','password','role','status','mobile','national_id','province','city','address','postal_code','no_postal_code',
        'primary_segment','secondary_segments','supervisor_id','referrer_id','referral_code','national_id_hash','password_change_required','last_activity_at',
    ];
    protected $hidden = ['password','remember_token','national_id'];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'secondary_segments' => 'array',
            'password_change_required' => 'boolean',
            'last_activity_at' => 'datetime',
            'national_id' => 'encrypted',
            'no_postal_code' => 'boolean',
        ];
    }

    public function isAdmin(): bool { return $this->role === 'admin'; }
    public function projects() { return $this->hasMany(Project::class, 'ambassador_id'); }
    public function pointEntries() { return $this->hasMany(Point::class, 'ambassador_id'); }
    public function referrals() { return $this->hasMany(Referral::class, 'referrer_id'); }
}
