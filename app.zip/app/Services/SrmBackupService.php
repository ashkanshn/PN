<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class SrmBackupService
{
    private const TABLES = [
        'users','supervisors','projects','project_forms','project_form_fields','purchase_reports','purchase_documents',
        'project_status_history','points','rewards','redemptions','learning_contents','learning_progress','exams',
        'exam_attempts','pre_registration_exam_sessions','referrals','notices','notifications','sms_logs',
        'feedback_tickets','feedback_messages','media_files','project_media','ai_knowledge','ai_chat_history',
        'events','srm_settings','audit_logs',
    ];

    public function create(): string
    {
        $data = [];
        foreach (self::TABLES as $table) {
            $query = DB::table($table);
            if ($table === 'srm_settings') {
                $query->whereNotIn('key', ['backup_frequency', 'backup_last_at', 'backup_cron_token']);
            }
            $data[$table] = $query->get()->map(fn ($row) => (array) $row)->all();
        }

        $filename = 'peyvand-srm-backup-'.now()->format('Ymd-His').'-'.Str::lower(Str::random(6)).'.json';
        $path = 'backups/'.$filename;
        $json = json_encode([
            'version' => '1.0.14',
            'created_at' => now()->toIso8601String(),
            'data' => $data,
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE);

        abort_if($json === false || ! Storage::disk('local')->put($path, $json), 500, 'ذخیرهٔ فایل پشتیبان انجام نشد. پوشهٔ storage/app/private را بررسی کنید.');

        return $filename;
    }

    public function files(): array
    {
        $disk = Storage::disk('local');

        return collect($disk->files('backups'))
            ->filter(fn (string $path) => preg_match('/^backups\/peyvand-srm-backup-\d{8}-\d{6}-[a-z0-9]{6}\.json$/', $path) === 1)
            ->map(fn (string $path) => [
                'filename' => basename($path),
                'size' => $disk->size($path),
                'created_at' => $disk->lastModified($path),
            ])
            ->sortByDesc('created_at')
            ->values()
            ->all();
    }

    public function path(string $filename): string
    {
        $filename = basename($filename);
        abort_unless(preg_match('/^peyvand-srm-backup-\d{8}-\d{6}-[a-z0-9]{6}\.json$/', $filename) === 1, 404);

        $path = 'backups/'.$filename;
        abort_unless(Storage::disk('local')->exists($path), 404);

        return $path;
    }

    public function read(string $filename): array
    {
        $contents = Storage::disk('local')->get($this->path($filename));
        $backup = json_decode($contents, true);
        abort_unless(is_array($backup) && is_array($backup['data'] ?? null), 422, 'فایل پشتیبان معتبر نیست.');

        return $backup;
    }

    public function restore(array $backup): void
    {
        abort_unless(is_array($backup['data'] ?? null), 422, 'فایل پشتیبان معتبر نیست.');
        $scheduleSettings = DB::table('srm_settings')->whereIn('key', ['backup_frequency', 'backup_last_at', 'backup_cron_token'])->get()->map(fn ($row) => (array) $row)->all();

        DB::transaction(function () use ($backup, $scheduleSettings) {
            foreach (array_reverse(self::TABLES) as $table) {
                DB::table($table)->delete();
            }

            foreach (self::TABLES as $table) {
                $rows = $backup['data'][$table] ?? [];
                if ($table === 'srm_settings') {
                    $rows = array_merge($rows, $scheduleSettings);
                }
                foreach (array_chunk($rows, 100) as $chunk) {
                    $rows = array_map(fn ($row) => (array) $row, $chunk);
                    if ($rows) {
                        DB::table($table)->insert($rows);
                    }
                }
            }
        });
    }
}
