<?php

namespace App\Services;

class JalaliDate
{
    private const BREAKS = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];

    public static function isValid(string $value): bool
    {
        $digits = strtr($value, array_combine(
            preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY),
            str_split('01234567890123456789')
        ));
        if (preg_match('/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/', $digits, $matches) !== 1) {
            return false;
        }

        $year = (int) $matches[1];
        $month = (int) $matches[2];
        $day = (int) $matches[3];
        if ($year < 1300 || $year > 1500 || $month < 1 || $month > 12 || $day < 1) {
            return false;
        }
        if ($month <= 6) {
            return $day <= 31;
        }
        if ($month <= 11) {
            return $day <= 30;
        }

        return $day <= (self::calendar($year)['leap'] === 0 ? 30 : 29);
    }

    public static function toGregorianDate(string $value): ?string
    {
        $digits = strtr($value, array_combine(
            preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY),
            str_split('01234567890123456789')
        ));
        if (!self::isValid($digits) || preg_match('/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/', $digits, $m) !== 1) return null;
        $year=(int)$m[1]; $month=(int)$m[2]; $day=(int)$m[3]; $calendar=self::calendar($year);
        $offset=($month<=6?($month-1)*31:186+($month-7)*30)+$day-1;
        return (new \DateTimeImmutable(sprintf('%04d-%02d-%02d',$calendar['gy'],3,$calendar['march'])))->modify('+'.$offset.' days')->format('Y-m-d');
    }

    private static function calendar(int $year): array
    {
        $leapJ = -14;
        $jp = self::BREAKS[0];
        $jump = 0;
        foreach (array_slice(self::BREAKS, 1) as $jm) {
            $jump = $jm - $jp;
            if ($year < $jm) {
                break;
            }
            $leapJ += intdiv($jump, 33) * 8 + intdiv($jump % 33, 4);
            $jp = $jm;
        }

        $n = $year - $jp;
        $leapJ += intdiv($n, 33) * 8 + intdiv(($n % 33) + 3, 4);
        if (($jump % 33) === 4 && ($jump - $n) === 4) {
            $leapJ++;
        }
        $gy = $year + 621;
        $leapG = intdiv($gy, 4) - intdiv((intdiv($gy, 100) + 1) * 3, 4) - 150;
        if (($jump - $n) < 6) {
            $n = $n - $jump + intdiv($jump + 4, 33) * 33;
        }
        $leap = (($n + 1) % 33 - 1) % 4;
        if ($leap === -1) {
            $leap = 4;
        }

        return ['gy' => $gy, 'march' => 20 + $leapJ - $leapG, 'leap' => $leap];
    }
}
