<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;
use ZipArchive;

class SrmUpdateService
{
    private const MAX_FILES = 5000;
    private const MAX_FILE_BYTES = 20971520;
    private const MAX_UNPACKED_BYTES = 209715200;
    private const BATCH_SIZE = 20;

    public function stage(UploadedFile $upload): array
    {
        if (! class_exists(ZipArchive::class)) {
            throw new RuntimeException('افزونهٔ ZIP در PHP فعال نیست.');
        }

        $id = (string) Str::uuid();
        $work = $this->workPath($id);
        File::ensureDirectoryExists($work, 0750, true);
        $package = $work.DIRECTORY_SEPARATOR.'package.zip';

        if (! $upload->move($work, 'package.zip')) {
            File::deleteDirectory($work);
            throw new RuntimeException('ذخیرهٔ بستهٔ به‌روزرسانی انجام نشد.');
        }

        try {
            $zip = new ZipArchive();
            if ($zip->open($package) !== true) {
                throw new RuntimeException('فایل ZIP باز نشد یا ساختار آن معتبر نیست.');
            }

            $paths = [];
            $seen = [];
            $unpackedBytes = 0;
            for ($index = 0; $index < $zip->numFiles; $index++) {
                $entry = $zip->statIndex($index);
                $name = (string) ($entry['name'] ?? '');
                $this->assertSafeArchivePath($name);
                $mode = 0;
                $opsys = 0;
                $attributes = 0;
                if ($zip->getExternalAttributesIndex($index, $opsys, $attributes) && (($attributes >> 16) & 0170000) === 0120000) {
                    throw new RuntimeException('بسته شامل پیوند نمادین است و قابل نصب نیست.');
                }

                if (str_ends_with($name, '/')) {
                    continue;
                }
                if (isset($seen[$name])) {
                    throw new RuntimeException('نام فایل تکراری در بسته وجود دارد: '.$name);
                }
                $seen[$name] = true;
                if (! $this->isUpdatablePath($name)) {
                    continue;
                }
                $size = (int) ($entry['size'] ?? 0);
                if ($size < 0 || $size > self::MAX_FILE_BYTES) {
                    throw new RuntimeException('اندازهٔ یکی از فایل‌های بسته مجاز نیست.');
                }
                $unpackedBytes += $size;
                if (count($paths) >= self::MAX_FILES || $unpackedBytes > self::MAX_UNPACKED_BYTES) {
                    throw new RuntimeException('تعداد یا حجم فایل‌های قابل به‌روزرسانی بیش از حد مجاز است.');
                }
                $paths[] = $name;
            }
            $zip->close();

            if ($paths === []) {
                throw new RuntimeException('در بسته فایل قابل به‌روزرسانی پیدا نشد. ZIP باید فایل‌های برنامه را مستقیماً در ریشه داشته باشد.');
            }

            $state = [
                'id' => $id,
                'status' => 'ready',
                'paths' => $paths,
                'next' => 0,
                'originals' => [],
                'created_at' => now()->toIso8601String(),
                'message' => 'بسته بررسی شد و آمادهٔ نصب است.',
            ];
            $this->writeState($id, $state);

            return ['id' => $id, 'total' => count($paths), 'status' => $state['status'], 'message' => $state['message']];
        } catch (Throwable $error) {
            File::deleteDirectory($work);
            throw $error;
        }
    }

    public function advance(string $id): array
    {
        abort_unless(preg_match('/^[0-9a-f-]{36}$/i', $id) === 1 && is_dir($this->workPath($id)), 404);
        $lock = fopen($this->workPath($id).DIRECTORY_SEPARATOR.'lock', 'c');
        if ($lock === false) {
            throw new RuntimeException('قفل اجرای به‌روزرسانی ایجاد نشد.');
        }
        try {
            if (! flock($lock, LOCK_EX)) {
                throw new RuntimeException('قفل اجرای به‌روزرسانی دریافت نشد.');
            }
            return $this->advanceLocked($id);
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    private function advanceLocked(string $id): array
    {
        $state = $this->readState($id);
        if ($state['status'] === 'complete' || $state['status'] === 'failed') {
            return $this->publicState($state);
        }

        try {
            $state['status'] = 'applying';
            $zip = new ZipArchive();
            $package = $this->workPath($id).DIRECTORY_SEPARATOR.'package.zip';
            if ($zip->open($package) !== true) {
                throw new RuntimeException('خواندن بستهٔ به‌روزرسانی ممکن نیست.');
            }

            $batch = array_slice($state['paths'], (int) $state['next'], self::BATCH_SIZE);
            $backupRoot = $this->workPath($id).DIRECTORY_SEPARATOR.'originals';
            foreach ($batch as $relative) {
                if (! array_key_exists($relative, $state['originals'])) {
                    $target = $this->targetPath($relative);
                    $this->assertNoSymlinkParents($target);
                    $exists = is_file($target);
                    $state['originals'][$relative] = ['exists' => $exists];
                    if ($exists) {
                        $backup = $backupRoot.DIRECTORY_SEPARATOR.str_replace('/', DIRECTORY_SEPARATOR, $relative);
                        File::ensureDirectoryExists(dirname($backup), 0750, true);
                        if (! copy($target, $backup)) {
                            throw new RuntimeException('تهیهٔ نسخهٔ بازگشت برای یکی از فایل‌ها انجام نشد.');
                        }
                    }
                }
            }
            // Persist originals before writing any package file so an interrupted request can safely resume.
            $this->writeState($id, $state);

            foreach ($batch as $relative) {
                $stream = $zip->getStream($relative);
                if ($stream === false) {
                    throw new RuntimeException('خواندن فایل از بسته ناموفق بود: '.$relative);
                }
                $contents = stream_get_contents($stream, self::MAX_FILE_BYTES + 1);
                fclose($stream);
                if ($contents === false || strlen($contents) > self::MAX_FILE_BYTES) {
                    throw new RuntimeException('اندازهٔ فایل بازشده از حد مجاز بیشتر است: '.$relative);
                }
                $target = $this->targetPath($relative);
                $this->assertNoSymlinkParents($target);
                File::ensureDirectoryExists(dirname($target), 0755, true);
                $temporary = $target.'.update-'.Str::random(10);
                if (file_put_contents($temporary, $contents, LOCK_EX) === false || ! rename($temporary, $target)) {
                    @unlink($temporary);
                    throw new RuntimeException('جایگزینی فایل ناموفق بود: '.$relative);
                }
            }
            $zip->close();

            $state['next'] = (int) $state['next'] + count($batch);
            if ($state['next'] >= count($state['paths'])) {
                $state['status'] = 'finalizing';
                $state['message'] = 'فایل‌ها جایگزین شدند؛ پاک‌سازی cache سامانه در حال انجام است.';
                $this->writeState($id, $state);
                $this->clearCodeCaches();
                $state['status'] = 'complete';
                $state['message'] = 'به‌روزرسانی با موفقیت انجام شد. اطلاعات و فایل‌های کاربران حفظ شدند.';
                $this->writeState($id, $state);
                File::deleteDirectory($this->workPath($id).DIRECTORY_SEPARATOR.'originals');
                @unlink($package);
            } else {
                $state['message'] = 'در حال جایگزینی فایل‌های برنامه.';
                $this->writeState($id, $state);
            }

            return $this->publicState($state);
        } catch (Throwable $error) {
            if (isset($zip) && $zip instanceof ZipArchive) {
                @$zip->close();
            }
            $state = $this->rollback($id, $state, $error);
            return $this->publicState($state);
        }
    }

    private function rollback(string $id, array $state, Throwable $cause): array
    {
        $backupRoot = $this->workPath($id).DIRECTORY_SEPARATOR.'originals';
        $errors = [];
        foreach (array_reverse($state['paths']) as $relative) {
            if (! array_key_exists($relative, $state['originals'] ?? [])) {
                continue;
            }
            try {
                $target = $this->targetPath($relative);
                $this->assertNoSymlinkParents($target);
                if ($state['originals'][$relative]['exists']) {
                    $backup = $backupRoot.DIRECTORY_SEPARATOR.str_replace('/', DIRECTORY_SEPARATOR, $relative);
                    if (! is_file($backup)) {
                        throw new RuntimeException('نسخهٔ اصلی فایل پیدا نشد: '.$relative);
                    }
                    File::ensureDirectoryExists(dirname($target), 0755, true);
                    $temporary = $target.'.rollback-'.Str::random(10);
                    if (! copy($backup, $temporary) || ! rename($temporary, $target)) {
                        @unlink($temporary);
                        throw new RuntimeException('بازگردانی فایل ناموفق بود: '.$relative);
                    }
                } elseif (is_file($target)) {
                    @unlink($target);
                }
            } catch (Throwable $rollbackError) {
                $errors[] = $rollbackError->getMessage();
            }
        }

        try {
            $this->clearCodeCaches();
        } catch (Throwable $cacheError) {
            $errors[] = 'پاک‌سازی cache: '.$cacheError->getMessage();
        }

        $state['status'] = 'failed';
        $state['message'] = $errors === []
            ? 'به‌روزرسانی ناموفق بود؛ فایل‌های سامانه به وضعیت پیش از اجرا بازگشتند. علت: '.$cause->getMessage()
            : 'به‌روزرسانی و بازگشت خودکار با خطا روبه‌رو شدند. نسخه‌های اصلی در فضای خصوصی updates نگهداری شده‌اند. علت: '.$cause->getMessage().' | '.implode(' | ', $errors);
        $this->writeState($id, $state);

        return $state;
    }

    private function publicState(array $state): array
    {
        $total = count($state['paths'] ?? []);
        return [
            'id' => $state['id'],
            'status' => $state['status'],
            'total' => $total,
            'completed' => min((int) ($state['next'] ?? 0), $total),
            'percent' => $total === 0 ? 0 : (int) floor(min((int) ($state['next'] ?? 0), $total) * 100 / $total),
            'message' => $state['message'] ?? '',
        ];
    }

    private function clearCodeCaches(): void
    {
        foreach (['config:clear', 'route:clear', 'view:clear', 'event:clear'] as $command) {
            Artisan::call($command);
        }
    }

    private function readState(string $id): array
    {
        abort_unless(preg_match('/^[0-9a-f-]{36}$/i', $id) === 1, 404);
        $path = $this->workPath($id).DIRECTORY_SEPARATOR.'state.json';
        abort_unless(is_file($path), 404);
        $state = json_decode((string) file_get_contents($path), true);
        abort_unless(is_array($state) && ($state['id'] ?? null) === $id && is_array($state['paths'] ?? null), 404);
        return $state;
    }

    private function writeState(string $id, array $state): void
    {
        $path = $this->workPath($id).DIRECTORY_SEPARATOR.'state.json';
        $temporary = $path.'.tmp';
        if (file_put_contents($temporary, json_encode($state, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), LOCK_EX) === false || ! rename($temporary, $path)) {
            @unlink($temporary);
            throw new RuntimeException('ذخیرهٔ وضعیت به‌روزرسانی انجام نشد.');
        }
    }

    private function assertSafeArchivePath(string $path): void
    {
        if ($path === '' || str_contains($path, "\\") || str_starts_with($path, '/') || preg_match('/^[a-zA-Z]:/', $path) || preg_match('~(^|/)\.\.?(/|$)~', $path) || str_contains($path, "\0")) {
            throw new RuntimeException('بسته شامل مسیر فایل نامعتبر است.');
        }
    }

    private function isUpdatablePath(string $path): bool
    {
        if (preg_match('~^(app|config|resources|routes)/.+$~', $path)) {
            return true;
        }
        if (preg_match('~^bootstrap/(app|providers)\.php$~', $path)) {
            return true;
        }
        if ($path === 'index.php' || $path === 'public/index.php') {
            return true;
        }
        return str_starts_with($path, 'public/')
            && ! str_starts_with($path, 'public/storage/')
            && ! preg_match('~^public/.*\.php$~i', $path)
            && ! str_starts_with($path, 'public/.');
    }

    private function targetPath(string $relative): string
    {
        $base = base_path();
        return $base.DIRECTORY_SEPARATOR.str_replace('/', DIRECTORY_SEPARATOR, $relative);
    }

    private function assertNoSymlinkParents(string $target): void
    {
        $base = rtrim(base_path(), DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR;
        abort_unless(str_starts_with($target, $base), 422, 'مسیر فایل خارج از ریشهٔ برنامه است.');
        $relative = substr($target, strlen($base));
        $parts = explode(DIRECTORY_SEPARATOR, $relative);
        $current = rtrim(base_path(), DIRECTORY_SEPARATOR);
        foreach ($parts as $part) {
            $current .= DIRECTORY_SEPARATOR.$part;
            if (is_link($current)) {
                throw new RuntimeException('مسیر فایل شامل پیوند نمادین است و امن نیست.');
            }
        }
    }

    private function workPath(string $id): string
    {
        return storage_path('app/private/updates/'.$id);
    }
}
