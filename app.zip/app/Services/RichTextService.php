<?php

namespace App\Services;

use DOMDocument;
use DOMElement;
use DOMNode;

class RichTextService
{
    private const ALLOWED = ['p','br','strong','b','em','i','u','ul','ol','li','h2','h3','h4','blockquote','a','span','div','hr','pre','code','sub','sup','table','thead','tbody','tfoot','tr','th','td'];
    private const DROP_CONTENT = ['script','style','iframe','object','embed','svg','math','form','input','button','textarea','select'];

    public function sanitize(string $html): string
    {
        if (trim($html) === '') return '';
        $previous = libxml_use_internal_errors(true);
        $document = new DOMDocument('1.0', 'UTF-8');
        $document->loadHTML('<?xml encoding="UTF-8"><div id="rich-text-root">'.$html.'</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        $root = null;
        foreach ($document->getElementsByTagName('div') as $candidate) {
            if ($candidate->getAttribute('id') === 'rich-text-root') { $root = $candidate; break; }
        }
        if (!$root) return '';
        $this->cleanChildren($root);
        $result = '';
        foreach ($root->childNodes as $child) $result .= $document->saveHTML($child);
        return $result;
    }

    private function cleanChildren(DOMNode $parent): void
    {
        foreach (iterator_to_array($parent->childNodes) as $child) {
            if ($child instanceof DOMElement) {
                $tag = strtolower($child->tagName);
                if (in_array($tag, self::DROP_CONTENT, true)) { $parent->removeChild($child); continue; }
                $this->cleanChildren($child);
                if (!in_array($tag, self::ALLOWED, true)) {
                    while ($child->firstChild) $parent->insertBefore($child->firstChild, $child);
                    $parent->removeChild($child);
                    continue;
                }
                $href = $tag === 'a' ? trim($child->getAttribute('href')) : '';
                $style = in_array($tag, ['span','div'], true) ? $this->safeStyle($child->getAttribute('style')) : '';
                while ($child->attributes->length) $child->removeAttributeNode($child->attributes->item(0));
                if ($tag === 'a' && $this->safeHref($href)) {
                    $child->setAttribute('href', $href);
                    $child->setAttribute('rel', 'nofollow noopener noreferrer');
                }
                if ($style !== '') $child->setAttribute('style', $style);
            } elseif ($child->nodeType !== XML_TEXT_NODE) {
                $parent->removeChild($child);
            }
        }
    }

    private function safeHref(string $href): bool
    {
        if ($href === '') return false;
        if (str_starts_with($href, '/') || str_starts_with($href, '#')) return true;
        return in_array(strtolower((string)parse_url($href, PHP_URL_SCHEME)), ['http','https','mailto','tel'], true);
    }

    private function safeStyle(string $style): string
    {
        $safe = [];
        foreach (explode(';', $style) as $declaration) {
            if (! str_contains($declaration, ':')) continue;
            [$property, $value] = array_map('trim', explode(':', $declaration, 2));
            $property = strtolower($property);
            $value = strtolower($value);
            if (in_array($property, ['color','background-color'], true)
                && preg_match('/^(#[0-9a-f]{3,8}|[a-z]{1,20}|rgba?\([0-9.,%\s]+\))$/i', $value)) {
                $safe[$property] = $value;
            } elseif ($property === 'text-align' && in_array($value, ['left','right','center','justify'], true)) {
                $safe[$property] = $value;
            } elseif ($property === 'font-weight' && in_array($value, ['bold','normal','400','500','600','700','800','900'], true)) {
                $safe[$property] = $value;
            } elseif ($property === 'font-style' && in_array($value, ['italic','normal'], true)) {
                $safe[$property] = $value;
            } elseif ($property === 'text-decoration' && in_array($value, ['underline','line-through','none'], true)) {
                $safe[$property] = $value;
            } elseif ($property === 'font-family' && preg_match('/^(tahoma|arial|georgia|courier new|times new roman|sans-serif|serif|monospace)(\s*,\s*(tahoma|arial|georgia|courier new|times new roman|sans-serif|serif|monospace))*$/i', $value)) {
                $safe[$property] = $value;
            } elseif ($property === 'font-size' && preg_match('/^(\d{1,2})(px|pt)$/', $value, $size) && (int) $size[1] >= 8 && (int) $size[1] <= 72) {
                $safe[$property] = $value;
            } elseif ($property === 'direction' && in_array($value, ['ltr','rtl'], true)) {
                $safe[$property] = $value;
            }
        }
        $output = [];
        foreach ($safe as $property => $value) $output[] = $property.': '.$value;
        return implode('; ', $output);
    }
}
