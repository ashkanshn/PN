<?php

namespace App\Services;

use App\Http\Controllers\SrmController;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class VisibilityService
{
    public function matches(?array $targets,User $user): bool
    {
        if(!$targets||in_array('all',$targets,true))return true;
        $groups=['ambassador'=>[],'rank'=>[],'province'=>[],'city'=>[],'segment'=>[],'supervisor'=>[],'activity'=>[]];
        foreach($targets as $target){[$type,$value]=array_pad(explode(':',(string)$target,2),2,'');if(isset($groups[$type]))$groups[$type][]=$value;}
        foreach($groups as $type=>$values){if(!$values)continue;
            $ok=match($type){
                'ambassador'=>in_array((string)$user->id,$values,true),
                'province'=>in_array((string)$user->province,$values,true),
                'city'=>in_array((string)$user->province.'|'.(string)$user->city,$values,true),
                'segment'=>count(array_intersect(array_filter(array_merge([$user->primary_segment],$user->secondary_segments??[])),$values))>0,
                'supervisor'=>in_array((string)$user->supervisor_id,$values,true),
                'rank'=>in_array((string)$this->rank($user),$values,true),
                'activity'=>in_array($this->activity($user),$values,true),
                default=>true,
            };
            if(!$ok)return false;
        }
        return true;
    }
    private function rank(User $user): int
    {
        $query=DB::table('points')->leftJoin('projects','projects.id','=','points.project_id')->where('points.ambassador_id',$user->id)->where(function($q){$q->where('points.source','!=','activity')->orWhereNull('points.project_id')->orWhere('points.reason','not like','ثبت پروژه (%')->orWhereNull('projects.id')->orWhereIn('projects.status',['approved','active','completed']);if(Schema::hasTable('project_status_history'))$q->orWhereExists(function($history){$history->selectRaw('1')->from('project_status_history')->whereColumn('project_status_history.project_id','points.project_id')->whereIn('project_status_history.to_status',['approved','active','completed']);});});$points=(int)$query->sum('points.points');$ranks=json_decode((string)SrmController::setting('ranks','[]'),true)?:[];usort($ranks,fn($a,$b)=>(int)($a['min']??$a['from']??0)<=>(int)($b['min']??$b['from']??0));
        foreach($ranks as $i=>$r){$min=(int)($r['min']??$r['from']??0);$max=isset($r['max'])&&$r['max']!==''?(int)$r['max']:(isset($r['to'])&&$r['to']!==''?(int)$r['to']:null);if($points>=$min&&($max===null||$points<=$max))return (int)$i;}return -1;
    }
    private function activity(User $user): string
    {
        $last=DB::table('projects')->where('ambassador_id',$user->id)->whereIn('status',['approved','active','completed'])->latest('updated_at')->value('updated_at');
        $months=$last?now()->diffInMonths($last):now()->diffInMonths($user->created_at);
        if($months>=(int)SrmController::setting('inactive_months','6'))return 'inactive';if($months>=(int)SrmController::setting('low_activity_months','3'))return 'low';return 'active';
    }
}
