<?php

namespace App\Services;

use App\Http\Controllers\SrmController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class SmsService
{
    public function send(?int $ambassadorId,string $phone,string $message,string $event='manual'): array
    {
        $provider=(string)SrmController::setting('sms_provider','kavenegar');$api=(string)SrmController::setting('sms_api_key','');$sender=(string)SrmController::setting('sms_line_number','');$result=['ok'=>false,'id'=>null,'error'=>'درگاه پیامک تنظیم نشده است'];
        try {
            if($provider==='kavenegar'){$r=Http::timeout(20)->asForm()->post('https://api.kavenegar.com/v1/'.rawurlencode($api).'/sms/send.json',['receptor'=>$phone,'sender'=>$sender,'message'=>$message]);$j=$r->json();$result=['ok'=>$r->successful()&&(int)data_get($j,'return.status')>=200,'id'=>(string)data_get($j,'entries.0.messageid',''),'error'=>(string)data_get($j,'return.message','')];}
            elseif($provider==='smsir'){$r=Http::timeout(20)->withHeaders(['X-API-KEY'=>$api])->post('https://api.sms.ir/v1/send/bulk',['lineNumber'=>$sender,'MessageText'=>$message,'Mobiles'=>[$phone]]);$j=$r->json();$result=['ok'=>$r->successful()&&(int)data_get($j,'status')===1,'id'=>(string)data_get($j,'data',''),'error'=>(string)data_get($j,'message','')];}
            elseif(in_array($provider,['ippanel','farazsms'],true)){$r=Http::timeout(20)->withHeader('Authorization',$api)->post('https://edge.ippanel.com/v1/api/send',['sending_type'=>'webservice','from_number'=>$sender,'message'=>$message,'params'=>['recipients'=>[$phone]]]);$j=$r->json();$result=['ok'=>$r->successful()&&(bool)data_get($j,'meta.status'),'id'=>(string)data_get($j,'data.0'),'error'=>(string)data_get($j,'meta.message','')];}
            elseif($provider==='melipayamak'){$user=(string)SrmController::setting('sms_username','');$pass=(string)SrmController::setting('sms_password','');$r=Http::timeout(20)->asForm()->post('https://rest.payamak-panel.com/api/SendSMS/SendSMS',['username'=>$user,'password'=>$pass,'to'=>$phone,'from'=>$sender,'text'=>$message,'isFlash'=>false]);$id=trim($r->body());$result=['ok'=>$r->successful()&&is_numeric($id)&&(int)$id>0,'id'=>$id,'error'=>is_numeric($id)?'':'پاسخ نامعتبر سرویس'];}
            elseif($provider==='ghasedak'){$r=Http::timeout(20)->withHeaders(['apikey'=>$api,'Accept'=>'application/json'])->asForm()->post('https://api.ghasedak.me/v2/sms/send/simple',['message'=>$message,'receptor'=>$phone,'lineNumber'=>$sender]);$j=$r->json();$mid=(string)(data_get($j,'id')??data_get($j,'data.0.id')??'');$result=['ok'=>$r->successful()&&($mid!==''||(int)data_get($j,'result.code')===200),'id'=>$mid,'error'=>(string)data_get($j,'message','')];}
            elseif($provider==='first_portal'||$provider==='firstportal'){$user=(string)SrmController::setting('sms_username','');$pass=(string)SrmController::setting('sms_password','');$r=Http::timeout(20)->asForm()->post('https://service.1st.ir/UserServices/Sms/HttpService.ashx',['method'=>'send','username'=>$user,'password'=>$pass,'lineNumber'=>$sender,'to'=>$phone,'message'=>$message]);$body=trim($r->body());$result=['ok'=>$r->successful()&&preg_match('/^\d+$/',$body)===1&&(int)$body>=1000,'id'=>$body,'error'=>$r->successful()?'':'ارسال پیامک ناموفق بود'];}
            elseif($provider==='parsgreen'){$result=['ok'=>false,'id'=>null,'error'=>'برای پارس‌گرین، افزونه PHP SOAP باید فعال باشد.'];}
            else{$result=['ok'=>false,'id'=>null,'error'=>'ارائه‌دهندهٔ پیامک انتخاب‌شده پشتیبانی نمی‌شود.'];}
        } catch(\Throwable $e) { $result=['ok'=>false,'id'=>null,'error'=>$e->getMessage()]; }
        DB::table('sms_logs')->insert(['ambassador_id'=>$ambassadorId,'provider'=>$provider,'recipient'=>$phone,'event_key'=>$event,'message'=>$message,'status'=>$result['ok']?'sent':'failed','provider_message_id'=>$result['id'],'error'=>$result['error'],'created_at'=>now(),'updated_at'=>now()]);
        return $result;
    }
}
