<?php

namespace App\Services;

use App\Http\Controllers\SrmController;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class NotificationService
{
    public function ambassador(int $id,string $event,string $message,array $context=[]): void
    {
        $user=User::find($id);if(!$user)return;
        DB::table('notifications')->insert(['ambassador_id'=>$id,'channel'=>'in_app','event_key'=>$event,'recipient'=>$user->email,'message'=>$message,'created_at'=>now(),'updated_at'=>now()]);
        if(!filter_var(SrmController::setting('sms_enabled','0'),FILTER_VALIDATE_BOOLEAN)||!$user->mobile)return;
        $template=(string)SrmController::setting('sms_template_'.$event,'');if($template==='')return;
        foreach(['first_name'=>$user->first_name,'last_name'=>$user->last_name,'name'=>$user->name]+$context as $key=>$value)$template=str_replace('{'.$key.'}',(string)$value,$template);
        app(SmsService::class)->send($id,$user->mobile,$template,$event);
    }
    public function admins(string $event,string $message): void
    {
        $admins=User::where('role','admin')->pluck('id');
        foreach($admins as $id)DB::table('notifications')->insert(['ambassador_id'=>null,'channel'=>'in_app','event_key'=>$event,'recipient'=>'admin:'.$id,'message'=>$message,'created_at'=>now(),'updated_at'=>now()]);
    }

    public function activity(string $event,string $message,?int $actorId=null): void
    {
        $message=trim($message);
        if($message==='')$message='رویداد تازه‌ای در سامانه ثبت شد: '.$event;
        $this->admins($event,mb_substr($message,0,1000));
    }

    public function activityLabel(string $event): string
    {
        $labels=[
            'ambassador.registered'=>'ثبت‌نام نماینده','project.submitted'=>'ثبت پروژه','project.updated'=>'ویرایش و ارسال دوبارهٔ پروژه',
            'purchase_report.submitted'=>'ثبت گزارش خرید یا فروش','profile.updated'=>'به‌روزرسانی پروفایل','referral.invited'=>'ثبت دعوت همکاری',
            'feedback.created'=>'ثبت پیام پشتیبانی','supervisor.report.created'=>'ارسال گزارش سرپرست','supervisor.report.viewed'=>'مشاهدهٔ گزارش تیم',
            'supervisor.report.csv_exported'=>'دریافت خروجی CSV گزارش','supervisor.report.pdf_exported'=>'دریافت خروجی PDF گزارش',
            'learning.completed'=>'تکمیل آموزش','exam.submitted'=>'ثبت پاسخ آزمون','admin.module_saved'=>'ذخیرهٔ اطلاعات سامانه',
            'admin.module_deleted'=>'حذف اطلاعات سامانه','admin.media.uploaded'=>'بارگذاری رسانه','settings.updated'=>'به‌روزرسانی تنظیمات سامانه',
        ];
        return $labels[$event]??str_replace(['.','_'],[' / ',' '],$event);
    }
}
