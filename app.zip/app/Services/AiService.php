<?php

namespace App\Services;

use App\Http\Controllers\SrmController;
use Illuminate\Support\Facades\DB;

class AiService
{
    public function reply(int $userId,string $question): string
    {
        abort_unless(filter_var(SrmController::setting('ai_enabled','0'),FILTER_VALIDATE_BOOLEAN),503,'دستیار هوشمند غیرفعال است.');
        $daily=(int)DB::table('ai_chat_history')->where('ambassador_id',$userId)->whereDate('chat_date',today())->count();$limit=max(1,(int)SrmController::setting('ai_daily_limit','30'));abort_if($daily >= $limit,429,'سهمیه روزانه پرسش شما تمام شده است.');
        $api=(string)SrmController::setting('ai_api_key','');$model=(string)SrmController::setting('ai_model','');abort_if(!$api||!$model,503,'اتصال HeroAI.ir کامل پیکربندی نشده است.');
        $knowledge=DB::table('ai_knowledge')->where('is_published',true)->orderByDesc('id')->limit(100)->get(['title','body'])->map(fn($r)=>$r->title."\n".html_entity_decode(strip_tags($r->body),ENT_QUOTES|ENT_HTML5,'UTF-8'))->implode("\n---\n");
        $system=(string)SrmController::setting('ai_knowledge_notes','به فارسی و براساس دانش مرجع پاسخ بده. اگر پاسخ در مرجع نیست، شفاف بگو اطلاعات کافی در دسترس نیست.')."\n\nدانش مرجع:\n".$knowledge;
        $history=DB::table('ai_chat_history')->where('ambassador_id',$userId)->latest()->limit(8)->get()->reverse();$messages=[['role'=>'system','content'=>$system]];foreach($history as $item)foreach((json_decode($item->messages,true)?:[]) as $message)$messages[]=['role'=>$message['role']??'user','content'=>$message['content']??''];$messages[]=['role'=>'user','content'=>$question];
        $payload=['model'=>$model,'messages'=>$messages,'max_tokens'=>(int)SrmController::setting('ai_max_output_tokens','1024')];
        $timeout=max(5,min(120,(int)SrmController::setting('ai_timeout','30')));[$status,$responseBody]=$this->postJson('https://api.heroai.ir/ai/chat/completions',$payload,$api,$timeout);$response=json_decode($responseBody,true);if(!is_array($response))throw new \RuntimeException('پاسخ سرویس AI معتبر نیست.');$apiError=(string)($response['message']??$response['error']['message']??'');if($status<200||$status>=300)throw new \RuntimeException('سرویس AI پاسخ موفق نداد: '.$status.($apiError!==''?' · '.$apiError:''));
        $answer=(string)($response['choices'][0]['message']['content']??$response['output_text']??$response['output'][0]['content'][0]['text']??'پاسخ خالی از سرویس دریافت شد.');
        DB::table('ai_chat_history')->insert(['ambassador_id'=>$userId,'messages'=>json_encode([['role'=>'user','content'=>$question],['role'=>'assistant','content'=>$answer]],JSON_UNESCAPED_UNICODE),'tokens_used'=>(int)($response['usage']['total_tokens']??0),'chat_date'=>today(),'created_at'=>now(),'updated_at'=>now()]);
        return $answer;
    }

    private function postJson(string $url,array $payload,string $token,int $timeout): array
    {
        $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if($json===false)throw new \RuntimeException('ساخت درخواست هوش مصنوعی ناموفق بود.');$headers=['Content-Type: application/json','Accept: application/json','Authorization: Bearer '.$token];
        if(function_exists('curl_init')){$handle=curl_init($url);curl_setopt_array($handle,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_POSTFIELDS=>$json,CURLOPT_TIMEOUT=>$timeout,CURLOPT_CONNECTTIMEOUT=>min(15,$timeout),CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);$body=curl_exec($handle);$status=(int)curl_getinfo($handle,CURLINFO_RESPONSE_CODE);$error=curl_error($handle);curl_close($handle);if($body===false)throw new \RuntimeException('ارتباط با سرویس هوش مصنوعی برقرار نشد: '.$error);return [$status,(string)$body];}
        $headerText=implode("\r\n",$headers)."\r\nConnection: close\r\n";$context=stream_context_create(['http'=>['method'=>'POST','header'=>$headerText,'content'=>$json,'timeout'=>$timeout,'ignore_errors'=>true,'protocol_version'=>1.1],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);$body=@file_get_contents($url,false,$context);$status=0;foreach($http_response_header??[] as $header)if(preg_match('/^HTTP\/\S+\s+(\d{3})/i',$header,$match))$status=(int)$match[1];if($body===false)throw new \RuntimeException('ارتباط با سرویس هوش مصنوعی برقرار نشد. تنظیمات شبکه و دسترسی HTTPS هاست را بررسی کنید.');return [$status,(string)$body];
    }
}
