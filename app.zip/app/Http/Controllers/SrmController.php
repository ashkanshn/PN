<?php

namespace App\Http\Controllers;

use App\Models\Point;
use App\Models\Project;
use App\Models\ProjectStatusHistory;
use App\Models\Referral;
use App\Models\User;
use App\Services\AiService;
use App\Services\SrmBackupService;
use App\Services\SrmUpdateService;
use App\Services\JalaliDate;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;

class SrmController extends Controller
{
    private const MODULES = [
        'ambassadors'=>['title'=>'نمایندگان فروش','table'=>'users','user'=>true,'fields'=>['first_name'=>'نام','last_name'=>'نام خانوادگی','email'=>'ایمیل','mobile'=>'موبایل','province'=>'استان','city'=>'شهر','address'=>'نشانی','postal_code'=>'کدپستی','primary_segment'=>'زمینه فعالیت','supervisor_id'=>'سرپرست','status'=>'وضعیت']],
        'supervisors'=>['title'=>'سرپرستان','table'=>'supervisors','fields'=>['name'=>'نام','email'=>'ایمیل','mobile'=>'موبایل','provinces'=>'استان‌ها (JSON)','status'=>'وضعیت']],
        'projects'=>['title'=>'پروژه‌ها','table'=>'projects','fields'=>['ambassador_id'=>'نماینده','title'=>'عنوان پروژه','customer_name'=>'نام مشتری','customer_mobile'=>'موبایل مشتری','province'=>'استان','city'=>'شهر','estimated_amount'=>'مبلغ برآوردی','stage'=>'مرحله','status'=>'وضعیت','manager_note'=>'یادداشت مدیر']],
        'purchase-reports'=>['title'=>'گزارش خرید','table'=>'purchase_reports','fields'=>['project_id'=>'پروژه','ambassador_id'=>'نماینده','note'=>'شرح','review_note'=>'یادداشت بررسی','status'=>'وضعیت']],
        'purchase-documents'=>['title'=>'اسناد گزارش خرید','table'=>'purchase_documents','fields'=>['report_id'=>'گزارش','project_id'=>'پروژه','ambassador_id'=>'نماینده','original_name'=>'نام فایل','mime_type'=>'نوع','file_size'=>'حجم']],
        'points'=>['title'=>'دفتر امتیاز','table'=>'points','fields'=>['ambassador_id'=>'نماینده','project_id'=>'پروژه','points'=>'امتیاز (+/-)','reason'=>'علت','source'=>'منبع']],
        'rewards'=>['title'=>'جوایز','table'=>'rewards','fields'=>['title'=>'عنوان','description'=>'توضیحات','points_required'=>'امتیاز لازم','stock'=>'موجودی','segments'=>'زمینه‌های مجاز (JSON)','status'=>'وضعیت']],
        'redemptions'=>['title'=>'درخواست جوایز','table'=>'redemptions','fields'=>['ambassador_id'=>'نماینده','reward_id'=>'جایزه','points_spent'=>'امتیاز','status'=>'وضعیت','review_note'=>'یادداشت بررسی']],
        'learning'=>['title'=>'آموزش‌ها','table'=>'learning_contents','fields'=>['title'=>'عنوان','body'=>'متن آموزش','is_published'=>'منتشر شود']],
        'exams'=>['title'=>'آزمون‌ها','table'=>'exams','fields'=>['title'=>'عنوان','description'=>'شرح','questions'=>'سوال‌های چهارگزینه‌ای','pass_score'=>'حد نصاب','is_published'=>'منتشر شود']],
        'exam-attempts'=>['title'=>'نتایج آزمون','table'=>'exam_attempts','fields'=>['ambassador_id'=>'نماینده','exam_id'=>'آزمون','score'=>'درصد','passed'=>'قبول شده','duration_seconds'=>'مدت (ثانیه)']],
        'learning-progress'=>['title'=>'پیشرفت آموزش','table'=>'learning_progress','fields'=>['ambassador_id'=>'نماینده','learning_content_id'=>'آموزش','progress_percent'=>'درصد','completed'=>'تکمیل شده']],
        'notices'=>['title'=>'اطلاعیه‌ها','table'=>'notices','fields'=>['title'=>'عنوان','body'=>'متن اطلاعیه','is_pinned'=>'سنجاق شود','is_published'=>'منتشر شود']],
        'project-forms'=>['title'=>'فرم‌های پروژه','table'=>'project_forms','fields'=>['name'=>'نام فرم','status'=>'وضعیت','target_segments'=>'زمینه‌های مجاز (JSON)','is_default'=>'فرم پیش‌فرض']],
        'notifications'=>['title'=>'اعلان‌ها','table'=>'notifications','fields'=>['ambassador_id'=>'نماینده (خالی=عمومی)','channel'=>'کانال','event_key'=>'رویداد','recipient'=>'گیرنده','message'=>'متن']],
        'sms-reports'=>['title'=>'گزارش پیامک','table'=>'sms_logs','fields'=>['ambassador_id'=>'نماینده','provider'=>'درگاه','recipient'=>'گیرنده','event_key'=>'رویداد','message'=>'پیام','status'=>'وضعیت','error'=>'خطا']],
        'media'=>['title'=>'رسانه نمایندگان','table'=>'media_files','fields'=>['ambassador_id'=>'نماینده','project_id'=>'پروژه','original_name'=>'نام فایل','mime_type'=>'نوع فایل','file_size'=>'حجم','kind'=>'نوع','review_status'=>'بررسی']],
        'project-forms'=>['title'=>'فرم‌های پروژه','table'=>'project_forms','fields'=>['name'=>'نام فرم','status'=>'وضعیت','target_segments'=>'زمینه‌های مجاز (JSON)','is_default'=>'فرم پیش‌فرض']],
        'ai-knowledge'=>['title'=>'پایگاه دانش AI','table'=>'ai_knowledge','fields'=>['title'=>'عنوان','body'=>'محتوا','is_published'=>'فعال']],
    ];

    public function home(Request $request)
    {
        if (!User::where('role','admin')->exists()) return redirect()->route('install');
        if (!auth()->check()) return redirect()->route('login');
        if (auth()->user()->role === 'admin') return $this->adminDashboard();
        if (auth()->user()->role === 'admin_staff') return redirect()->route('staff.dashboard');
        if (auth()->user()->role === 'supervisor') return redirect()->route('supervisor.dashboard');
        return $this->memberDashboard();
    }

    public function installForm() { abort_if(User::where('role','admin')->exists(),404); return view('auth.install'); }
    public function install(Request $request)
    {
        abort_if(User::where('role','admin')->exists(),404);
        $data=$request->validate(['first_name'=>'required|string|max:100','last_name'=>'required|string|max:100','email'=>'required|email|max:190|unique:users,email','password'=>'required|string|min:12|confirmed']);
        $user=User::create($data+['name'=>$data['first_name'].' '.$data['last_name'],'role'=>'admin','status'=>'active']);
        foreach(['segments'=>json_encode(['عمومی'],JSON_UNESCAPED_UNICODE),'project_stages'=>json_encode(['سرنخ جدید','ارزیابی نیاز','ارائه پیشنهاد','مذاکره','فروش قطعی','تکمیل پروژه'],JSON_UNESCAPED_UNICODE),'ranks'=>json_encode([['title'=>'عادی','min'=>0,'max'=>null]],JSON_UNESCAPED_UNICODE),'activity_points'=>'{}','sms_enabled'=>'0','ai_enabled'=>'0'] as $key=>$value)DB::table('srm_settings')->updateOrInsert(['key'=>$key],['value'=>$value,'created_at'=>now(),'updated_at'=>now()]);
        auth()->login($user); $request->session()->regenerate(); $this->audit('install.admin_created',$user->email);
        return redirect()->route('admin.dashboard')->with('success','مدیر سامانه ساخته شد.');
    }
    public function loginForm() { return view('auth.login'); }
    public function login(Request $request)
    {
        $data=$request->validate(['identifier'=>'required|string','password'=>'required|string']);$field=filter_var($data['identifier'],FILTER_VALIDATE_EMAIL)?'email':'mobile';$credentials=[$field=>$data['identifier'],'password'=>$data['password']];
        if (!auth()->attempt($credentials + ['status'=>'approved'], $request->boolean('remember'))) {
            if (!auth()->attempt($credentials + ['status'=>'active'], $request->boolean('remember'))) return back()->withErrors(['identifier'=>'موبایل/ایمیل یا رمز نادرست است یا حساب هنوز تأیید نشده.'])->onlyInput('identifier');
        }
        $request->session()->regenerate(); $user=auth()->user(); $user->forceFill(['last_activity_at'=>now()])->save();
        $this->audit('auth.login',$user->email);
        $destination=match($user->role){'admin'=>route('admin.dashboard'),'admin_staff'=>route('staff.dashboard'),'supervisor'=>route('supervisor.dashboard'),default=>route('member.dashboard')};return redirect()->intended($destination);
    }
    public function forgotPasswordForm() { return view('auth.forgot-password'); }
    public function sendPasswordResetLink(Request $request)
    {
        $data=$request->validate(['email'=>'required|email|max:190']);
        $status=Password::sendResetLink($data);
        return $status===Password::RESET_LINK_SENT
            ? back()->with('status','اگر این ایمیل در سامانه ثبت شده باشد، پیوند بازیابی رمز برای آن ارسال می‌شود.')
            : back()->withErrors(['email'=>__($status)]);
    }
    public function resetPasswordForm(Request $request,string $token)
    {
        return view('auth.reset-password',['token'=>$token,'email'=>(string)$request->query('email','')]);
    }
    public function resetPassword(Request $request)
    {
        $data=$request->validate(['token'=>'required','email'=>'required|email|max:190','password'=>'required|string|min:12|confirmed']);
        $status=Password::reset($data,function(User $user,string $password): void {
            $user->forceFill(['password'=>Hash::make($password),'remember_token'=>Str::random(60)])->save();
        });
        return $status===Password::PASSWORD_RESET
            ? redirect()->route('login')->with('success','رمز عبور با موفقیت تغییر کرد؛ اکنون وارد شوید.')
            : back()->withErrors(['email'=>__($status)]);
    }
    public function registerForm(Request $request) { return view('auth.register',['referralCode'=>$request->query('ref',''),'provinces'=>array_keys(config('peyvand_geo')),'segments'=>$this->segments()]); }
    public function cities(string $province) { return response()->json(config('peyvand_geo.'.$province,[])); }
    public function register(Request $request)
    {
        $request->merge(['mobile'=>$this->digits((string)$request->input('mobile')),'national_id'=>$this->digits((string)$request->input('national_id')),'postal_code'=>$this->digits((string)$request->input('postal_code'))]);
        $nidHash=hash_hmac('sha256',(string)$request->input('national_id'),(string)config('app.key'));$request->merge(['national_id_hash'=>$nidHash]);
        $validator=Validator::make($request->all(),['first_name'=>'required|string|max:100','last_name'=>'required|string|max:100','email'=>'nullable|email|max:190|unique:users,email','mobile'=>'required|regex:/^09\d{9}$/|unique:users,mobile','national_id'=>'required|regex:/^\d{10}$/','national_id_hash'=>'required|unique:users,national_id_hash','province'=>'required|string|max:100','city'=>'required|string|max:100','address'=>'required|string|max:3000','postal_code'=>'nullable|regex:/^\d{10}$/','no_postal_code'=>'nullable|boolean','primary_segment'=>'required|string|max:80','secondary_segments'=>'nullable|array','secondary_segments.*'=>'string|max:80','referral_code'=>'nullable|string|max:40'],['first_name.required'=>'واردکردن نام الزامی است.','last_name.required'=>'واردکردن نام خانوادگی الزامی است.','email.email'=>'قالب ایمیل معتبر نیست.','email.unique'=>'این ایمیل قبلاً در سامانه ثبت شده است.','mobile.required'=>'واردکردن شماره همراه الزامی است.','mobile.regex'=>'شماره همراه باید ۱۱ رقم و با 09 آغاز شود.','mobile.unique'=>'این شماره همراه قبلاً در سامانه ثبت شده است.','national_id.required'=>'واردکردن کد ملی الزامی است.','national_id.regex'=>'کد ملی باید دقیقاً ۱۰ رقم باشد.','national_id_hash.unique'=>'این کد ملی قبلاً در سامانه ثبت شده است.','province.required'=>'استان را انتخاب کنید.','city.required'=>'شهر را انتخاب کنید.','address.required'=>'واردکردن نشانی الزامی است.','postal_code.regex'=>'کدپستی باید دقیقاً ۱۰ رقم باشد.','primary_segment.required'=>'زمینهٔ فعالیت را انتخاب کنید.','secondary_segments.array'=>'فهرست زمینه‌های فعالیت معتبر نیست.','secondary_segments.*.string'=>'یکی از زمینه‌های انتخاب‌شده معتبر نیست.','referral_code.max'=>'کد معرف بیش از حد مجاز است.']);$d=$validator->validate();
        $d['no_postal_code']=$request->boolean('no_postal_code');if(!$d['no_postal_code']&&empty($d['postal_code']))return back()->withErrors(['postal_code'=>'کدپستی ۱۰ رقمی لازم است یا گزینه کدپستی ندارم را انتخاب کنید.'])->withInput();
        if(!in_array($d['city'],config('peyvand_geo.'.$d['province'],[]),true))return back()->withErrors(['city'=>'این شهر در استان انتخاب‌شده وجود ندارد؛ استان و شهر را دوباره انتخاب کنید.'])->withInput();
        $validSegments=array_map(fn($s)=>is_array($s)?($s['key']??$s['label']??''):$s,$this->segments());$selected=array_values(array_unique(array_filter(array_merge($d['secondary_segments']??[],[$d['primary_segment']]))));if(!$selected||count(array_diff($selected,$validSegments))>0)return back()->withErrors(['primary_segment'=>'زمینهٔ فعالیت انتخاب‌شده معتبر نیست.'])->withInput();$d['secondary_segments']=$selected;
        $referrer=null;if(!empty($d['referral_code'])){$referrer=User::where('referral_code',$d['referral_code'])->whereIn('status',['approved','active'])->first();if(!$referrer)return back()->withErrors(['referral_code'=>'کد معرف معتبر یا فعال نیست.'])->withInput();}unset($d['referral_code']);if($d['no_postal_code'])$d['postal_code']='';$d['name']=$d['first_name'].' '.$d['last_name'];$d['role']='ambassador';$d['status']='pending';$d['password']=$d['national_id'];$d['password_change_required']=true;$d['referral_code']=strtoupper(Str::random(10));$d['referrer_id']=$referrer?->id;
        $user=User::create($d);if($referrer)Referral::create(['referrer_id'=>$referrer->id,'referred_id'=>$user->id,'invited_name'=>$user->name,'invited_phone'=>$user->mobile,'invite_code'=>strtoupper(Str::random(12)),'status'=>'registered']);$this->awardActivityPoints((int)$user->id,'registration','ثبت‌نام نماینده','نماینده #'.$user->id);$this->audit('ambassador.registered',$user->email??$user->mobile);app(NotificationService::class)->admins('ambassador_registered','ثبت‌نام جدید نماینده در انتظار بررسی است: '.$user->name);
        if(filter_var(self::setting('require_registration_exam','0'),FILTER_VALIDATE_BOOLEAN)){$exam=DB::table('exams')->where('type','pre_registration')->where('is_published',true)->first();if($exam){$token=Str::random(64);DB::table('pre_registration_exam_sessions')->insert(['ambassador_id'=>$user->id,'token_hash'=>hash('sha256',$token),'expires_at'=>now()->addHours(24),'created_at'=>now(),'updated_at'=>now()]);return redirect()->route('pre-exam',$token);}}
        return redirect()->route('login')->with('success','درخواست عضویت ثبت شد و پس از بررسی مدیریت فعال می‌شود.');
    }
    public function logout(Request $request) { $this->audit('auth.logout');auth()->logout();$request->session()->invalidate();$request->session()->regenerateToken();return redirect()->route('login'); }
    public function preRegistrationExam(string $token)
    {
        $session=DB::table('pre_registration_exam_sessions')->where('token_hash',hash('sha256',$token))->where('expires_at','>',now())->first();abort_unless($session&&!$session->passed,404);
        $exam=DB::table('exams')->where('type','pre_registration')->where('is_published',true)->latest()->first();abort_unless($exam,404);$questions=json_decode($exam->questions,true)?:[];return view('auth.pre-exam',compact('token','exam','questions'));
    }
    public function submitPreRegistrationExam(Request $request,string $token)
    {
        $session=DB::table('pre_registration_exam_sessions')->where('token_hash',hash('sha256',$token))->where('expires_at','>',now())->first();abort_unless($session&&!$session->passed,404);
        $exam=DB::table('exams')->where('type','pre_registration')->where('is_published',true)->latest()->first();abort_unless($exam,404);$questions=json_decode($exam->questions,true)?:[];$answers=$request->input('answers',[]);$correct=0;$wrong=[];foreach($questions as $i=>$q){if((string)($answers[$i]??'')===(string)($q['correct']??''))$correct++;else $wrong[]=$i;}$score=count($questions)?(int)round($correct*100/count($questions)):0;$passed=$score>=(int)$exam->pass_score;
        DB::table('pre_registration_exam_sessions')->where('id',$session->id)->update(['attempts'=>$session->attempts+1,'passed'=>$passed,'last_wrong_questions'=>json_encode($wrong),'passed_at'=>$passed?now():null,'updated_at'=>now()]);
        if($passed){User::whereKey($session->ambassador_id)->update(['status'=>'pending']);return redirect()->route('login')->with('success','آزمون با موفقیت گذرانده شد؛ درخواست شما در صف بررسی مدیریت است.');}
        return back()->withErrors(['exam'=>'حد نصاب قبولی به دست نیامد. امتیاز شما '.$score.'٪ است؛ دوباره تلاش کنید.']);
    }

    public function adminDashboard()
    {
        $stats=['ambassadors'=>User::where('role','ambassador')->count(),'pending'=>User::where('role','ambassador')->where('status','pending')->count(),'projects'=>Project::count(),'pending_projects'=>Project::where('status','pending')->count(),'redemptions'=>DB::table('redemptions')->where('status','pending')->count(),'feedback'=>DB::table('feedback_tickets')->where('status','open')->count()];
        $recent=Project::with('ambassador')->latest()->limit(8)->get();
        $months=collect(range(5,0))->map(fn($offset)=>now()->startOfMonth()->subMonths($offset));
        $start=$months->first()->copy();
        $projectsByMonth=Project::where('created_at','>=',$start)->get(['created_at'])->groupBy(fn($project)=>$project->created_at?->format('Y-m'));
        $representativesByMonth=User::where('role','ambassador')->where('created_at','>=',$start)->get(['created_at'])->groupBy(fn($user)=>$user->created_at?->format('Y-m'));
        $pendingProjectsByMonth=Project::where('status','pending')->where('created_at','>=',$start)->get(['created_at'])->groupBy(fn($project)=>$project->created_at?->format('Y-m'));
        $pendingRepresentativesByMonth=User::where('role','ambassador')->where('status','pending')->where('created_at','>=',$start)->get(['created_at'])->groupBy(fn($user)=>$user->created_at?->format('Y-m'));
        $chartMonths=$months->map(fn($month)=>['label'=>$month->format('m/Y'),'projects'=>($projectsByMonth[$month->format('Y-m')]??collect())->count(),'representatives'=>($representativesByMonth[$month->format('Y-m')]??collect())->count(),'pending_projects'=>($pendingProjectsByMonth[$month->format('Y-m')]??collect())->count(),'pending_representatives'=>($pendingRepresentativesByMonth[$month->format('Y-m')]??collect())->count()])->values();
        $projectStatuses=Project::select('status',DB::raw('COUNT(*) as total'))->groupBy('status')->orderBy('status')->get();
        return view('admin.dashboard',compact('stats','recent','chartMonths','projectStatuses'));
    }
    public function memberDashboard()
    {
        $u=auth()->user();$stats=['projects'=>$u->projects()->count(),'points'=>(int)$this->eligiblePointQuery((int)$u->id)->sum('points.points'),'rank'=>$this->rankTitleFor($u),'referrals'=>$u->referrals()->count(),'unread'=>DB::table('notifications')->where(fn($q)=>$q->whereNull('ambassador_id')->orWhere('ambassador_id',$u->id))->whereNull('read_at')->count()];
        $bannerAvailable=$this->representativeBannerScope($u)!==null;
        return view('member.dashboard',compact('stats','bannerAvailable'));
    }

    private function staffModules(): array
    {
        return ['ambassadors'=>'نمایندگان','supervisors'=>'سرپرستان','projects'=>'پروژه‌ها','purchase-reports'=>'گزارش فروش','purchase-documents'=>'اسناد فروش','points'=>'امتیازات','rewards'=>'جوایز','redemptions'=>'درخواست جوایز','learning'=>'آموزش‌ها','learning-progress'=>'پیشرفت آموزش','exams'=>'آزمون‌ها','exam-attempts'=>'نتایج آزمون','notices'=>'اطلاعیه‌ها','feedback'=>'بازخورد و پشتیبانی','notifications'=>'اعلان‌ها','media'=>'رسانه نمایندگان','project-forms'=>'فرم پروژه','ai-knowledge'=>'پایگاه دانش AI'];
    }
    private function assertStaffModule(string $module): void
    {
        if(auth()->user()?->role==='admin_staff')abort_unless(array_key_exists($module,$this->staffModules())&&in_array($module,auth()->user()->secondary_segments??[],true),403,'این همکار به این بخش دسترسی ندارد.');
    }
    public function staffDashboard()
    {
        $modules=array_intersect_key($this->staffModules(),array_flip(auth()->user()->secondary_segments??[]));return view('staff.dashboard',compact('modules'));
    }
    public function collaborators()
    {
        $rows=User::where('role','admin_staff')->orderBy('name')->get();$modules=$this->staffModules();return view('admin.collaborators',compact('rows','modules'));
    }
    public function saveCollaborator(Request $request)
    {
        $id=$request->integer('id')?:null;$existing=$id?User::where('role','admin_staff')->findOrFail($id):null;
        $d=$request->validate(['id'=>'nullable|integer','name'=>'required|string|max:190','email'=>'required|email|max:190|unique:users,email'.($existing?','.$existing->id:''),'password'=>($existing?'nullable':'required').'|string|min:10','permissions'=>'required|array|min:1','permissions.*'=>'required|string']);
        $allowed=array_keys($this->staffModules());abort_unless(count(array_diff($d['permissions'],$allowed))===0,422,'یکی از بخش‌های انتخاب‌شده معتبر نیست.');
        if($existing){$existing->name=$d['name'];$existing->first_name=$d['name'];$existing->email=$d['email'];$existing->secondary_segments=array_values(array_unique($d['permissions']));if(!empty($d['password']))$existing->password=Hash::make($d['password']);$existing->save();$userId=$existing->id;}else{$user=User::create(['name'=>$d['name'],'first_name'=>$d['name'],'last_name'=>'','email'=>$d['email'],'password'=>Hash::make($d['password']),'role'=>'admin_staff','status'=>'active','secondary_segments'=>array_values(array_unique($d['permissions']))]);$userId=$user->id;}
        $this->audit('admin.collaborator_saved',$userId.':'.implode(',',$d['permissions']));return redirect()->route('admin.collaborators')->with('success','حساب همکار مدیر ذخیره شد.');
    }
    public function deleteCollaborator(int $id)
    {
        $user=User::where('role','admin_staff')->findOrFail($id);$user->delete();$this->audit('admin.collaborator_deleted',$id);return back()->with('success','حساب همکار حذف شد.');
    }

    public function moduleIndex(string $module)
    {
        $this->assertStaffModule($module);
        if ($module === 'media') return $this->representativeMediaIndex();
        if ($module === 'sms-reports') return $this->smsReportsIndex();
        $m=$this->module($module);$query=DB::table($m['table']);if(!empty($m['user'])){
            $query->where('role','ambassador');
            foreach(['name','mobile','province','city'] as $field){$term=trim((string)request()->query($field,''));if($term==='')continue;$term=$field==='mobile'?$this->digits($term):$term;
                if($field==='name')$query->where(fn($q)=>$q->where('name','like','%'.$term.'%')->orWhere('first_name','like','%'.$term.'%')->orWhere('last_name','like','%'.$term.'%'));
                else $query->where($field,'like','%'.$term.'%');
            }
            $nationalId=$this->digits((string)request()->query('national_id',''));if($nationalId!=='')$query->where('national_id_hash',hash_hmac('sha256',$nationalId,(string)config('app.key')));
        }$rows=$query->latest('id')->paginate(25)->withQueryString();
        return view('admin.module-index',compact('m','module','rows'));
    }
    public function projectFormFields(int $id)
    {
        $form=DB::table('project_forms')->find($id);abort_unless($form,404);$fields=DB::table('project_form_fields')->where('form_id',$id)->orderBy('sort_order')->orderBy('id')->get();return view('admin.project-form-fields',compact('form','fields'));
    }
    public function saveProjectFormField(Request $request,int $id)
    {
        abort_unless(DB::table('project_forms')->where('id',$id)->exists(),404);
        $data=$this->validateProjectFormField($request,$id);
        DB::table('project_form_fields')->insert(['form_id'=>$id]+$data+['created_at'=>now(),'updated_at'=>now()]);
        return back()->with('success','فیلد فرم ثبت شد.');
    }
    public function updateProjectFormField(Request $request,int $id,int $field)
    {
        abort_unless(DB::table('project_form_fields')->where('form_id',$id)->where('id',$field)->exists(),404);
        $data=$this->validateProjectFormField($request,$id,$field);
        DB::table('project_form_fields')->where('form_id',$id)->where('id',$field)->update($data+['updated_at'=>now()]);
        return back()->with('success','فیلد فرم ویرایش شد.');
    }
    private function validateProjectFormField(Request $request,int $formId,?int $fieldId=null): array
    {
        $d=$request->validate(['label'=>'required|string|max:190','field_key'=>'required|alpha_dash|max:80','type'=>'required|in:text,textarea,number,count,tel,email,date,jalali_date,time,select,radio,checkbox,document,file,image,video,stage,url','help_text'=>'nullable|string|max:500','placeholder'=>'nullable|string|max:190','options'=>'nullable|string','required'=>'nullable|boolean','enabled'=>'nullable|boolean','sort_order'=>'nullable|integer|min:0']);
        $duplicate=DB::table('project_form_fields')->where('form_id',$formId)->where('field_key',$d['field_key'])->when($fieldId,fn($query)=>$query->where('id','!=',$fieldId))->exists();
        if($duplicate)return back()->withErrors(['field_key'=>'این کلید در فرم تکراری است.'])->withInput();
        $raw=trim((string)($d['options']??''));$choices=[];
        if($raw!==''){
            $decoded=json_decode($raw,true);
            if(json_last_error()===JSON_ERROR_NONE&&is_array($decoded))$choices=array_is_list($decoded)?$decoded:(array)($decoded['choices']??[]);
            else $choices=preg_split('/\r\n|\r|\n/u',$raw)?:[];
            $choices=array_values(array_filter(array_map(function($choice){if(is_array($choice))return ['value'=>trim((string)($choice['value']??$choice['label']??'')),'label'=>trim((string)($choice['label']??$choice['value']??''))];$choice=trim((string)$choice);return $choice===''?null:['value'=>$choice,'label'=>$choice];},$choices)));
        }
        if(in_array($d['type'],['radio','checkbox','select'],true)&&count($choices)<1)return back()->withErrors(['options'=>'برای این نوع فیلد، گزینه‌ها را هرکدام در یک خط وارد کنید.'])->withInput();
        $metadata=['choices'=>$choices,'help_text'=>trim((string)($d['help_text']??'')),'placeholder'=>trim((string)($d['placeholder']??''))];
        return ['label'=>$d['label'],'field_key'=>$d['field_key'],'type'=>$d['type'],'options'=>json_encode($metadata,JSON_UNESCAPED_UNICODE),'required'=>$request->boolean('required'),'enabled'=>$request->boolean('enabled',true),'sort_order'=>$d['sort_order']??0];
    }
    public function deleteProjectFormField(int $id,int $field)
    {
        DB::table('project_form_fields')->where('form_id',$id)->where('id',$field)->delete();return back()->with('success','فیلد حذف شد.');
    }
    public function moduleCreate(string $module)
    {
        $this->assertStaffModule($module);abort_if(in_array($module,['media','sms-reports','projects'],true),404);$m=$this->module($module);$row=null;
        if($module==='supervisors'){$account=null;return view('admin.supervisor-form',compact('m','module','row','account'));}
        $segments=in_array($module,['project-forms','ambassadors'],true)?$this->segments():[];
        if($module==='project-forms'){$fields=collect();return view('admin.project-form-builder',array_merge(compact('m','module','row','segments','fields'),$this->projectFormBuilderData($row,$fields)));}
        $options=$this->options($module);$attachments=collect();$provinces=array_keys(config('peyvand_geo',[]));$citiesByProvince=config('peyvand_geo',[]);
        $routePrefix=auth()->user()->role==='admin_staff'?'staff':'admin';$initialQuestions=$this->initialModuleQuestions($row);
        return view('admin.module-form',compact('m','module','row','options','attachments','segments','routePrefix','initialQuestions','provinces','citiesByProvince'));
    }
    public function moduleEdit(string $module,int $id)
    {
        $this->assertStaffModule($module);abort_if(in_array($module,['media','sms-reports'],true),404);$m=$this->module($module);$row=DB::table($m['table'])->where('id',$id)->first();abort_unless($row,404);if(!empty($m['user']))abort_unless($row->role==='ambassador',404);
        if($module==='supervisors'){$account=User::where('role','supervisor')->where('supervisor_id',$id)->first();return view('admin.supervisor-form',compact('m','module','row','account'));}
        if($module==='projects'){
            $representative=User::find($row->ambassador_id);
            $values=is_array($row->form_values)?$row->form_values:(json_decode((string)$row->form_values,true)?:[]);
            $row->form_values=$values;
            $fieldLabels=DB::table('project_form_fields')->whereIn('field_key',array_keys($values))->orderByDesc('id')->get()->keyBy('field_key');
            $submittedFields=[];foreach($values as $key=>$value){if($key==='_project_processes')continue;$meta=$fieldLabels[$key]??null;$label=$meta->label??$key;$mediaId=is_array($value)?($value['media_id']??null):null;$submittedFields[]=['label'=>$label,'value'=>$value,'media_id'=>$mediaId];}
            $attachments=DB::table('project_media')->join('media_files','media_files.id','=','project_media.media_file_id')->where('project_media.project_id',$id)->select('project_media.caption','media_files.id as media_id','media_files.original_name','media_files.mime_type')->orderBy('media_files.id')->get();
            $routePrefix=auth()->user()->role==='admin_staff'?'staff':'admin';
            return view('admin.project-review',compact('row','representative','submittedFields','attachments','routePrefix'));
        }
        if(in_array($module,['learning','notices','ai-knowledge'],true))$row->body=app(\App\Services\RichTextService::class)->sanitize((string)$row->body);if($module==='exams')$row->description=app(\App\Services\RichTextService::class)->sanitize((string)$row->description);
        $attachments=in_array($module,['learning','notices','exams'],true)?DB::table('media_files')->where('kind',($module==='learning'?'lesson:':($module==='notices'?'notice:':'exam:')).$id)->orderByDesc('id')->get():collect();$segments=in_array($module,['project-forms','ambassadors'],true)?$this->segments():[];
        if($module==='project-forms'){$fields=DB::table('project_form_fields')->where('form_id',$id)->orderBy('sort_order')->orderBy('id')->get();return view('admin.project-form-builder',array_merge(compact('m','module','row','segments','fields'),$this->projectFormBuilderData($row,$fields)));}
        $options=$this->options($module);if($module==='projects'&&!in_array((string)$row->stage,$options['stages'],true))$options['stages'][]=(string)$row->stage;$routePrefix=auth()->user()->role==='admin_staff'?'staff':'admin';$initialQuestions=$this->initialModuleQuestions($row);$provinces=array_keys(config('peyvand_geo',[]));$citiesByProvince=config('peyvand_geo',[]);return view('admin.module-form',compact('m','module','row','options','attachments','segments','routePrefix','initialQuestions','provinces','citiesByProvince'));
    }
    private function initialModuleQuestions($row): array
    {
        $questions=old('questions',$row->questions??[]);
        if(is_string($questions))$questions=json_decode($questions,true)?:[];
        return is_array($questions)?$questions:[];
    }
    private function projectFormBuilderData($row,$fields): array
    {
        $typeLabels=['text'=>'متن کوتاه','textarea'=>'متن بلند','tel'=>'شماره تلفن','email'=>'ایمیل','count'=>'تعداد','video'=>'ویدیوی MP4','image'=>'تصویر JPG / PNG','document'=>'سند PDF / ZIP','radio'=>'انتخاب تکی','checkbox'=>'انتخاب چندگانه','jalali_date'=>'تاریخ شمسی','time'=>'ساعت'];
        $initial=[];foreach($fields as $field){$meta=json_decode($field->options??'{}',true)?:[];$initial[]=['id'=>$field->id,'label'=>$field->label,'field_key'=>$field->field_key,'type'=>$field->type,'help_text'=>$meta['help_text']??'','placeholder'=>$meta['placeholder']??'','choices'=>array_map(fn($choice)=>is_array($choice)?($choice['label']??$choice['value']??''):$choice,$meta['choices']??[]),'required'=>(bool)$field->required];}
        if(old('builder_fields')){$oldFields=json_decode((string)old('builder_fields'),true);if(is_array($oldFields))$initial=$oldFields;}
        $storedSegments=$row?json_decode((string)($row->target_segments??'[]'),true):[];$selectedSegments=old('target_segments',is_array($storedSegments)?$storedSegments:[]);if(!is_array($selectedSegments))$selectedSegments=[];
        return ['routePrefix'=>auth()->user()->role==='admin_staff'?'staff':'admin','typeLabels'=>$typeLabels,'initial'=>$initial,'selectedSegments'=>$selectedSegments];
    }
    public function moduleSave(Request $request,string $module,?int $id=null)
    {
        abort_if(in_array($module,['media','sms-reports'],true),404);
        $this->assertStaffModule($module);
        abort_if($module==='projects',403,'اطلاعات پروژه فقط از مسیر بررسی قابل تغییر است.');
        $m=$this->module($module);$data=[];if($module==='projects'&&$request->filled('stage')){$currentStage=$id?DB::table('projects')->where('id',$id)->value('stage'):null;abort_unless(in_array((string)$request->input('stage'),$this->projectStages(),true)||(string)$request->input('stage')===(string)$currentStage,422,'مرحلهٔ فروش انتخاب‌شده معتبر نیست.');}
        if($module==='project-forms')return $this->saveProjectFormBuilder($request,$id);
        if($module==='supervisors')return $this->saveSupervisorAccount($request,$id);
        if($module==='project-forms'){$validSegments=array_map(fn($s)=>is_array($s)?($s['key']??$s['label']??''):$s,$this->segments());$selected=$request->input('target_segments',[]);if(!is_array($selected))return back()->withErrors(['target_segments'=>'زمینه‌های فعالیت معتبر نیست.'])->withInput();$request->validate(['target_segments'=>'nullable|array','target_segments.*'=>'string|max:80']);abort_unless(count(array_diff($selected,$validSegments))===0,422,'زمینهٔ فعالیت انتخاب‌شده معتبر نیست.');$data['target_segments']=json_encode(array_values(array_unique($selected)),JSON_UNESCAPED_UNICODE);}
        foreach(array_keys($m['fields']) as $key){if($module==='project-forms'&&$key==='target_segments')continue;if(in_array($key,['is_published','is_pinned','passed','is_default','completed'],true)){$data[$key]=$request->boolean($key);continue;}if(!$request->exists($key))continue;$value=$request->input($key);if($key==='supervisor_id'&&($value===null||$value==='')){$data[$key]=null;continue;}if(in_array($key,['questions','form_values','visibility_targets','segments','provinces','target_segments'],true)&&is_string($value)&&trim($value)!==''){$decoded=json_decode($value,true);if(json_last_error()!==JSON_ERROR_NONE)return back()->withErrors([$key=>'JSON واردشده معتبر نیست.'])->withInput();$value=json_encode($decoded,JSON_UNESCAPED_UNICODE);}$data[$key]=$value;}
        if(in_array($module,['learning','notices','ai-knowledge'],true)){$request->validate(['body'=>'nullable|string|max:100000']);$data['body']=app(\App\Services\RichTextService::class)->sanitize((string)$request->input('body',''));}
        if($module==='exams'){$request->validate(['description'=>'nullable|string|max:100000']);$data['description']=app(\App\Services\RichTextService::class)->sanitize((string)$request->input('description',''));}
        if($module==='exams'){
            $request->validate(['questions'=>'required|string','pass_score'=>'required|integer|min:0|max:100']);
            $questions=json_decode((string)($data['questions']??''),true)?:[];
            if(!$questions)return back()->withErrors(['questions'=>'حداقل یک سوال لازم است.'])->withInput();
            foreach($questions as $index=>$question){if(!is_array($question)||trim((string)($question['q']??''))===''||!is_array($question['options']??null)||count($question['options'])!==4||count(array_filter($question['options'],fn($option)=>trim((string)$option)!==''))!==4||!is_numeric($question['correct']??null)||(int)$question['correct']<0||(int)$question['correct']>3)return back()->withErrors(['questions'=>'سوال '.($index+1).' باید متن، چهار گزینه و پاسخ صحیح داشته باشد.'])->withInput();$questions[$index]=['q'=>trim((string)$question['q']),'options'=>array_map(fn($option)=>trim((string)$option),array_values($question['options'])),'correct'=>(int)$question['correct']];}
            $data['questions']=json_encode($questions,JSON_UNESCAPED_UNICODE);
        }
        $uploaded=[];
        if(in_array($module,['learning','exams','notices'],true)){
            $request->validate(['video_file'=>'nullable|file|max:51200|mimes:mp4','image_file'=>'nullable|image|max:10240|mimes:jpg,jpeg,png','document_file'=>'nullable|file|max:51200|mimes:pdf,zip']);
            foreach(['video_file','image_file','document_file'] as $field)if($request->hasFile($field))$uploaded[]=$request->file($field);
        }
        if(!empty($m['user'])){
            $request->merge(['mobile'=>$this->digits((string)$request->input('mobile')),'national_id'=>$this->digits((string)$request->input('national_id')),'postal_code'=>$this->digits((string)$request->input('postal_code'))]);
            $d=$request->validate(['first_name'=>'required|string|max:100','last_name'=>'required|string|max:100','email'=>'required|email|max:190|unique:users,email'.($id?','.$id:''),'mobile'=>($id?'nullable':'required').'|regex:/^09\d{9}$/|unique:users,mobile'.($id?','.$id:''),'national_id'=>($id?'nullable':'required').'|regex:/^\d{10}$/','province'=>'required|string|max:100','city'=>'required|string|max:100','address'=>'nullable|string|max:3000','postal_code'=>'nullable|regex:/^\d{10}$/','primary_segment'=>'required|string|max:80','password'=>'nullable|string|min:10','status'=>'required|in:pending,approved,active,rejected,inactive'],['email.unique'=>'این ایمیل قبلاً در سامانه ثبت شده است.','mobile.required'=>'واردکردن شماره همراه الزامی است.','mobile.regex'=>'شماره همراه باید ۱۱ رقم و با 09 آغاز شود.','mobile.unique'=>'این شماره همراه قبلاً در سامانه ثبت شده است.','national_id.required'=>'واردکردن کد ملی الزامی است.','national_id.regex'=>'کد ملی باید دقیقاً ۱۰ رقم باشد.','province.required'=>'استان را انتخاب کنید.','city.required'=>'شهر را انتخاب کنید.','postal_code.regex'=>'کدپستی باید دقیقاً ۱۰ رقم باشد.','password.min'=>'رمز اولیه باید حداقل ۱۰ نویسه باشد.','primary_segment.required'=>'زمینهٔ فعالیت را انتخاب کنید.']);
            $province=(string)$d['province'];$city=(string)$d['city'];if(!in_array($province,array_keys(config('peyvand_geo',[])),true)||!in_array($city,config('peyvand_geo.'.$province,[]),true))return back()->withErrors(['city'=>'استان یا شهر انتخاب‌شده معتبر نیست.'])->withInput();
            $validSegments=array_map(fn($segment)=>is_array($segment)?($segment['key']??$segment['label']??''):$segment,$this->segments());$currentSegment=$id?(string)DB::table('users')->where('id',$id)->where('role','ambassador')->value('primary_segment'):'';if(!in_array((string)$d['primary_segment'],$validSegments,true)&&(string)$d['primary_segment']!==$currentSegment)return back()->withErrors(['primary_segment'=>'زمینهٔ فعالیت انتخاب‌شده معتبر نیست.'])->withInput();
            if($d['national_id']??''){$nationalIdHash=hash_hmac('sha256',(string)$d['national_id'],(string)config('app.key'));$duplicate=DB::table('users')->where('national_id_hash',$nationalIdHash)->when($id,fn($query)=>$query->where('id','!=',$id))->exists();if($duplicate)return back()->withErrors(['national_id'=>'این کد ملی قبلاً در سامانه ثبت شده است.'])->withInput();$data['national_id']=Crypt::encryptString((string)$d['national_id']);$data['national_id_hash']=$nationalIdHash;}
            $data['mobile']=$d['mobile']??null;$data['role']='ambassador';$data['name']=trim(($data['first_name']??'').' '.($data['last_name']??''));if($request->filled('password'))$data['password']=Hash::make($request->input('password'));
        }
        if(isset($data['ambassador_id']))$request->validate(['ambassador_id'=>'required|exists:users,id']);if(isset($data['supervisor_id']))$request->validate(['supervisor_id'=>'nullable|exists:supervisors,id']);
        if(isset($data['title'])&&trim((string)$data['title'])==='')return back()->withErrors(['title'=>'عنوان الزامی است.'])->withInput();
        if($module==='exams'&&!$id)$data['type']='regular';
        if(in_array($module,['learning','notices'],true))$data['published_at']=!empty($data['is_published'])?now():null;
        $data['updated_at']=now();if($id){DB::table($m['table'])->where('id',$id)->update($data);$recordId=$id;}else{$data['created_at']=now();if(!empty($m['user']))$data['password']=$data['password']??Hash::make(Str::random(40));$recordId=DB::table($m['table'])->insertGetId($data);}
        if($uploaded){$kind=$module==='learning'?'lesson:'.$recordId:($module==='notices'?'notice:'.$recordId:'exam:'.$recordId);foreach($uploaded as $file)$this->storeSystemMedia($file,$kind);}
        $this->audit('admin.module_saved',$module.($id?'#'.$id:''));$prefix=auth()->user()->role==='admin_staff'?'staff':'admin';return redirect()->route($prefix.'.modules.index',$module)->with('success','تغییرات ذخیره شد.');
    }
    private function saveSupervisorAccount(Request $request,?int $id=null)
    {
        $row=$id?DB::table('supervisors')->find($id):null;abort_if($id&&!$row,404);$account=$id?User::where('role','supervisor')->where('supervisor_id',$id)->first():null;
        $d=$request->validate(['name'=>'required|string|max:190','email'=>'required|email|max:190|unique:users,email'.($account?','.$account->id:''),'mobile'=>'nullable|string|max:32','provinces'=>'nullable|string|max:5000','status'=>'required|in:active,inactive','password'=>($account?'nullable':'required').'|string|min:10']);
        $provinces=[];$raw=trim((string)($d['provinces']??''));if($raw!==''){$decoded=json_decode($raw,true);$provinces=is_array($decoded)?$decoded:preg_split('/[\r\n,،]+/u',$raw);$provinces=array_values(array_filter(array_map('trim',$provinces)));}
        $now=now();$supervisorId=DB::transaction(function()use($id,$d,$provinces,$account,$now){$data=['name'=>$d['name'],'email'=>$d['email'],'mobile'=>$d['mobile']??null,'provinces'=>json_encode($provinces,JSON_UNESCAPED_UNICODE),'status'=>$d['status'],'updated_at'=>$now];if($id){DB::table('supervisors')->where('id',$id)->update($data);$supervisorId=$id;}else{$data['created_at']=$now;$supervisorId=DB::table('supervisors')->insertGetId($data);}if($account){$account->name=$d['name'];$account->first_name=$d['name'];$account->email=$d['email'];$account->status=$d['status'];if(!empty($d['password']))$account->password=Hash::make($d['password']);$account->save();}else{User::create(['name'=>$d['name'],'first_name'=>$d['name'],'last_name'=>'','email'=>$d['email'],'password'=>Hash::make($d['password']),'role'=>'supervisor','status'=>$d['status'],'supervisor_id'=>$supervisorId]);}return $supervisorId;});
        $this->audit('admin.supervisor_saved',$supervisorId);$prefix=auth()->user()->role==='admin_staff'?'staff':'admin';return redirect()->route($prefix.'.modules.index','supervisors')->with('success','حساب و پروفایل سرپرست ذخیره شد.');
    }
    private function saveProjectFormBuilder(Request $request,?int $id=null)
    {
        $d=$request->validate(['name'=>'required|string|max:190','target_segments'=>'nullable|array','target_segments.*'=>'required|string|max:80','status'=>'required|in:active,inactive','builder_fields'=>'required|string|max:200000']);
        $validSegments=array_map(fn($s)=>is_array($s)?($s['key']??$s['label']??''):$s,$this->segments());$selected=array_values(array_unique($d['target_segments']??[]));abort_unless(count(array_diff($selected,$validSegments))===0,422,'زمینهٔ فعالیت انتخاب‌شده معتبر نیست.');
        $fields=json_decode($d['builder_fields'],true);if(!is_array($fields)||!array_is_list($fields)||count($fields)>50)return back()->withErrors(['builder_fields'=>'فهرست فیلدها معتبر نیست یا بیش از ۵۰ فیلد دارد.'])->withInput();
        $allowed=['text','textarea','tel','email','count','video','image','document','radio','checkbox','jalali_date','time'];$keys=[];$normalized=[];
        foreach($fields as $i=>$field){if(!is_array($field))return back()->withErrors(['builder_fields'=>'ساختار یکی از فیلدها معتبر نیست.'])->withInput();$key=trim((string)($field['field_key']??''));$label=trim((string)($field['label']??''));$type=(string)($field['type']??'');if(!preg_match('/^[A-Za-z][A-Za-z0-9_-]{0,79}$/',$key)||$label===''||mb_strlen($label)>190||!in_array($type,$allowed,true)||in_array($key,$keys,true))return back()->withErrors(['builder_fields'=>'نام، نوع یا شناسهٔ یکی از فیلدها معتبر نیست. شناسه‌ها باید یکتا باشند.'])->withInput();$keys[]=$key;$help=trim((string)($field['help_text']??''));$placeholder=trim((string)($field['placeholder']??''));if(mb_strlen($help)>500||mb_strlen($placeholder)>190)return back()->withErrors(['builder_fields'=>'متن راهنما یا جای‌نگهدار یکی از فیلدها بیش از حد مجاز است.'])->withInput();$choices=[];if(in_array($type,['radio','checkbox'],true)){foreach(($field['choices']??[]) as $choice){$choice=trim((string)$choice);if($choice!=='')$choices[]=['value'=>$choice,'label'=>$choice];}if(count($choices)<1)return back()->withErrors(['builder_fields'=>'برای فیلدهای انتخابی حداقل یک گزینه وارد کنید.'])->withInput();}$normalized[]=['id'=>isset($field['id'])?(int)$field['id']:null,'label'=>$label,'field_key'=>$key,'type'=>$type,'options'=>json_encode(['choices'=>$choices,'help_text'=>$help,'placeholder'=>$placeholder],JSON_UNESCAPED_UNICODE),'required'=>!empty($field['required']),'enabled'=>true,'sort_order'=>$i];}
        $now=now();DB::transaction(function()use($id,$d,$selected,$normalized,$now){$formData=['name'=>$d['name'],'status'=>$d['status'],'target_segments'=>json_encode($selected,JSON_UNESCAPED_UNICODE),'is_default'=>count($selected)===0,'updated_at'=>$now];if($id){$form=DB::table('project_forms')->where('id',$id)->lockForUpdate()->first();abort_unless($form,404);DB::table('project_forms')->where('id',$id)->update($formData);$formId=$id;}else{$formData['created_at']=$now;$formId=DB::table('project_forms')->insertGetId($formData);}$keep=[];foreach($normalized as $field){$fieldData=['form_id'=>$formId,'label'=>$field['label'],'field_key'=>$field['field_key'],'type'=>$field['type'],'options'=>$field['options'],'required'=>$field['required'],'enabled'=>true,'sort_order'=>$field['sort_order'],'updated_at'=>$now];if($field['id']){abort_unless(DB::table('project_form_fields')->where('form_id',$formId)->where('id',$field['id'])->exists(),422,'فیلد انتخاب‌شده متعلق به این فرم نیست.');DB::table('project_form_fields')->where('id',$field['id'])->update($fieldData);$keep[]=$field['id'];}else{$fieldData['created_at']=$now;$keep[]=DB::table('project_form_fields')->insertGetId($fieldData);}}$remove=DB::table('project_form_fields')->where('form_id',$formId);if($keep)$remove->whereNotIn('id',$keep);$remove->delete();});
        $this->audit('admin.module_saved','project-forms'.($id?'#'.$id:''));$prefix=auth()->user()->role==='admin_staff'?'staff':'admin';return redirect()->route($prefix.'.modules.index','project-forms')->with('success','فرم و فیلدهای آن ذخیره و منتشر شد.');
    }
    public function moduleDelete(string $module,int $id)
    {
        $this->assertStaffModule($module);
        abort_if(in_array($module,['media','sms-reports'],true),404);
        abort_if($module==='projects',403,'پروژه از این بخش قابل حذف نیست.');
        if($module==='supervisors'){$account=User::where('role','supervisor')->where('supervisor_id',$id)->first();DB::transaction(function()use($id,$account){DB::table('users')->where('role','ambassador')->where('supervisor_id',$id)->update(['supervisor_id'=>null]);if($account)$account->delete();DB::table('supervisors')->where('id',$id)->delete();});$this->audit('admin.module_deleted','supervisors#'.$id);return back()->with('success','سرپرست حذف شد و نمایندگان تیم بدون سرپرست ماندند.');}
        if(in_array($module,['learning','notices','exams'],true)){$kind=($module==='learning'?'lesson:':($module==='notices'?'notice:':'exam:')).$id;$assets=DB::table('media_files')->where('kind',$kind)->get();foreach($assets as $asset)$this->removeMediaFile($asset);}
        $m=$this->module($module);if(!empty($m['user']))DB::table('users')->where('id',$id)->where('role','ambassador')->delete();else DB::table($m['table'])->where('id',$id)->delete();$this->audit('admin.module_deleted',$module.'#'.$id);return back()->with('success','رکورد حذف شد.');
    }

    public function smsReportsIndex()
    {
        $rows=DB::table('sms_logs')->leftJoin('users','users.id','=','sms_logs.ambassador_id')->select('sms_logs.*','users.name as representative_name')->latest('sms_logs.id')->paginate(40)->withQueryString();
        return view('admin.sms-reports',compact('rows'));
    }

    public function representativeMediaIndex()
    {
        $this->assertStaffModule('media');
        $rows=DB::table('media_files')->join('users','users.id','=','media_files.ambassador_id')->leftJoin('projects','projects.id','=','media_files.project_id')->whereNotNull('media_files.ambassador_id')->select('media_files.*','users.name as representative_name','projects.title as project_title')->latest('media_files.id')->paginate(40)->withQueryString();
        return view('admin.representative-media',compact('rows'));
    }

    public function adminMediaLibrary()
    {
        $rows=DB::table('media_files')->whereNull('ambassador_id')->whereNull('project_id')->where(function($query){$query->where('kind','admin')->orWhere('kind','like','lesson:%')->orWhere('kind','like','notice:%')->orWhere('kind','like','exam:%');})->latest('id')->paginate(40)->withQueryString();
        foreach($rows as $media){$media->source_title='کتابخانه مدیریت';if(preg_match('/^(lesson|notice|exam):(\d+)$/',$media->kind,$match)===1){$table=match($match[1]){'lesson'=>'learning_contents','notice'=>'notices',default=>'exams'};$media->source_title=DB::table($table)->where('id',(int)$match[2])->value('title')?:'محتوای حذف‌شده';}}
        return view('admin.media-library',compact('rows'));
    }

    public function uploadAdminMedia(Request $request)
    {
        $request->validate(['files'=>'required|array|min:1','files.*'=>'file|max:51200|mimes:jpg,jpeg,png,gif,webp,mp4,webm,pdf,zip,doc,docx,xls,xlsx']);
        foreach($request->file('files',[]) as $file)$this->storeSystemMedia($file,'admin');
        $this->audit('admin.media.uploaded',(string)count($request->file('files',[])));
        return back()->with('success','رسانه‌های انتخاب‌شده بارگذاری شدند.');
    }

    public function deleteRepresentativeMedia(int $id)
    {
        $this->assertStaffModule('media');
        $media=DB::table('media_files')->whereNotNull('ambassador_id')->find($id);abort_unless($media,404);$this->removeMediaFile($media);$this->audit('representative.media.deleted',(string)$id);
        return back()->with('success','رسانه نماینده حذف شد.');
    }

    public function bulkDeleteRepresentativeMedia(Request $request)
    {
        $this->assertStaffModule('media');
        $ids=$request->validate(['ids'=>'required|array|min:1','ids.*'=>'integer|distinct'])['ids'];$items=DB::table('media_files')->whereNotNull('ambassador_id')->whereIn('id',$ids)->get();
        foreach($items as $item)$this->removeMediaFile($item);
        $this->audit('representative.media.bulk_deleted',(string)$items->count());
        return back()->with('success',$items->count().' رسانه نمایندگان حذف شد.');
    }

    public function deleteAdminMedia(int $id)
    {
        $media=DB::table('media_files')->whereNull('ambassador_id')->whereNull('project_id')->where(function($query){$query->where('kind','admin')->orWhere('kind','like','lesson:%')->orWhere('kind','like','notice:%')->orWhere('kind','like','exam:%');})->find($id);abort_unless($media,404);$this->removeMediaFile($media);$this->audit('admin.media.deleted',(string)$id);
        return back()->with('success','رسانه حذف شد.');
    }

    public function deleteContentMedia(int $id)
    {
        $media=DB::table('media_files')->where('id',$id)->where(function($query){$query->where('kind','like','lesson:%')->orWhere('kind','like','notice:%')->orWhere('kind','like','exam:%');})->first();abort_unless($media,404);if(auth()->user()?->role==='admin_staff'){$module=str_starts_with($media->kind,'lesson:')?'learning':(str_starts_with($media->kind,'notice:')?'notices':'exams');$this->assertStaffModule($module);}$this->removeMediaFile($media);$this->audit('admin.content_media.deleted',(string)$id);
        return back()->with('success','فایل از محتوا حذف شد.');
    }

    private function storeSystemMedia($file,string $kind): int
    {
        $path=$file->store('srm/system-media','local');
        return DB::table('media_files')->insertGetId(['ambassador_id'=>null,'project_id'=>null,'storage_key'=>$path,'original_name'=>$file->getClientOriginalName(),'mime_type'=>$file->getMimeType()?:'application/octet-stream','file_size'=>$file->getSize(),'sha256'=>hash_file('sha256',$file->getRealPath()),'kind'=>$kind,'review_status'=>'published','created_at'=>now(),'updated_at'=>now()]);
    }

    private function removeMediaFile(object $media): void
    {
        DB::table('media_files')->where('id',$media->id)->delete();
        Storage::disk('local')->delete($media->storage_key);
    }
    public function approveAmbassador(int $id,Request $request)
    {
        $this->assertStaffModule('ambassadors');
        $user=User::where('role','ambassador')->findOrFail($id);$status=$request->validate(['status'=>'required|in:approved,rejected,active,inactive'])['status'];$user->status=$status;$user->save();$this->audit('ambassador.status',$id.':'.$status);app(NotificationService::class)->ambassador($id,'ambassador_'.$status,'وضعیت حساب شما: '.$status);return back()->with('success','وضعیت نماینده به‌روزرسانی شد.');
    }
    public function reports() { $stats=['projects_by_status'=>Project::select('status',DB::raw('COUNT(*) as total'))->groupBy('status')->get(),'ambassadors_by_status'=>User::where('role','ambassador')->select('status',DB::raw('COUNT(*) as total'))->groupBy('status')->get(),'top_ambassadors'=>DB::table('users')->leftJoin('points','users.id','=','points.ambassador_id')->where('users.role','ambassador')->groupBy('users.id','users.name')->select('users.id','users.name',DB::raw('COALESCE(SUM(points.points),0) as points'))->orderByDesc('points')->limit(15)->get()];return view('admin.reports',compact('stats')); }

    public function memberProjects() { $user=auth()->user();$rows=Project::where('ambassador_id',$user->id)->latest()->paginate(20);$form=$this->activeProjectForm($user);$fields=$form?DB::table('project_form_fields')->where('form_id',$form->id)->where('enabled',true)->orderBy('sort_order')->get():collect();$provinces=array_keys(config('peyvand_geo'));$processes=json_decode((string)self::setting('project_processes','[]'),true)?:[];$processesEnabled=filter_var(self::setting('project_processes_enabled','0'),FILTER_VALIDATE_BOOLEAN);return view('member.projects',compact('rows','form','fields','provinces','processes','processesEnabled')); }
    public function memberProjectEdit(int $id)
    {
        $project=Project::where('ambassador_id',auth()->id())->findOrFail($id);$form=$this->activeProjectForm(auth()->user());$fields=$form?DB::table('project_form_fields')->where('form_id',$form->id)->where('enabled',true)->orderBy('sort_order')->get():collect();$provinces=array_keys(config('peyvand_geo'));$citiesByProvince=config('peyvand_geo',[]);$processes=json_decode((string)self::setting('project_processes','[]'),true)?:[];$processesEnabled=filter_var(self::setting('project_processes_enabled','0'),FILTER_VALIDATE_BOOLEAN);$values=is_array($project->form_values)?$project->form_values:(json_decode((string)$project->form_values,true)?:[]);$attachments=DB::table('project_media')->join('media_files','media_files.id','=','project_media.media_file_id')->where('project_media.project_id',$id)->select('project_media.caption','media_files.id as media_id','media_files.original_name')->get();return view('member.project-edit',compact('project','form','fields','provinces','citiesByProvince','processes','processesEnabled','values','attachments'));
    }
    public function memberProjectUpdate(Request $request,int $id)
    {
        $project=Project::where('ambassador_id',auth()->id())->findOrFail($id);if($request->filled('estimated_amount'))$request->merge(['estimated_amount'=>$this->digits((string)$request->input('estimated_amount'))]);$d=$request->validate(['title'=>'required|string|max:190','customer_name'=>'nullable|string|max:190','customer_mobile'=>'nullable|string|max:32','province'=>'required|string|max:100','city'=>'required|string|max:100','estimated_amount'=>'nullable|numeric|min:0|max:99999999999999']);abort_unless(in_array($d['city'],config('peyvand_geo.'.$d['province'],[]),true),422,'استان یا شهر انتخاب‌شده معتبر نیست.');$form=$this->activeProjectForm(auth()->user());$fields=$form?DB::table('project_form_fields')->where('form_id',$form->id)->where('enabled',true)->orderBy('sort_order')->get():collect();$values=is_array($project->form_values)?$project->form_values:(json_decode((string)$project->form_values,true)?:[]);$processesEnabled=filter_var(self::setting('project_processes_enabled','0'),FILTER_VALIDATE_BOOLEAN);$defined=json_decode((string)self::setting('project_processes','[]'),true)?:[];
        if($processesEnabled){$request->validate(['processes'=>'required|array|min:1','processes.*'=>'required|string|max:80']);$selected=array_values(array_unique($request->input('processes',[])));abort_if(!$defined||count(array_diff($selected,$defined))>0,422,'فرایندهای انتخاب‌شده معتبر نیستند.');$values['_project_processes']=$selected;}
        foreach($fields as $field){$key=$field->field_key;$type=$field->type;if(in_array($type,['file','image','video','document'],true)){if(!$request->hasFile('project_fields.'.$key)){if($field->required&&empty($values[$key]))return back()->withErrors([$key=>'بارگذاری این فایل الزامی است.'])->withInput();continue;}$rules=match($type){'video'=>['file','max:51200','mimes:mp4'],'image'=>['file','max:10240','mimes:jpg,jpeg,png'],'document'=>['file','max:51200','mimes:pdf,zip'],'file'=>['file','max:51200','mimes:mp4,jpg,jpeg,png,pdf,zip']};$request->validate(['project_fields.'.$key=>$rules]);continue;}$value=$request->input('project_fields.'.$key);$empty=$value===null||$value===''||$value===[];if($empty){if($field->required)return back()->withErrors([$key=>'این فیلد الزامی است.'])->withInput();$values[$key]=$type==='checkbox'?[]:null;continue;}$choices=$this->projectFieldChoices($field);$rule=match($type){'text'=>'string|max:1000','textarea'=>'string|max:20000','tel'=>['string','regex:/^[0-9۰-۹٠-٩]+$/u','max:32'],'email'=>'email|max:190','number'=>'numeric','count'=>'integer|min:0','time'=>'date_format:H:i','date','jalali_date'=>'string|max:10','radio','select'=>'string|max:500','checkbox'=>'array',default=>'string|max:5000'};$validator=Validator::make(['value'=>$value],['value'=>is_array($rule)?$rule:explode('|',$rule)]);if($validator->fails())return back()->withErrors([$key=>'مقدار واردشده برای «'.$field->label.'» معتبر نیست.'])->withInput();if($type==='tel')$value=$this->digits((string)$value);if(in_array($type,['date','jalali_date'],true)&&!JalaliDate::isValid((string)$value))return back()->withErrors([$key=>'تاریخ شمسی معتبر انتخاب کنید.'])->withInput();if(in_array($type,['radio','select'],true)&&$choices&&!in_array((string)$value,$choices,true))return back()->withErrors([$key=>'گزینهٔ انتخاب‌شده معتبر نیست.'])->withInput();if($type==='checkbox'&&(array_filter($value,fn($item)=>!is_scalar($item))||array_diff(array_map('strval',$value),$choices)))return back()->withErrors([$key=>'گزینهٔ انتخاب‌شده معتبر نیست.'])->withInput();$values[$key]=$value;}
        $was=$project->status;$project->fill($d+['status'=>'pending','submitted_at'=>now(),'form_values'=>$values])->save();if(Schema::hasTable('project_status_history'))ProjectStatusHistory::create(['project_id'=>$id,'from_status'=>$was,'to_status'=>'pending','changed_by'=>auth()->id(),'note'=>'ویرایش و ارسال مجدد توسط نماینده']);
        foreach($fields as $field){$key=$field->field_key;if(!in_array($field->type,['file','image','video','document'],true)||!$request->hasFile('project_fields.'.$key))continue;$file=$request->file('project_fields.'.$key);$path=$file->store('srm/projects/'.$id,'local');$mid=DB::table('media_files')->insertGetId(['ambassador_id'=>auth()->id(),'project_id'=>$id,'storage_key'=>$path,'original_name'=>$file->getClientOriginalName(),'mime_type'=>$file->getMimeType()?:'application/octet-stream','file_size'=>$file->getSize(),'sha256'=>hash_file('sha256',$file->getRealPath()),'kind'=>'form','review_status'=>'pending','created_at'=>now(),'updated_at'=>now()]);DB::table('project_media')->insert(['project_id'=>$id,'media_file_id'=>$mid,'caption'=>$field->label,'created_at'=>now(),'updated_at'=>now()]);$values[$key]=['media_id'=>$mid,'name'=>$file->getClientOriginalName()];}$project->form_values=$values;$project->save();app(NotificationService::class)->admins('project_submitted','پروژه ویرایش و برای بررسی دوباره ارسال شد: '.$project->title);$this->audit('project.updated',$id);return redirect()->route('member.projects')->with('success','تغییرات ذخیره شد و پروژه برای بررسی ارسال شد.');
    }
    public function projectStore(Request $request)
    {
        if($request->filled('estimated_amount'))$request->merge(['estimated_amount'=>$this->digits((string)$request->input('estimated_amount'))]);
        $d=$request->validate(['title'=>'required|string|max:190','customer_name'=>'nullable|string|max:190','customer_mobile'=>'nullable|string|max:32','province'=>'required|string|max:100','city'=>'required|string|max:100','estimated_amount'=>'nullable|numeric|min:0|max:99999999999999']);abort_unless(in_array($d['city'],config('peyvand_geo.'.$d['province'],[]),true),422,'استان یا شهر انتخاب‌شده معتبر نیست.');$form=$this->activeProjectForm(auth()->user());$fields=$form?DB::table('project_form_fields')->where('form_id',$form->id)->where('enabled',true)->orderBy('sort_order')->orderBy('id')->get():collect();$values=[];
        $processesEnabled=filter_var(self::setting('project_processes_enabled','0'),FILTER_VALIDATE_BOOLEAN);$definedProcesses=json_decode((string)self::setting('project_processes','[]'),true)?:[];
        if($processesEnabled){abort_if(!$definedProcesses,422,'انتخاب فرایند فعال است، اما فرایندی تعریف نشده است.');$request->validate(['processes'=>'required|array|min:1','processes.*'=>'required|string|max:80']);$selected=array_values(array_unique($request->input('processes',[])));abort_if(count(array_diff($selected,$definedProcesses))>0,422,'یکی از فرایندهای انتخاب‌شده معتبر نیست.');$values['_project_processes']=$selected;}
        foreach($fields as $field){$key=$field->field_key;$type=$field->type;
            if(in_array($type,['file','image','video','document'],true)){
                $file=$request->file('project_fields.'.$key);
                if(!$file){if($field->required)return back()->withErrors([$key=>'بارگذاری این فایل الزامی است.'])->withInput();continue;}
                $rules=match($type){'video'=>['file','max:51200','mimes:mp4'],'image'=>['file','max:10240','mimes:jpg,jpeg,png'],'document'=>['file','max:51200','mimes:pdf,zip'],'file'=>['file','max:51200','mimes:mp4,jpg,jpeg,png,pdf,zip']};
                $request->validate(['project_fields.'.$key=>$rules]);
                continue;
            }
            $value=$request->input('project_fields.'.$key);$empty=$value===null||$value===''||$value===[];
            if($field->required&&$empty)return back()->withErrors([$key=>'این فیلد الزامی است.'])->withInput();
            if($empty){$values[$key]=$type==='checkbox'?[]:null;continue;}
            $choices=$this->projectFieldChoices($field);$rule=match($type){'text'=>'string|max:1000','textarea'=>'string|max:20000','tel'=>['string','regex:/^[0-9۰-۹٠-٩]+$/u','max:32'],'email'=>'email|max:190','number'=>'numeric','count'=>'integer|min:0','time'=>'date_format:H:i','date','jalali_date'=>'string|max:10','radio','select'=>'string|max:500', 'checkbox'=>'array', default=>'string|max:5000'};$rules=is_array($rule)?$rule:explode('|',$rule);if($field->required)array_unshift($rules,'required');
            $validator=\Illuminate\Support\Facades\Validator::make(['value'=>$value],['value'=>$rules]);
            if($validator->fails())return back()->withErrors([$key=>'مقدار واردشده برای «'.$field->label.'» معتبر نیست.'])->withInput();
            if($type==='tel')$value=$this->digits((string)$value);
            if(in_array($type,['date','jalali_date'],true)&&!JalaliDate::isValid((string)$value))return back()->withErrors([$key=>'تاریخ شمسی معتبر انتخاب کنید.'])->withInput();
            if(in_array($type,['radio','select'],true)&&$choices&&!in_array((string)$value,$choices,true))return back()->withErrors([$key=>'گزینهٔ انتخاب‌شده معتبر نیست.'])->withInput();
            if($type==='checkbox'){if($field->required&&$value===[])return back()->withErrors([$key=>'حداقل یک گزینه را انتخاب کنید.'])->withInput();if(array_filter($value,fn($item)=>!is_scalar($item))||array_diff(array_map('strval',$value),$choices))return back()->withErrors([$key=>'گزینهٔ انتخاب‌شده معتبر نیست.'])->withInput();}
            $values[$key]=$value;
        }
        $project=Project::create($d+['ambassador_id'=>auth()->id(),'status'=>'pending','stage'=>$this->projectStages()[0]??'new','submitted_at'=>now(),'form_values'=>$values]);if(Schema::hasTable('project_status_history'))ProjectStatusHistory::create(['project_id'=>$project->id,'from_status'=>null,'to_status'=>'pending','changed_by'=>auth()->id(),'note'=>'ثبت اولیه']);app(NotificationService::class)->admins('project_submitted','پروژه جدید: '.$project->title);
        $fileValues=[];foreach($fields as $field){if(!in_array($field->type,['file','image','video','document'],true)||!$request->hasFile('project_fields.'.$field->field_key))continue;$file=$request->file('project_fields.'.$field->field_key);$path=$file->store('srm/projects/'.$project->id,'local');$mid=DB::table('media_files')->insertGetId(['ambassador_id'=>auth()->id(),'project_id'=>$project->id,'storage_key'=>$path,'original_name'=>$file->getClientOriginalName(),'mime_type'=>$file->getMimeType()?:'application/octet-stream','file_size'=>$file->getSize(),'sha256'=>hash_file('sha256',$file->getRealPath()),'kind'=>'form','review_status'=>'pending','created_at'=>now(),'updated_at'=>now()]);DB::table('project_media')->insert(['project_id'=>$project->id,'media_file_id'=>$mid,'caption'=>$field->label,'created_at'=>now(),'updated_at'=>now()]);$fileValues[$field->field_key]=['media_id'=>$mid,'name'=>$file->getClientOriginalName()];}
        if($fileValues){$project->form_values=array_merge($project->form_values??[],$fileValues);$project->save();}
        $this->audit('project.submitted',$project->id);return redirect()->route('member.projects')->with('success','پروژه ثبت شد.');
    }
    public function changeProjectStatus(Request $request,int $id)
    {
        $this->assertStaffModule('projects');
        $project=Project::findOrFail($id);$d=$request->validate(['status'=>'required|in:pending,approved,rejected,active,completed,cancelled','manager_note'=>'nullable|string|max:5000']);$from=$project->status;DB::transaction(function()use($project,$d,$from,$id){$locked=Project::whereKey($id)->lockForUpdate()->firstOrFail();$locked->status=$d['status'];$locked->manager_note=$d['manager_note']??null;$locked->save();if(Schema::hasTable('project_status_history'))ProjectStatusHistory::create(['project_id'=>$id,'from_status'=>$from,'to_status'=>$locked->status,'changed_by'=>auth()->id(),'note'=>$d['manager_note']??null]);if(in_array($locked->status,['approved','active','completed'],true)){$already=DB::table('points')->where('ambassador_id',$locked->ambassador_id)->where('project_id',$locked->id)->where('source','activity')->where('reason','like','ثبت پروژه (%')->exists();if(!$already)$this->awardActivityPoints((int)$locked->ambassador_id,'project','ثبت پروژه','#'.$locked->id,(int)$locked->id);}});$project->refresh();$this->audit('project.status',$id.':'.$from.'>'.$project->status);app(NotificationService::class)->ambassador($project->ambassador_id,'project_status','وضعیت پروژه «'.$project->title.'» به '.$project->status.' تغییر کرد.',['project_title'=>$project->title,'status'=>$project->status]);return back()->with('success','بررسی پروژه ذخیره شد.');
    }
    public function addPoints(Request $request)
    {
        $this->assertStaffModule('points');
        $d=$request->validate(['ambassador_id'=>'required|exists:users,id','points'=>'required|integer|between:-100000,100000','reason'=>'required|string|max:190','project_id'=>'nullable|exists:projects,id']);Point::create($d+['source'=>'admin','created_by'=>auth()->id()]);$this->audit('points.added',$d['ambassador_id'].':'.$d['points']);return back()->with('success','امتیاز ثبت شد.');
    }
    public function requestReferral(Request $request)
    {
        $d=$request->validate(['invited_name'=>'required|string|max:190','invited_phone'=>'required|string|max:32']);$d['referrer_id']=auth()->id();$d['invite_code']=strtoupper(Str::random(12));$referral=Referral::create($d);$this->awardActivityPoints((int)$referral->referrer_id,'invitation','معرفی همکاری با دعوت','#'.$referral->id);$this->audit('referral.invited',$d['invited_phone']);return back()->with('success','دعوت ثبت شد.');
    }
    public function redeem(Request $request,int $rewardId)
    {
        $reward=DB::table('rewards')->where('status','active')->find($rewardId);abort_unless($reward,404);$balance=(int)$this->eligiblePointQuery((int)auth()->id())->sum('points.points');$already=DB::table('redemptions')->where('ambassador_id',auth()->id())->whereIn('status',['pending','approved'])->sum('points_spent');abort_if($reward->stock<1||$balance-$already<(int)$reward->points_required,422,'امتیاز یا موجودی جایزه کافی نیست.');DB::table('redemptions')->insert(['ambassador_id'=>auth()->id(),'reward_id'=>$rewardId,'points_spent'=>$reward->points_required,'status'=>'pending','created_at'=>now(),'updated_at'=>now()]);$this->audit('redemption.requested',$reward->title);return back()->with('success','درخواست جایزه ثبت شد.');
    }
    public function reviewRedemption(Request $request,int $id)
    {
        $this->assertStaffModule('redemptions');
        $d=$request->validate(['status'=>'required|in:approved,rejected,pending','review_note'=>'nullable|string|max:5000']);$row=DB::table('redemptions')->where('id',$id)->lockForUpdate()->first();abort_unless($row,404);
        DB::transaction(function()use($row,$d){$current=DB::table('redemptions')->where('id',$row->id)->lockForUpdate()->first();if($d['status']==='approved'&&$current->status!=='approved'){$reward=DB::table('rewards')->where('id',$current->reward_id)->lockForUpdate()->first();abort_unless($reward&&$reward->stock>0,422,'موجودی جایزه تمام شده است.');DB::table('rewards')->where('id',$reward->id)->decrement('stock');}if($d['status']!=='approved'&&$current->status==='approved')DB::table('rewards')->where('id',$current->reward_id)->increment('stock');DB::table('redemptions')->where('id',$current->id)->update(['status'=>$d['status'],'review_note'=>$d['review_note']??null,'reviewed_by'=>auth()->id(),'reviewed_at'=>now(),'updated_at'=>now()]);});
        $this->audit('redemption.reviewed',$id.':'.$d['status']);return back()->with('success','درخواست جایزه بررسی شد.');
    }
    public function completeLearning(int $id)
    {
        abort_unless(DB::table('learning_contents')->where('id',$id)->where('is_published',true)->exists(),404);$ambassadorId=(int)auth()->id();$progress=DB::table('learning_progress')->where('ambassador_id',$ambassadorId)->where('learning_content_id',$id)->first();DB::table('learning_progress')->updateOrInsert(['ambassador_id'=>$ambassadorId,'learning_content_id'=>$id],['progress_percent'=>100,'completed'=>true,'completed_at'=>now(),'updated_at'=>now(),'created_at'=>now()]);if(!$progress||!$progress->completed)$this->awardActivityPoints($ambassadorId,'learning','تکمیل آموزش','آموزش #'.$id.' برای نماینده #'.$ambassadorId);$this->audit('learning.completed','آموزش #'.$id);return back()->with('success','پیشرفت آموزش ثبت شد.');
    }
    public function submitExam(Request $request,int $id)
    {
        $exam=DB::table('exams')->where('is_published',true)->find($id);abort_unless($exam,404);$ambassadorId=(int)auth()->id();$questions=json_decode($exam->questions,true)?:[];$answers=$request->input('answers',[]);$correct=0;foreach($questions as $i=>$q)if((string)($answers[$i]??'')===(string)($q['correct']??''))$correct++;$score=count($questions)?(int)round($correct*100/count($questions)):0;DB::table('exam_attempts')->insert(['ambassador_id'=>$ambassadorId,'exam_id'=>$id,'answers'=>json_encode($answers),'score'=>$score,'passed'=>$score>=(int)$exam->pass_score,'started_at'=>now(),'submitted_at'=>now(),'created_at'=>now(),'updated_at'=>now()]);$this->awardActivityPoints($ambassadorId,'exam','تکمیل آزمون','آزمون #'.$id.' برای نماینده #'.$ambassadorId);$this->audit('exam.submitted','آزمون #'.$id.' · '.$score.'٪');return redirect()->route('member.learning')->with('success','آزمون ثبت شد؛ امتیاز شما '.$score.'٪ است.');
    }
    public function learning(Request $request)
    {
        $user=auth()->user();$richText=app(\App\Services\RichTextService::class);$lessons=DB::table('learning_contents')->where('is_published',true)->latest()->get();foreach($lessons as $lesson)$lesson->body=$richText->sanitize((string)$lesson->body);$exams=DB::table('exams')->where('is_published',true)->where('type','regular')->latest()->get();foreach($exams as $exam)$exam->description=$richText->sanitize((string)$exam->description);$lessonKinds=$lessons->map(fn($lesson)=>'lesson:'.$lesson->id)->all();$lessonMedia=$lessonKinds?DB::table('media_files')->whereIn('kind',$lessonKinds)->orderBy('id')->get()->groupBy('kind'):collect();$examKinds=$exams->map(fn($exam)=>'exam:'.$exam->id)->all();$examMedia=$examKinds?DB::table('media_files')->whereIn('kind',$examKinds)->orderBy('id')->get()->groupBy('kind'):collect();$progress=DB::table('learning_progress')->where('ambassador_id',$user->id)->pluck('completed','learning_content_id');return view('member.learning',compact('lessons','exams','progress','lessonMedia','examMedia'));
    }
    public function rewards() { $rows=DB::table('rewards')->where('status','active')->latest()->paginate(20);$balance=(int)$this->eligiblePointQuery((int)auth()->id())->sum('points.points');return view('member.rewards',compact('rows','balance')); }
    public function points() { $rows=$this->eligiblePointQuery((int)auth()->id())->select('points.*')->latest('points.id')->paginate(30);$balance=(int)$this->eligiblePointQuery((int)auth()->id())->sum('points.points');return view('member.points',compact('rows','balance')); }
    public function notices() { $rows=DB::table('notices')->where('is_published',true)->latest()->get();foreach($rows as $notice)$notice->body=app(\App\Services\RichTextService::class)->sanitize((string)$notice->body);$noticeKinds=$rows->map(fn($notice)=>'notice:'.$notice->id)->all();$noticeMedia=$noticeKinds?DB::table('media_files')->whereIn('kind',$noticeKinds)->orderBy('id')->get()->groupBy('kind'):collect();return view('member.notices',compact('rows','noticeMedia')); }
    public function referrals() { $rows=Referral::where('referrer_id',auth()->id())->latest()->paginate(20);return view('member.referrals',compact('rows')); }
    public function feedback()
    {
        $rows=DB::table('feedback_tickets')->where('ambassador_id',auth()->id())->latest()->paginate(20);
        $messages=DB::table('feedback_messages')->whereIn('ticket_id',$rows->pluck('id'))->orderBy('id')->get()->groupBy('ticket_id');
        return view('member.feedback',compact('rows','messages'));
    }
    public function feedbackCreate(Request $request)
    {
        $d=$request->validate(['subject'=>'required|string|max:190','message'=>'required|string|max:10000']);
        $ticket=DB::table('feedback_tickets')->insertGetId(['ambassador_id'=>auth()->id(),'subject'=>$d['subject'],'status'=>'open','priority'=>'normal','created_at'=>now(),'updated_at'=>now()]);
        DB::table('feedback_messages')->insert(['ticket_id'=>$ticket,'sender_id'=>auth()->id(),'body'=>$d['message'],'created_at'=>now(),'updated_at'=>now()]);
        $this->audit('feedback.created',(string)$ticket);return back()->with('success','پیام شما برای مدیریت ارسال شد.');
    }
    public function feedbackReply(Request $request,int $id)
    {
        $ticket=DB::table('feedback_tickets')->where('id',$id)->where('ambassador_id',auth()->id())->first();abort_unless($ticket,404);abort_if($ticket->status!=='open',422,'این گفت‌وگو بسته شده است.');
        $d=$request->validate(['message'=>'required|string|max:10000']);DB::table('feedback_messages')->insert(['ticket_id'=>$id,'sender_id'=>auth()->id(),'body'=>$d['message'],'created_at'=>now(),'updated_at'=>now()]);DB::table('feedback_tickets')->where('id',$id)->update(['updated_at'=>now()]);$this->audit('feedback.replied',(string)$id);return back()->with('success','پیام ارسال شد.');
    }
    public function adminFeedbackIndex()
    {
        $this->assertStaffModule('feedback');
        $rows=DB::table('feedback_tickets')->join('users','users.id','=','feedback_tickets.ambassador_id')->select('feedback_tickets.*','users.name as representative_name','users.mobile')->orderByRaw("CASE WHEN feedback_tickets.status='open' THEN 0 ELSE 1 END")->latest('feedback_tickets.updated_at')->paginate(30);
        $routePrefix=auth()->user()->role==='admin_staff'?'staff':'admin';
        return view('admin.feedback-index',compact('rows','routePrefix'));
    }
    public function adminFeedbackReply(Request $request,int $id)
    {
        $this->assertStaffModule('feedback');
        $ticket=DB::table('feedback_tickets')->where('id',$id)->first();abort_unless($ticket,404);abort_if($ticket->status!=='open',422,'برای ادامهٔ گفتگو ابتدا تیکت را دوباره باز کنید.');$d=$request->validate(['message'=>'required|string|max:10000']);
        DB::table('feedback_messages')->insert(['ticket_id'=>$id,'sender_id'=>auth()->id(),'body'=>$d['message'],'created_at'=>now(),'updated_at'=>now()]);DB::table('feedback_tickets')->where('id',$id)->update(['updated_at'=>now()]);return back()->with('success','پاسخ ارسال شد.');
    }
    public function adminFeedbackStatus(Request $request,int $id)
    {
        $this->assertStaffModule('feedback');
        $d=$request->validate(['status'=>'required|in:open,closed,pending']);DB::table('feedback_tickets')->where('id',$id)->update(['status'=>$d['status'],'updated_at'=>now()]);return back()->with('success','وضعیت گفتگو به‌روزرسانی شد.');
    }
    public function adminFeedbackShow(int $id)
    {
        $this->assertStaffModule('feedback');
        $ticket=DB::table('feedback_tickets')->join('users','users.id','=','feedback_tickets.ambassador_id')->where('feedback_tickets.id',$id)->select('feedback_tickets.*','users.name as representative_name','users.mobile')->first();abort_unless($ticket,404);$messages=DB::table('feedback_messages')->where('ticket_id',$id)->join('users','users.id','=','feedback_messages.sender_id')->select('feedback_messages.*','users.name as sender_name','users.role as sender_role')->orderBy('feedback_messages.id')->get();return view('admin.feedback-show',compact('ticket','messages'));
    }
    public function aiChat(Request $request,AiService $ai)
    {
        $data=$request->validate(['question'=>'required|string|max:5000']);try{$answer=$ai->reply((int)auth()->id(),$data['question']);$this->audit('ai.question.sent',mb_substr($data['question'],0,120));if($request->expectsJson())return response()->json(['ok'=>true,'question'=>$data['question'],'answer'=>$answer,'created_at'=>now()->format('Y/m/d H:i')]);return redirect()->route('member.assistant')->with('success','پاسخ در تاریخچهٔ گفتگو ذخیره شد.');}catch(\Throwable $e){if($request->expectsJson())return response()->json(['ok'=>false,'message'=>$e->getMessage()],422);return back()->withErrors(['question'=>$e->getMessage()])->withInput();}
    }
    public function aiConversations(Request $request)
    {
        $search=trim((string)$request->query('q',''));$query=DB::table('ai_chat_history')->join('users','users.id','=','ai_chat_history.ambassador_id')->where('users.role','ambassador')->select('users.id','users.name','users.mobile','users.email',DB::raw('COUNT(ai_chat_history.id) as exchange_count'),DB::raw('MAX(ai_chat_history.created_at) as last_message_at'))->groupBy('users.id','users.name','users.mobile','users.email');
        if($search!=='')$query->where(function($q)use($search){$q->where('users.name','like','%'.$search.'%')->orWhere('users.mobile','like','%'.$search.'%')->orWhere('users.email','like','%'.$search.'%');});$representatives=$query->orderByDesc('last_message_at')->paginate(20)->withQueryString();return view('admin.ai-conversations',compact('representatives','search'));
    }
    public function aiConversation(int $ambassadorId)
    {
        $representative=User::where('role','ambassador')->findOrFail($ambassadorId);$exchanges=DB::table('ai_chat_history')->where('ambassador_id',$ambassadorId)->orderByDesc('id')->paginate(30)->withQueryString();$exchanges->setCollection($exchanges->getCollection()->reverse()->values());return view('admin.ai-conversation',compact('representative','exchanges'));
    }
    public function profile(Request $request)
    {
        $user=auth()->user();if($request->isMethod('post')){$d=$request->validate(['first_name'=>'required|string|max:100','last_name'=>'required|string|max:100','mobile'=>'required|regex:/^09\d{9}$/|unique:users,mobile,'.$user->id,'province'=>'required|string|max:100','city'=>'required|string|max:100','address'=>'required|string|max:3000','postal_code'=>'nullable|regex:/^\d{10}$/','no_postal_code'=>'nullable|boolean','primary_segment'=>'nullable|string|max:80','secondary_segments'=>'nullable|array','secondary_segments.*'=>'string|max:80','profile_photo'=>'nullable|image|mimes:jpg,jpeg,png,webp|max:5120']);abort_unless(in_array($d['city'],config('peyvand_geo.'.$d['province'],[]),true),422,'استان یا شهر انتخاب‌شده معتبر نیست.');$d['no_postal_code']=$request->boolean('no_postal_code');if($d['no_postal_code'])$d['postal_code']='';$d['secondary_segments']=array_values(array_unique(array_filter(array_merge($d['secondary_segments']??[],[$d['primary_segment']??'']))));$photo=$d['profile_photo']??null;unset($d['profile_photo']);$d['name']=$d['first_name'].' '.$d['last_name'];$user->fill($d)->save();if($photo){$key='representative_profile_photo_'.$user->id;$oldPath=(string)self::setting($key,'');$newPath=$photo->store('srm/profile-photos','local');if(!$newPath)return back()->withErrors(['profile_photo'=>'ذخیرهٔ تصویر پروفایل انجام نشد.']);try{$this->saveSetting($key,$newPath);}catch(\Throwable $error){Storage::disk('local')->delete($newPath);throw $error;}if($oldPath!==''&&$oldPath!==$newPath)Storage::disk('local')->delete($oldPath);}$this->audit('profile.updated');return back()->with('success','پروفایل ذخیره شد.');}$provinces=array_keys(config('peyvand_geo'));$segments=$this->segments();$profilePhotoPath=(string)self::setting('representative_profile_photo_'.$user->id,'');$hasProfilePhoto=$profilePhotoPath!==''&&Storage::disk('local')->exists($profilePhotoPath);return view('member.profile',compact('user','provinces','segments','hasProfilePhoto'));
    }
    public function memberProfilePhoto()
    {
        $path=(string)self::setting('representative_profile_photo_'.auth()->id(),'');abort_unless($path!==''&&Storage::disk('local')->exists($path),404);$mime=Storage::disk('local')->mimeType($path)?:'application/octet-stream';abort_unless(in_array($mime,['image/jpeg','image/png','image/webp'],true),404);return Storage::disk('local')->response($path,basename($path),['Content-Type'=>$mime,'Cache-Control'=>'private, max-age=300'],'inline');
    }
    public function changePassword(Request $request)
    {
        if($request->isMethod('post')){$d=$request->validate(['current_password'=>'required|string','password'=>'required|string|min:10|confirmed']);abort_unless(Hash::check($d['current_password'],auth()->user()->password),422,'رمز فعلی نادرست است.');auth()->user()->forceFill(['password'=>$d['password'],'password_change_required'=>false])->save();$this->audit('account.password_changed');return redirect()->route('member.dashboard')->with('success','رمز عبور تغییر کرد.');}return view('member.password');
    }
    public function uploadProjectMedia(Request $request,int $id)
    {
        $project=Project::where('id',$id)->where('ambassador_id',auth()->id())->firstOrFail();$d=$request->validate(['file'=>'required|file|max:20480|mimes:jpg,jpeg,png,webp,mp4,pdf,zip,doc,docx']);$file=$d['file'];$path=$file->store('srm/projects/'.$project->id,'local');
        $media=DB::table('media_files')->insertGetId(['ambassador_id'=>auth()->id(),'project_id'=>$project->id,'storage_key'=>$path,'original_name'=>$file->getClientOriginalName(),'mime_type'=>$file->getMimeType()?:'application/octet-stream','file_size'=>$file->getSize(),'sha256'=>hash_file('sha256',$file->getRealPath()),'kind'=>'project','review_status'=>'pending','created_at'=>now(),'updated_at'=>now()]);
        DB::table('project_media')->insert(['project_id'=>$project->id,'media_file_id'=>$media,'caption'=>$request->input('caption'),'created_at'=>now(),'updated_at'=>now()]);$this->audit('project.media.uploaded',$project->id.':'.$file->getClientOriginalName());return back()->with('success','فایل به پرونده پروژه افزوده شد.');
    }
    public function downloadMedia(int $id)
    {
        $media=$this->accessibleMedia($id);abort_unless(Storage::disk('local')->exists($media->storage_key),404);return Storage::disk('local')->download($media->storage_key,$media->original_name);
    }

    public function previewMedia(int $id)
    {
        $media=$this->accessibleMedia($id);abort_unless(preg_match('#^(image/(jpeg|png|gif|webp)|video/(mp4|webm))$#',$media->mime_type)===1,415);abort_unless(Storage::disk('local')->exists($media->storage_key),404);
        return Storage::disk('local')->response($media->storage_key,$media->original_name,['Content-Type'=>$media->mime_type,'X-Content-Type-Options'=>'nosniff'],'inline');
    }

    private function accessibleMedia(int $id): object
    {
        $media=DB::table('media_files')->find($id);abort_unless($media,404);$user=auth()->user();if($user->role==='admin')return $media;
        if($user->role==='admin_staff'){$module=$media->project_id!==null?'projects':($media->ambassador_id!==null?'media':(str_starts_with($media->kind,'lesson:')?'learning':(str_starts_with($media->kind,'notice:')?'notices':(str_starts_with($media->kind,'exam:')?'exams':'media'))));$this->assertStaffModule($module);return $media;}
        if($media->ambassador_id!==null){abort_unless((int)$media->ambassador_id===(int)$user->id,403);return $media;}
        if(preg_match('/^(lesson|notice|exam):(\d+)$/',$media->kind,$match)===1){$table=match($match[1]){'lesson'=>'learning_contents','notice'=>'notices',default=>'exams'};abort_unless(DB::table($table)->where('id',(int)$match[2])->where('is_published',true)->exists(),404);return $media;}
        abort(403);
    }
    public function purchaseReportStore(Request $request,int $id)
    {
        $project=Project::where('id',$id)->where('ambassador_id',auth()->id())->firstOrFail();$d=$request->validate(['note'=>'required|string|max:10000','documents'=>'nullable|array','documents.*'=>'file|max:20480|mimes:pdf,jpg,jpeg,png,webp,doc,docx,xls,xlsx']);$report=DB::table('purchase_reports')->insertGetId(['project_id'=>$id,'ambassador_id'=>auth()->id(),'note'=>$d['note'],'status'=>'pending','created_at'=>now(),'updated_at'=>now()]);$this->awardActivityPoints((int)$project->ambassador_id,'purchase_report','ثبت گزارش خرید یا فروش','#'.$report,(int)$project->id);
        foreach($request->file('documents',[]) as $file){$path=$file->store('srm/purchase-docs/'.$id,'local');DB::table('purchase_documents')->insert(['report_id'=>$report,'project_id'=>$id,'ambassador_id'=>auth()->id(),'storage_key'=>$path,'original_name'=>$file->getClientOriginalName(),'mime_type'=>$file->getMimeType()?:'application/octet-stream','file_size'=>$file->getSize(),'sha256'=>hash_file('sha256',$file->getRealPath()),'created_at'=>now()]);}
        app(NotificationService::class)->admins('purchase_report_submitted','گزارش خرید جدید برای پروژه '.$project->title);return back()->with('success','گزارش خرید و مدارک ثبت شد.');
    }
    public function downloadPurchaseDocument(int $id)
    {
        $doc=DB::table('purchase_documents')->find($id);abort_unless($doc,404);if(auth()->user()->role==='admin_staff')$this->assertStaffModule('purchase-documents');elseif(auth()->user()->role!=='admin')abort_unless((int)$doc->ambassador_id===(int)auth()->id(),403);abort_unless(Storage::disk('local')->exists($doc->storage_key),404);return Storage::disk('local')->download($doc->storage_key,$doc->original_name);
    }
    public function notifications()
    {
        $rows=DB::table('notifications')->where('ambassador_id',auth()->id())->latest()->paginate(30);
        DB::table('notifications')->where('ambassador_id',auth()->id())->whereNull('read_at')->update(['read_at'=>now()]);return view('member.notifications',compact('rows'));
    }

    public function adminNotificationFeed(Request $request)
    {
        $recipient='admin:'.auth()->id();
        $query=DB::table('notifications')->where('recipient',$recipient);
        $unread=(clone $query)->whereNull('read_at')->count();
        $rows=$query->latest('id')->limit(10)->get(['id','event_key','message','read_at','created_at']);
        return response()->json(['unread'=>$unread,'notifications'=>$rows]);
    }

    public function markAdminNotificationRead(int $id)
    {
        DB::table('notifications')->where('id',$id)->where('recipient','admin:'.auth()->id())->whereNull('read_at')->update(['read_at'=>now(),'updated_at'=>now()]);
        return response()->json(['ok'=>true]);
    }

    public function markAllAdminNotificationsRead()
    {
        DB::table('notifications')->where('recipient','admin:'.auth()->id())->whereNull('read_at')->update(['read_at'=>now(),'updated_at'=>now()]);
        return response()->json(['ok'=>true]);
    }

    public function accountProfile(Request $request)
    {
        $user=auth()->user();
        $key='representative_profile_photo_'.$user->id;
        if($request->isMethod('post')){
            if($request->boolean('change_password')){
                $passwordData=$request->validate(['current_password'=>'required|string','password'=>'required|string|min:10|confirmed']);
                abort_unless(Hash::check($passwordData['current_password'],$user->password),422,'رمز عبور فعلی نادرست است.');
                $user->forceFill(['password'=>$passwordData['password'],'password_change_required'=>false])->save();
                $this->audit('account.password_changed');
                return back()->with('success','رمز عبور با موفقیت تغییر کرد.');
            }
            $data=$request->validate(['name'=>'required|string|max:190','email'=>'nullable|email|max:190|unique:users,email,'.$user->id,'profile_photo'=>'nullable|image|mimes:jpg,jpeg,png,webp|max:5120']);
            $user->name=$data['name'];
            if(array_key_exists('email',$data))$user->email=$data['email']??null;
            $user->save();
            if($request->hasFile('profile_photo')){
                $old=(string)self::setting($key,'');$path=$request->file('profile_photo')->store('srm/profile-photos','local');
                if(!$path)return back()->withErrors(['profile_photo'=>'ذخیرهٔ تصویر پروفایل انجام نشد.']);
                $this->saveSetting($key,$path);
                if($old!==''&&$old!==$path)Storage::disk('local')->delete($old);
            }
            $this->audit('profile.updated');
            return back()->with('success','پروفایل ذخیره شد.');
        }
        $path=(string)self::setting($key,'');$hasProfilePhoto=$path!==''&&Storage::disk('local')->exists($path);
        $photoRoute=match($user->role){'admin_staff'=>'staff.profile.photo','supervisor'=>'supervisor.profile.photo',default=>'admin.profile.photo'};
        return view('account.profile',compact('user','hasProfilePhoto','photoRoute'));
    }

    public function brandLogo()
    {
        $path=(string)self::setting('system_brand_logo','');
        abort_unless($path!==''&&Storage::disk('local')->exists($path),404);
        $mime=Storage::disk('local')->mimeType($path)?:'application/octet-stream';
        abort_unless(in_array($mime,['image/jpeg','image/png','image/webp'],true),404);
        return Storage::disk('local')->response($path,basename($path),['Content-Type'=>$mime,'Cache-Control'=>'private, max-age=300'],'inline');
    }
    public function assistant()
    {
        $history=DB::table('ai_chat_history')->where('ambassador_id',auth()->id())->orderByDesc('id')->paginate(20)->withQueryString();$history->setCollection($history->getCollection()->reverse()->values());return view('member.assistant',compact('history'));
    }

    public function settings(Request $request)
    {
        if($request->isMethod('post')){
            $section=(string)$request->input('section','');$values=[];
            if($section==='general'){
                $request->validate(['segments'=>'required|string|max:12000','project_stages'=>'required|string|max:12000','project_processes'=>'nullable|string|max:12000','low_activity_months'=>'required|integer|between:1,60','inactive_months'=>'required|integer|between:1,120','brand_name'=>'nullable|string|max:100','brand_tagline'=>'nullable|string|max:160','brand_logo'=>'nullable|image|mimes:jpg,jpeg,png,webp|max:2048']);
                foreach(['segments','project_stages','project_processes'] as $key){$list=$this->parseSettingLines((string)$request->input($key,''));if(($key!=='project_processes'&&!$list)||count($list)>100||collect($list)->contains(fn($item)=>mb_strlen($item)>80))return back()->withErrors([$key=>'برای این فهرست حداکثر ۱۰۰ عبارت با طول حداکثر ۸۰ نویسه وارد کنید.'])->withInput();$values[$key]=json_encode($list,JSON_UNESCAPED_UNICODE);}
                $processes=json_decode($values['project_processes'],true)?:[];$enabled=$request->boolean('project_processes_enabled');if($enabled&&!$processes)return back()->withErrors(['project_processes'=>'برای فعال‌کردن انتخاب فرایند، ابتدا دست‌کم یک فرایند تعریف کنید.'])->withInput();
                $values['project_processes_enabled']=$enabled?'1':'0';$values['low_activity_months']=(string)$request->input('low_activity_months');$values['inactive_months']=(string)$request->input('inactive_months');$values['require_registration_exam']=$request->boolean('require_registration_exam')?'1':'0';
                $values['system_brand_name']=trim((string)$request->input('brand_name',''))?:'پیوند';$values['system_brand_tagline']=trim((string)$request->input('brand_tagline',''));
                if($request->hasFile('brand_logo')){$oldLogo=(string)self::setting('system_brand_logo','');$newLogo=$request->file('brand_logo')->store('srm/branding','local');if(!$newLogo)return back()->withErrors(['brand_logo'=>'ذخیرهٔ لوگوی برند انجام نشد.'])->withInput();$values['system_brand_logo']=$newLogo;if($oldLogo!==''&&$oldLogo!==$newLogo)Storage::disk('local')->delete($oldLogo);}
            }elseif($section==='sms'){
                $request->validate(['sms_provider'=>'required|in:kavenegar,smsir,ippanel,farazsms,melipayamak,ghasedak,first_portal,parsgreen','sms_api_key'=>'nullable|string|max:2048','sms_username'=>'nullable|string|max:190','sms_password'=>'nullable|string|max:2048','sms_line_number'=>'nullable|string|max:100']);
                $values=$request->only(['sms_provider','sms_api_key','sms_username','sms_password','sms_line_number']);$values['sms_enabled']=$request->boolean('sms_enabled')?'1':'0';
            }elseif($section==='ai'){
                $request->validate(['ai_api_key'=>'nullable|string|max:2048','ai_model'=>'nullable|string|max:190','ai_daily_limit'=>'required|integer|between:1,100000','ai_max_output_tokens'=>'required|integer|between:1,100000','ai_timeout'=>'required|integer|between:1,180','ai_knowledge_notes'=>'nullable|string|max:20000']);
                $values=$request->only(['ai_api_key','ai_model','ai_daily_limit','ai_max_output_tokens','ai_timeout','ai_knowledge_notes']);$values['ai_enabled']=$request->boolean('ai_enabled')?'1':'0';
            }elseif($section==='points'){
                $activities=['project'=>'ثبت پروژه','purchase_report'=>'ثبت گزارش خرید یا فروش','learning'=>'تکمیل آموزش','exam'=>'تکمیل آزمون','invitation'=>'معرفی همکاری جدید از طریق دعوت','registration'=>'ثبت‌نام'];$input=$request->input('activity_points',[]);if(!is_array($input))return back()->withErrors(['activity_points'=>'مقادیر امتیاز معتبر نیستند.'])->withInput();$configured=[];
                foreach($activities as $key=>$label){$raw=trim((string)($input[$key]??''));if($raw!==''&&(!ctype_digit($raw)||(int)$raw>100000))return back()->withErrors(['activity_points.'.$key=>'برای «'.$label.'» عددی بین صفر تا ۱۰۰٬۰۰۰ وارد کنید یا فیلد را خالی بگذارید.'])->withInput();$configured[$key]=$raw;}
                $values['activity_points']=json_encode($configured,JSON_UNESCAPED_UNICODE);
            }elseif($section==='ranks'){
                $request->validate(['ranks'=>'required|array|min:1|max:50','ranks.*.title'=>'required|string|max:80','ranks.*.min'=>'required|integer|min:0|max:100000000','ranks.*.max'=>'nullable|integer|min:0|max:100000000']);$ranks=[];$names=[];
                foreach($request->input('ranks',[]) as $index=>$rank){$title=trim((string)$rank['title']);$min=(int)$rank['min'];$max=isset($rank['max'])&&$rank['max']!==''?(int)$rank['max']:null;if($max!==null&&$max<$min)return back()->withErrors(['ranks.'.$index.'.max'=>'بازهٔ «تا» باید برابر یا بزرگ‌تر از «از» باشد.'])->withInput();$nameKey=mb_strtolower($title);if(isset($names[$nameKey]))return back()->withErrors(['ranks.'.$index.'.title'=>'نام رتبه‌ها باید یکتا باشد.'])->withInput();$names[$nameKey]=true;$ranks[]=['title'=>$title,'min'=>$min,'max'=>$max];}
                usort($ranks,fn($a,$b)=>$a['min']<=>$b['min']);if($ranks[0]['min']!==0)return back()->withErrors(['ranks'=>'بازهٔ اولین رتبه باید از صفر شروع شود.'])->withInput();foreach($ranks as $index=>$rank){$isLast=$index===count($ranks)-1;if(!$isLast&&($rank['max']===null||$ranks[$index+1]['min']!==$rank['max']+1))return back()->withErrors(['ranks'=>'بازه‌ها باید پیوسته باشند؛ بازهٔ بعدی از یک امتیاز پس از پایان بازهٔ قبلی آغاز می‌شود.'])->withInput();if($isLast&&$rank['max']!==null)return back()->withErrors(['ranks'=>'فیلد «تا» برای آخرین رتبه را خالی بگذارید تا رتبهٔ همهٔ امتیازهای بالاتر مشخص باشد.'])->withInput();}
                $values['ranks']=json_encode($ranks,JSON_UNESCAPED_UNICODE);
            }else{return back()->withErrors(['section'=>'بخش تنظیمات معتبر نیست.'])->withInput();}

            foreach($values as $key=>$value){if(in_array($key,['sms_api_key','sms_password','ai_api_key'],true)){if(trim((string)$value)==='')continue;$value=Crypt::encryptString((string)$value);}DB::table('srm_settings')->updateOrInsert(['key'=>$key],['value'=>is_array($value)?json_encode($value,JSON_UNESCAPED_UNICODE):$value,'updated_at'=>now(),'created_at'=>now()]);}
            if($section==='ai')DB::table('srm_settings')->whereIn('key',['ai_endpoint','ai_request_mode'])->delete();
            $this->audit('settings.updated',$section);return back()->with('success','تنظیمات این بخش ذخیره شد.');
        }
        $values=DB::table('srm_settings')->whereNotIn('key',['sms_api_key','sms_password','ai_api_key'])->pluck('value','key')->all();
        foreach(['segments','project_stages','project_processes'] as $key){$values[$key]=implode("\n",$this->parseSettingLines((string)($values[$key]??'')));}
        if(trim((string)$values['project_stages'])==='')$values['project_stages']=implode("\n",['سرنخ جدید','ارزیابی نیاز','ارائه پیشنهاد','مذاکره','فروش قطعی','تکمیل پروژه']);
        $legacyStageLabels=['new'=>'سرنخ جدید','qualified'=>'ارزیابی نیاز','proposal'=>'ارائه پیشنهاد','negotiation'=>'مذاکره','purchased'=>'فروش قطعی','completed'=>'تکمیل پروژه'];$stageLines=explode("\n",(string)$values['project_stages']);$values['project_stages']=implode("\n",array_map(fn($stage)=>$legacyStageLabels[$stage]??$stage,$stageLines));
        $values['ranks']=$this->normalizedRanks($values['ranks']??'[]')?:[['title'=>'عادی','min'=>0,'max'=>null]];$values['activity_points']=json_decode((string)($values['activity_points']??'{}'),true)?:[];
        if(!in_array($values['sms_provider']??'kavenegar',['kavenegar','smsir','ippanel','farazsms','melipayamak','ghasedak','first_portal','parsgreen'],true))$values['sms_provider']='kavenegar';
        $activityLabels=['project'=>'ثبت پروژه','purchase_report'=>'ثبت گزارش خرید یا فروش','learning'=>'تکمیل آموزش','exam'=>'تکمیل آزمون','invitation'=>'معرفی همکاری جدید از طریق دعوت','registration'=>'ثبت‌نام'];
        return view('admin.settings',compact('values','activityLabels'));
    }

    private function parseSettingLines(string $raw): array
    {
        $decoded=json_decode($raw,true);$items=is_array($decoded)?$decoded:(preg_split('/[\r\n,،]+/u',$raw)?:[]);$items=array_map(fn($item)=>trim((string)(is_array($item)?($item['label']??$item['key']??''):$item)," \t\n\r\0\x0B"),$items);return array_values(array_unique(array_filter($items,fn($item)=>$item!=='')));
    }

    private function normalizedRanks(string $raw): array
    {
        $ranks=json_decode($raw,true);if(!is_array($ranks))return [];$normalized=[];foreach($ranks as $rank){if(!is_array($rank))continue;$title=trim((string)($rank['title']??$rank['name']??''));if($title==='')continue;$normalized[]=['title'=>$title,'min'=>(int)($rank['min']??$rank['from']??0),'max'=>isset($rank['max'])&&$rank['max']!==''?(int)($rank['max']??0):(isset($rank['to'])&&$rank['to']!==''?(int)$rank['to']:null)];}usort($normalized,fn($a,$b)=>$a['min']<=>$b['min']);return $normalized;
    }

    private function awardActivityPoints(int $ambassadorId,string $activity,string $label,string $reference,?int $projectId=null): void
    {
        $settings=json_decode((string)self::setting('activity_points','{}'),true)?:[];$raw=$settings[$activity]??'';if($raw===''||!is_numeric($raw)||(int)$raw<=0)return;$reason=mb_substr($label.' ('.$reference.')',0,190);$exists=DB::table('points')->where('ambassador_id',$ambassadorId)->where('source','activity')->where('reason',$reason)->exists();if($exists)return;Point::create(['ambassador_id'=>$ambassadorId,'project_id'=>$projectId,'points'=>(int)$raw,'reason'=>$reason,'source'=>'activity','created_by'=>null]);
    }

    private function eligiblePointQuery(int $ambassadorId)
    {
        $query=DB::table('points')->leftJoin('projects','projects.id','=','points.project_id')->where('points.ambassador_id',$ambassadorId);
        return $query->where(function($q){$q->where('points.source','!=','activity')->orWhereNull('points.project_id')->orWhere('points.reason','not like','ثبت پروژه (%')->orWhereNull('projects.id')->orWhereIn('projects.status',['approved','active','completed']);if(Schema::hasTable('project_status_history'))$q->orWhereExists(function($history){$history->selectRaw('1')->from('project_status_history')->whereColumn('project_status_history.project_id','points.project_id')->whereIn('project_status_history.to_status',['approved','active','completed']);});});
    }

    private function rankTitleFor(User $user): string
    {
        $points=(int)$this->eligiblePointQuery((int)$user->id)->sum('points.points');$ranks=$this->normalizedRanks((string)self::setting('ranks','[]'));foreach($ranks as $rank)if($points>=$rank['min']&&($rank['max']===null||$points<=$rank['max']))return $rank['title'];return 'بدون رتبه';
    }

    private function projectStages(): array
    {
        return $this->parseSettingLines((string)self::setting('project_stages','["سرنخ جدید","ارزیابی نیاز","ارائه پیشنهاد","مذاکره","فروش قطعی","تکمیل پروژه"]'))?:['سرنخ جدید','ارزیابی نیاز','ارائه پیشنهاد','مذاکره','فروش قطعی','تکمیل پروژه'];
    }

    public function aiModels(Request $request)
    {
        $request->validate(['api_key'=>'nullable|string|max:2048']);$apiKey=trim((string)$request->input('api_key',''));
        if($apiKey==='')$apiKey=(string)self::setting('ai_api_key','');
        abort_if($apiKey==='',422,'ابتدا کلید API هوش مصنوعی را وارد کنید.');
        $status=0;$body=false;
        if(function_exists('curl_init')){
            $client=curl_init('https://api.heroai.ir/ai/models');
            curl_setopt_array($client,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPGET=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$apiKey,'Accept: application/json'],CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>20,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
            $body=curl_exec($client);$status=(int)curl_getinfo($client,CURLINFO_HTTP_CODE);curl_close($client);
        }else{
            $context=stream_context_create(['http'=>['method'=>'GET','header'=>'Authorization: Bearer '.$apiKey."\r\nAccept: application/json\r\n",'timeout'=>20,'ignore_errors'=>true],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
            $body=@file_get_contents('https://api.heroai.ir/ai/models',false,$context);
            foreach($http_response_header??[] as $header)if(preg_match('/^HTTP\/\S+\s+(\d{3})/i',$header,$match))$status=(int)$match[1];
        }
        if($body===false||$status===0)return response()->json(['message'=>'اتصال به HeroAI.ir برقرار نشد. اتصال خروجی هاست را بررسی کنید.'],422);
        if($status<200||$status>=300)return response()->json(['message'=>'HeroAI.ir فهرست مدل‌ها را با خطای '.$status.' برگرداند. کلید API را بررسی کنید.'],422);
        $payload=json_decode((string)$body,true);$items=is_array($payload)?($payload['data']??[]):[];
        $models=collect(is_array($items)?$items:[])->map(fn($item)=>is_array($item)?(string)($item['id']??''):'')->filter(fn($id)=>$id!=='')->unique()->sort()->values();
        if($models->isEmpty())return response()->json(['message'=>'مدلی برای این کلید API دریافت نشد.'],422);
        return response()->json(['models'=>$models]);
    }
    private function supervisorRecord(): object
    {
        $account=auth()->user();abort_unless($account&&$account->role==='supervisor'&&$account->supervisor_id,403);
        $supervisor=DB::table('supervisors')->where('id',$account->supervisor_id)->where('status','active')->first();abort_unless($supervisor,403,'حساب سرپرست غیرفعال است.');return $supervisor;
    }
    private function supervisorTeamIds(): array
    {
        $supervisor=$this->supervisorRecord();return User::where('role','ambassador')->where('supervisor_id',$supervisor->id)->pluck('id')->all();
    }
    private function supervisorReportData(string $type)
    {
        $team=$this->supervisorTeamIds();$typeAliases=['sales'=>'sales','projects'=>'sales','activity'=>'activity','exams'=>'exams','learning'=>'learning'];abort_unless(isset($typeAliases[$type]),404);$type=$typeAliases[$type];
        if($type==='sales')return DB::table('purchase_reports')->join('projects','projects.id','=','purchase_reports.project_id')->join('users','users.id','=','purchase_reports.ambassador_id')->whereIn('purchase_reports.ambassador_id',$team)->select('purchase_reports.id','projects.title','purchase_reports.status','projects.stage','projects.estimated_amount','purchase_reports.created_at','users.name as ambassador_name')->latest('purchase_reports.id');
        if($type==='activity')return DB::table('audit_logs')->join('users','users.id','=','audit_logs.user_id')->whereIn('audit_logs.user_id',$team)->select('audit_logs.id','audit_logs.event_key as operation','audit_logs.details','audit_logs.created_at','users.name as ambassador_name')->latest('audit_logs.id');
        if($type==='exams')return DB::table('exam_attempts')->join('users','users.id','=','exam_attempts.ambassador_id')->leftJoin('exams','exams.id','=','exam_attempts.exam_id')->whereIn('exam_attempts.ambassador_id',$team)->select('exam_attempts.id','exams.title','exam_attempts.score','exam_attempts.passed','exam_attempts.submitted_at as created_at','users.name as ambassador_name')->latest('exam_attempts.id');
        return DB::table('learning_progress')->join('users','users.id','=','learning_progress.ambassador_id')->leftJoin('learning_contents','learning_contents.id','=','learning_progress.learning_content_id')->whereIn('learning_progress.ambassador_id',$team)->select('learning_progress.id','learning_contents.title','learning_progress.progress_percent','learning_progress.completed','learning_progress.updated_at as created_at','users.name as ambassador_name')->latest('learning_progress.id');
    }
    private function supervisorReportTitle(string $type): string { return ['sales'=>'گزارش فروش و پروژه‌ها','projects'=>'گزارش فروش و پروژه‌ها','activity'=>'گزارش فعالیت‌ها','exams'=>'گزارش آزمون‌ها','learning'=>'گزارش آموزش‌ها'][$type]??'گزارش'; }
    public function supervisorDashboard()
    {
        $this->audit('supervisor.dashboard.viewed');
        $team=$this->supervisorTeamIds();$stats=['ambassadors'=>count($team),'projects'=>DB::table('projects')->whereIn('ambassador_id',$team)->count(),'sales'=>DB::table('purchase_reports')->whereIn('ambassador_id',$team)->count(),'exam_attempts'=>DB::table('exam_attempts')->whereIn('ambassador_id',$team)->count(),'learning'=>DB::table('learning_progress')->whereIn('ambassador_id',$team)->count()];
        $months=collect(range(5,0))->map(fn($offset)=>now()->startOfMonth()->subMonths($offset));$all=DB::table('projects')->whereIn('ambassador_id',$team)->where('created_at','>=',$months->first())->get(['created_at','estimated_amount']);$byMonth=$all->groupBy(fn($row)=>substr((string)$row->created_at,0,7));$chartMonths=$months->map(fn($month)=>['label'=>$month->format('m/Y'),'projects'=>($byMonth[$month->format('Y-m')]??collect())->count(),'sales'=>(float)($byMonth[$month->format('Y-m')]??collect())->sum('estimated_amount')])->values();$projectStatuses=DB::table('projects')->whereIn('ambassador_id',$team)->select('status',DB::raw('COUNT(*) as total'))->groupBy('status')->get();return view('supervisor.dashboard',compact('stats','chartMonths','projectStatuses'));
    }
    public function supervisorReport(string $type)
    {
        $this->audit('supervisor.report.viewed',$type);
        $query=$this->supervisorReportData($type);$rows=$query->paginate(30)->withQueryString();$title=$this->supervisorReportTitle($type);return view('supervisor.report',compact('rows','type','title'));
    }
    public function supervisorReportCsv(string $type)
    {
        $this->audit('supervisor.report.csv_exported',$type);
        $query=$this->supervisorReportData($type);$rows=$query->get();$title=$this->supervisorReportTitle($type);$file='report-'.$type.'-'.now()->format('Ymd-His').'.csv';
        return response()->streamDownload(function()use($rows,$type){$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");$headers=match($type){'sales','projects'=>['نماینده','پروژه','وضعیت','مرحله','مبلغ برآوردی','تاریخ'],'activity'=>['نماینده','نوع عملیات','شرح','تاریخ'],'exams'=>['نماینده','آزمون','امتیاز','قبولی','تاریخ'],default=>['نماینده','آموزش','پیشرفت','تکمیل','تاریخ']};fputcsv($out,$headers);foreach($rows as $r){$line=match($type){'sales','projects'=>[$r->ambassador_name,$r->title,$r->status,$r->stage,$r->estimated_amount,$r->created_at],'activity'=>[$r->ambassador_name,$r->operation,$r->details,$r->created_at],'exams'=>[$r->ambassador_name,$r->title,$r->score,$r->passed?'بله':'خیر',$r->created_at],default=>[$r->ambassador_name,$r->title,$r->progress_percent,$r->completed?'بله':'خیر',$r->created_at]};fputcsv($out,array_map(fn($v)=>preg_match('/^[=+@\-]/u',(string)$v)?"'".$v:$v,$line));}fclose($out);},$file,['Content-Type'=>'text/csv; charset=UTF-8']);
    }
    public function supervisorReportPdf(string $type)
    {
        $this->audit('supervisor.report.pdf_exported',$type);
        $rows=$this->supervisorReportData($type)->get();$title=$this->supervisorReportTitle($type);return view('supervisor.report-print',compact('rows','type','title'));
    }
    public function supervisorReportForm()
    {
        $team=$this->supervisorTeamIds();$ambassadors=User::whereIn('id',$team)->orderBy('name')->get(['id','name']);$projects=DB::table('projects')->whereIn('ambassador_id',$team)->orderByDesc('id')->limit(300)->get(['id','title','ambassador_id']);return view('supervisor.activity-report',compact('ambassadors','projects'));
    }
    public function supervisorReportStore(Request $request)
    {
        $team=$this->supervisorTeamIds();$d=$request->validate(['activity_type'=>'required|in:project,sale,activity,exam,learning,other','ambassador_id'=>'required|integer|in:'.(implode(',',$team)?:'0'),'project_id'=>'nullable|integer','note'=>'required|string|max:10000']);if(!empty($d['project_id']))abort_unless(DB::table('projects')->where('id',$d['project_id'])->whereIn('ambassador_id',$team)->exists(),403);
        $payload=['activity_type'=>$d['activity_type'],'ambassador_id'=>(int)$d['ambassador_id'],'project_id'=>isset($d['project_id'])?(int)$d['project_id']:null,'note'=>$d['note']];DB::table('events')->insert(['user_id'=>auth()->id(),'event_key'=>'supervisor.report','payload'=>json_encode($payload,JSON_UNESCAPED_UNICODE),'created_at'=>now()]);$this->audit('supervisor.report.created',json_encode($payload,JSON_UNESCAPED_UNICODE));return redirect()->route('supervisor.activity-report')->with('success','گزارش برای مدیران کل ارسال شد.');
    }
    public function supervisorReports()
    {
        $rows=DB::table('events')->join('users','users.id','=','events.user_id')->where('events.event_key','supervisor.report')->select('events.*','users.name as supervisor_name')->latest('events.id')->paginate(30);foreach($rows as $row){$row->report=json_decode((string)$row->payload,true)?:[];$row->report['ambassador_name']=User::whereKey($row->report['ambassador_id']??0)->value('name')??'—';$row->report['project_title']=DB::table('projects')->where('id',$row->report['project_id']??0)->value('title')??'';}return view('admin.supervisor-reports',compact('rows'));
    }
    public function auditLogs(Request $request)
    {
        $query=DB::table('audit_logs')->leftJoin('users','users.id','=','audit_logs.user_id')->select('audit_logs.*','users.name');
        foreach(['from'=>'>=','to'=>'<='] as $key=>$operator){$value=trim((string)$request->query($key,''));if($value==='')continue;$date=JalaliDate::toGregorianDate($value);if(!$date){return back()->withErrors([$key=>'تاریخ شمسی معتبر وارد کنید (نمونه: ۱۴۰۵/۰۷/۲۴).'])->withInput();}$query->whereDate('audit_logs.created_at',$operator,$date);}
        if($request->filled('supervisor'))$query->where('audit_logs.user_id',$request->integer('supervisor'));if($request->filled('operation'))$query->where('audit_logs.event_key',$request->query('operation'));
        $rows=$query->latest('audit_logs.id')->paginate(50)->withQueryString();$supervisors=User::where('role','supervisor')->orderBy('name')->get(['id','name']);$operations=DB::table('audit_logs')->select('event_key')->distinct()->orderBy('event_key')->pluck('event_key');return view('admin.audit',compact('rows','supervisors','operations'));
    }
    public function backup(SrmBackupService $backups)
    {
        $files=$backups->files();$frequency=(string)self::setting('backup_frequency','off');$token=(string)self::setting('backup_cron_token','');
        $scheduleUrl=$token!==''?route('backup.schedule',['token'=>$token]):null;
        return view('admin.backup',compact('files','frequency','scheduleUrl'));
    }
    public function updatePage() { return view('admin.update'); }
    public function bannersIndex()
    {
        $segments=$this->segmentChoices();$banners=$this->representativeBanners();$rows=[];
        foreach($banners as $scope=>$banner){if(!is_array($banner)||empty($banner['path']))continue;$rows[]=['scope'=>(string)$scope,'label'=>$scope==='*'?'همهٔ نمایندگان':($segments[$scope]??$scope),'updated_at'=>$banner['updated_at']??null,'image_url'=>route('admin.banners.image',['scope'=>$scope])];}
        return view('admin.banners',compact('segments','rows'));
    }
    public function uploadBanner(Request $request)
    {
        $data=$request->validate(['scope'=>'required|string|max:100','banner'=>'required|image|mimes:jpg,jpeg,png|max:5120|dimensions:width=1064,height=120'],['banner.dimensions'=>'ابعاد تصویر باید دقیقاً ۱۰۶۴ در ۱۲۰ پیکسل باشد.','banner.mimes'=>'فرمت بنر باید JPG یا PNG باشد.','banner.max'=>'حجم بنر نباید بیشتر از ۵ مگابایت باشد.']);
        $scope=(string)$data['scope'];$segments=$this->segmentChoices();if($scope!=='*'&&!array_key_exists($scope,$segments))return back()->withErrors(['scope'=>'زمینهٔ فعالیت انتخاب‌شده معتبر نیست.'])->withInput();
        $banners=$this->representativeBanners();$oldPath=(string)($banners[$scope]['path']??'');$path=$data['banner']->store('srm/banners','local');if(!$path)return back()->withErrors(['banner'=>'ذخیرهٔ فایل بنر انجام نشد.'])->withInput();
        try{$banners[$scope]=['path'=>$path,'mime_type'=>$data['banner']->getMimeType()?:'image/jpeg','original_name'=>$data['banner']->getClientOriginalName(),'updated_at'=>now()->toIso8601String()];$this->saveSetting('representative_banners',json_encode($banners,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));}catch(\Throwable $error){Storage::disk('local')->delete($path);throw $error;}
        if($oldPath!==''&&$oldPath!==$path)Storage::disk('local')->delete($oldPath);$this->audit('banner.uploaded',$scope);return redirect()->route('admin.banners.index')->with('success','بنر با موفقیت ذخیره و برای نمایندگان انتخاب‌شده فعال شد.');
    }
    public function deleteBanner(Request $request)
    {
        $scope=(string)$request->validate(['scope'=>'required|string|max:100'])['scope'];$banners=$this->representativeBanners();abort_unless(isset($banners[$scope]),404);$path=(string)($banners[$scope]['path']??'');unset($banners[$scope]);$this->saveSetting('representative_banners',json_encode($banners,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));if($path!=='')Storage::disk('local')->delete($path);$this->audit('banner.deleted',$scope);return redirect()->route('admin.banners.index')->with('success','بنر حذف شد.');
    }
    public function adminBannerImage(Request $request)
    {
        $scope=(string)$request->query('scope','');$banners=$this->representativeBanners();abort_unless(isset($banners[$scope]),404);return $this->bannerFileResponse($banners[$scope]);
    }
    public function memberBannerImage()
    {
        $scope=$this->representativeBannerScope(auth()->user());abort_if($scope===null,404);$banners=$this->representativeBanners();return $this->bannerFileResponse($banners[$scope]);
    }
    private function bannerFileResponse(array $banner)
    {
        $path=(string)($banner['path']??'');abort_unless($path!==''&&Storage::disk('local')->exists($path),404);$mime=(string)($banner['mime_type']??'image/jpeg');abort_unless(in_array($mime,['image/jpeg','image/png'],true),404);return Storage::disk('local')->response($path,basename($path),['Content-Type'=>$mime,'Cache-Control'=>'private, max-age=300'],'inline');
    }
    private function representativeBanners(): array
    {
        $banners=json_decode((string)self::setting('representative_banners','{}'),true);return is_array($banners)?$banners:[];
    }
    private function representativeBannerScope(User $user): ?string
    {
        $banners=$this->representativeBanners();$segments=array_values(array_unique(array_filter(array_merge([(string)$user->primary_segment],is_array($user->secondary_segments)?$user->secondary_segments:[]))));foreach($segments as $segment)if(isset($banners[$segment]['path']))return (string)$segment;return isset($banners['*']['path'])?'*':null;
    }
    private function segmentChoices(): array
    {
        $choices=[];foreach($this->segments() as $segment){if(is_array($segment)){$key=trim((string)($segment['key']??$segment['label']??''));$label=trim((string)($segment['label']??$key));}else{$key=trim((string)$segment);$label=$key;}if($key!=='')$choices[$key]=$label;}return $choices;
    }
    public function uploadUpdate(Request $request, SrmUpdateService $updates)
    {
        $data=$request->validate(['package'=>'required|file|max:102400|mimes:zip','password'=>'required|string']);
        abort_unless(Hash::check($data['password'],auth()->user()->password),403,'رمز مدیر درست نیست.');
        return response()->json($updates->stage($data['package']));
    }
    public function advanceUpdate(string $id, SrmUpdateService $updates)
    {
        return response()->json($updates->advance($id));
    }
    public function createBackup(SrmBackupService $backups)
    {
        $filename=$backups->create();$this->audit('backup.created',$filename);
        return back()->with('success','نسخهٔ پشتیبان ساخته شد.');
    }
    public function updateBackupSchedule(Request $request)
    {
        $frequency=$request->validate(['frequency'=>'required|in:off,daily,weekly,monthly'])['frequency'];
        $token=(string)self::setting('backup_cron_token','');if($token==='')$token=Str::random(64);
        $this->saveSetting('backup_frequency',$frequency);$this->saveSetting('backup_cron_token',$token);
        $this->audit('backup.schedule.updated',$frequency);
        return back()->with('success',$frequency==='off'?'پشتیبان‌گیری خودکار خاموش شد.':'زمان‌بندی پشتیبان‌گیری ذخیره شد.');
    }
    public function runScheduledBackup(string $token,SrmBackupService $backups)
    {
        $saved=(string)self::setting('backup_cron_token','');abort_unless($saved!==''&&hash_equals($saved,$token),404);
        $frequency=(string)self::setting('backup_frequency','off');if($frequency==='off')return response()->json(['status'=>'disabled']);
        $last=(string)self::setting('backup_last_at','');$lastAt=$last!==''?\Illuminate\Support\Carbon::parse($last):null;
        $due=$lastAt===null||match($frequency){'daily'=>$lastAt->lt(now()->startOfDay()),'weekly'=>$lastAt->lt(now()->subDays(7)),'monthly'=>$lastAt->lt(now()->subMonth()),default=>false};
        if(!$due)return response()->json(['status'=>'not_due']);
        $filename=$backups->create();$this->saveSetting('backup_last_at',now()->toIso8601String());$this->audit('backup.created.automatic',$filename);
        return response()->json(['status'=>'created','filename'=>$filename]);
    }
    public function downloadBackup(string $filename,SrmBackupService $backups)
    {
        return Storage::disk('local')->download($backups->path($filename),$filename,['Content-Type'=>'application/json']);
    }
    public function deleteBackup(string $filename,SrmBackupService $backups)
    {
        Storage::disk('local')->delete($backups->path($filename));$this->audit('backup.deleted',$filename);
        return back()->with('success','فایل پشتیبان حذف شد.');
    }
    public function restoreSavedBackup(Request $request,string $filename,SrmBackupService $backups)
    {
        $d=$request->validate(['confirmation'=>'required|in:RESTORE','password'=>'required|string']);abort_unless(Hash::check($d['password'],auth()->user()->password),403,'رمز مدیر درست نیست.');
        $backups->restore($backups->read($filename));$this->audit('backup.restore',$filename);
        return redirect()->route('admin.dashboard')->with('success','پشتیبان بازیابی شد.');
    }
    public function restoreBackup(Request $request,SrmBackupService $backups)
    {
        $d=$request->validate(['backup'=>'required|file|max:51200|mimes:json','confirmation'=>'required|in:RESTORE','password'=>'required|string']);abort_unless(Hash::check($d['password'],auth()->user()->password),403,'رمز مدیر درست نیست.');$json=json_decode(file_get_contents($d['backup']->getRealPath()),true);abort_unless(is_array($json)&&is_array($json['data']??null),422,'فایل پشتیبان معتبر نیست.');
        $backups->restore($json);$this->audit('backup.restore',$d['backup']->getClientOriginalName());return redirect()->route('admin.dashboard')->with('success','پشتیبان بازیابی شد.');
    }

    private function saveSetting(string $key,string $value): void
    {
        DB::table('srm_settings')->updateOrInsert(['key'=>$key],['value'=>$value,'updated_at'=>now(),'created_at'=>now()]);
    }

    private function module(string $key): array { abort_unless(isset(self::MODULES[$key]),404);return self::MODULES[$key]+['key'=>$key]; }
    private function digits(string $value): string
    {
        return strtr(preg_replace('/[^0-9۰-۹٠-٩]/u','',$value)??'',array_combine(preg_split('//u','۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩',-1,PREG_SPLIT_NO_EMPTY),str_split('01234567890123456789')));
    }
    private function activeProjectForm(User $user): ?object
    {
        $forms=DB::table('project_forms')->where('status','active')->orderByDesc('id')->get();$fallback=null;$segments=array_unique(array_filter(array_merge([$user->primary_segment],$user->secondary_segments??[])));
        foreach($forms as $form){$targets=json_decode($form->target_segments,true)?:[];if($targets&&array_intersect($targets,$segments))return $form;if(!$targets&&($form->is_default||$fallback===null))$fallback=$form;}return $fallback;
    }
    private function projectFieldChoices(object $field): array
    {
        $raw=json_decode((string)$field->options,true)??[];
        if(!is_array($raw))return [];
        $choices=array_is_list($raw)?$raw:($raw['choices']??[]);
        return array_values(array_map(fn($choice)=>(string)(is_array($choice)?($choice['value']??$choice['label']??''):$choice),is_array($choices)?$choices:[]));
    }
    private function segments(): array
    {
        $raw=(string)self::setting('segments','["عمومی"]');$json=json_decode($raw,true);if(is_array($json)&&$json)return $json;return array_values(array_filter(array_map('trim',preg_split('/[\r\n,،]+/u',$raw)?:[])))?:['عمومی'];
    }
    private function options(string $module): array
    {
        $definitions=[
            'ambassador_id'=>['users','name','name','role','ambassador'],'supervisor_id'=>['supervisors','name','name',null,null],
            'project_id'=>['projects','title','id',null,null],'purchase_reports'=>['purchase_reports','note','id',null,null],
            'report_id'=>['purchase_reports','note','id',null,null],'reward_id'=>['rewards','title','title',null,null],
            'exam_id'=>['exams','title','title',null,null],'learning_content_id'=>['learning_contents','title','title',null,null],
        ];
        $tableOptions=static function(array $definition){[$table,$label,$order,$whereColumn,$whereValue]=$definition;
            if(!\Illuminate\Support\Facades\Schema::hasTable($table)||!\Illuminate\Support\Facades\Schema::hasColumn($table,'id')||!\Illuminate\Support\Facades\Schema::hasColumn($table,$label)||!\Illuminate\Support\Facades\Schema::hasColumn($table,$order)||($whereColumn!==null&&!\Illuminate\Support\Facades\Schema::hasColumn($table,$whereColumn)))return collect();
            $query=DB::table($table);if($whereColumn!==null)$query->where($whereColumn,$whereValue);return $query->orderBy($order)->limit(1000)->pluck($label,'id');
        };
        $fields=array_keys($this->module($module)['fields']);$options=[];
        foreach($fields as $field){if(!isset($definitions[$field]))continue;$key=match($field){'ambassador_id'=>'ambassadors','supervisor_id'=>'supervisors','project_id'=>'projects','report_id'=>'purchase_reports','reward_id'=>'rewards','exam_id'=>'exams','learning_content_id'=>'learning_contents',default=>$field};if(!array_key_exists($key,$options))$options[$key]=$tableOptions($definitions[$field]);}
        if($module==='projects')$options['stages']=$this->projectStages();
        return $options;
    }
    private function audit(string $key,string $details=''): void
    {
        try{
            $actor=auth()->user();
            DB::table('audit_logs')->insert(['user_id'=>$actor?->id,'event_key'=>$key,'details'=>$details,'ip'=>request()->ip()??'','created_at'=>now(),'updated_at'=>now()]);
            if($actor&&$actor->role!=='admin'&&!in_array($key,['ambassador.registered','project.updated','project.submitted'],true)){
                $detail=trim((string)$details);
                $message=$actor->name.' · '.app(NotificationService::class)->activityLabel($key).($detail!==''?' · '.$detail:'');
                app(NotificationService::class)->activity($key,$message,(int)$actor->id);
            }
        }catch(\Throwable $e){}
    }
    public static function setting(string $key,$default=null) { $value=DB::table('srm_settings')->where('key',$key)->value('value');if($value===null)return $default;if(in_array($key,['sms_api_key','sms_password','ai_api_key'],true)){try{return Crypt::decryptString($value);}catch(\Throwable $e){return '';}}return $value; }
}
