<?php

namespace App\Http\Controllers;

use App\Support\LocalErrorLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Throwable;

class SystemHealthController extends Controller
{
    public function index(Request $request)
    {
        $checks = [];
        $checks[] = $this->check('نسخه PHP', version_compare(PHP_VERSION, '8.3.0', '>='), 'PHP '.PHP_VERSION.' · حداقل نسخهٔ لازم 8.3 است.');
        foreach (['mbstring', 'openssl', 'fileinfo', 'PDO'] as $extension) {
            $checks[] = $this->check('افزونهٔ '.$extension, extension_loaded($extension), extension_loaded($extension) ? 'فعال است.' : 'در PHP فعال نیست.');
        }
        $checks[] = $this->check('پشتیبانی ZIP', class_exists(\ZipArchive::class), class_exists(\ZipArchive::class) ? 'بازکردن بسته‌های به‌روزرسانی فعال است.' : 'افزونهٔ ZIP در PHP فعال نیست.');
        $dbDriver = (string) config('database.connections.'.config('database.default').'.driver', 'mysql');
        $pdoExtension = ['mysql' => 'pdo_mysql', 'sqlite' => 'pdo_sqlite', 'pgsql' => 'pdo_pgsql', 'sqlsrv' => 'pdo_sqlsrv'][$dbDriver] ?? null;
        if ($pdoExtension !== null) {
            $checks[] = $this->check('درایور پایگاه‌داده', extension_loaded($pdoExtension), extension_loaded($pdoExtension) ? 'درایور '.$dbDriver.' فعال است.' : 'افزونهٔ '.$pdoExtension.' برای اتصال '.$dbDriver.' فعال نیست.');
        }
        $checks[] = $this->check('کلید رمزنگاری', trim((string) config('app.key')) !== '', trim((string) config('app.key')) !== '' ? 'APP_KEY تنظیم شده است.' : 'APP_KEY خالی است.');

        try {
            DB::connection()->select('SELECT 1');
            $checks[] = $this->check('اتصال پایگاه‌داده', true, 'اتصال و اجرای پرس‌وجوی آزمایشی موفق بود.');
        } catch (Throwable $error) {
            $checks[] = $this->check('اتصال پایگاه‌داده', false, 'اتصال ناموفق بود: '.$error->getMessage());
        }

        foreach (['users', 'password_reset_tokens', 'projects', 'project_forms', 'project_form_fields', 'project_status_history', 'srm_settings', 'audit_logs'] as $table) {
            try {
                $exists = Schema::hasTable($table);
                $checks[] = $this->check('جدول '.$table, $exists, $exists ? 'جدول در دسترس است.' : 'جدول پیدا نشد؛ مهاجرت‌های سامانه را بررسی کنید.');
            } catch (Throwable $error) {
                $checks[] = $this->check('جدول '.$table, false, $error->getMessage());
            }
        }
        foreach (['users' => ['mobile', 'national_id_hash', 'primary_segment', 'province', 'city'], 'project_forms' => ['target_segments', 'status'], 'project_form_fields' => ['form_id', 'field_key', 'type', 'sort_order']] as $table => $columns) {
            try {
                $missing = array_values(array_filter($columns, fn ($column) => ! Schema::hasColumn($table, $column)));
                $checks[] = $this->check('ستون‌های '.$table, $missing === [], $missing === [] ? 'ستون‌های اصلی موجود هستند.' : 'ستون‌های پیدا نشده: '.implode('، ', $missing));
            } catch (Throwable $error) {
                $checks[] = $this->check('ستون‌های '.$table, false, $error->getMessage());
            }
        }

        foreach ([storage_path('logs'), storage_path('framework/views'), storage_path('framework/cache'), storage_path('framework/sessions'), storage_path('app/private')] as $directory) {
            $checks[] = $this->writableDirectoryCheck($directory);
        }

        try {
            $logPath = LocalErrorLog::ensureFile();
            $logWritable = $logPath !== null && is_file($logPath) && @file_put_contents($logPath, '', FILE_APPEND | LOCK_EX) !== false;
        } catch (Throwable) {
            $logWritable = false;
        }
        $checks[] = $this->check('فایل ثبت خطا', $logWritable, $logWritable ? 'فایل محلی خطا ساخته شده و برای نوشتن باز می‌شود.' : 'فایل خطا ساخته یا نوشته نمی‌شود؛ مجوز storage/logs را بررسی کنید.');

        try {
            $cacheKey = 'srm:health:'.bin2hex(random_bytes(8));
            Cache::put($cacheKey, 'ok', 10);
            $cacheWorks = Cache::get($cacheKey) === 'ok';
            Cache::forget($cacheKey);
            $checks[] = $this->check('ذخیره‌سازی cache', $cacheWorks, $cacheWorks ? 'نوشتن و خواندن cache موفق بود.' : 'مقدار آزمایشی از cache خوانده نشد.');
        } catch (Throwable $error) {
            $checks[] = $this->check('ذخیره‌سازی cache', false, 'آزمون cache ناموفق بود: '.$error->getMessage());
        }

        $sessionDriver = (string) config('session.driver', 'file');
        try {
            $sessionReady = match ($sessionDriver) {
                'file' => is_dir(storage_path('framework/sessions')) && is_writable(storage_path('framework/sessions')),
                'database' => Schema::hasTable((string) config('session.table', 'sessions')),
                default => $sessionDriver !== '',
            };
        } catch (Throwable) {
            $sessionReady = false;
        }
        $checks[] = $this->check('تنظیم نشست کاربران', $sessionReady, 'درایور نشست: '.$sessionDriver.'.');

        $uploadLimit = $this->iniBytes((string) ini_get('upload_max_filesize'));
        $postLimit = $this->iniBytes((string) ini_get('post_max_size'));
        $uploadReady = $uploadLimit > 0 && $postLimit >= $uploadLimit;
        $checks[] = $this->check('حد بارگذاری فایل', $uploadReady, 'upload_max_filesize='.ini_get('upload_max_filesize').' · post_max_size='.ini_get('post_max_size').($uploadReady ? '' : ' · مقدار POST باید دست‌کم برابر حد فایل باشد.'));

        $mailer = (string) config('mail.default', 'log');
        $mailReady = $mailer !== '' && ($mailer !== 'smtp' || (string) config('mail.mailers.smtp.host', '') !== '');
        $mailStatus = $mailer === 'log' || $mailer === 'array' ? 'warning' : ($mailReady ? 'ok' : 'fail');
        $checks[] = ['label' => 'ارسال بازیابی رمز', 'status' => $mailStatus, 'details' => $mailer === 'log' || $mailer === 'array' ? 'درایور ایمیل روی '.$mailer.' است؛ ارسال واقعی ایمیل انجام نمی‌شود.' : ($mailReady ? 'درایور '.$mailer.' پیکربندی شده است؛ ارسال واقعی برای جلوگیری از پیام ناخواسته آزمایش نشد.' : 'تنظیمات SMTP ناقص است.')];

        $views = [
            'auth.login' => 'ورود', 'auth.register' => 'ثبت‌نام', 'auth.forgot-password' => 'فراموشی رمز', 'auth.reset-password' => 'تغییر رمز با پیوند بازیابی',
            'admin.dashboard' => 'پنل ادمین', 'admin.health' => 'تست سلامت سامانه', 'admin.banners' => 'مدیریت بنرها', 'admin.ai-conversations' => 'فهرست گفتگوهای AI', 'admin.ai-conversation' => 'متن گفتگوی AI', 'admin.project-form-builder' => 'فرم‌ساز پروژه', 'admin.module-form' => 'فرم مدیریت رکوردها',
            'staff.dashboard' => 'پنل همکار مدیر', 'supervisor.dashboard' => 'پنل سرپرست', 'member.dashboard' => 'پنل نماینده', 'member.assistant' => 'دستیار هوشمند نماینده',
        ];
        foreach ($views as $view => $label) {
            $path = resource_path('views/'.str_replace('.', DIRECTORY_SEPARATOR, $view).'.blade.php');
            $exists = is_file($path) && is_readable($path);
            $checks[] = $this->check('قالب '.$label, $exists, $exists ? 'فایل قالب موجود و خواندنی است.' : 'فایل قالب پیدا نشد یا قابل خواندن نیست.');
        }

        $endpoints = [
            ['label' => 'ورود', 'route' => 'login', 'role' => 'public'],
            ['label' => 'ثبت‌نام', 'route' => 'register', 'role' => 'public'],
            ['label' => 'فراموشی رمز', 'route' => 'password.request', 'role' => 'public'],
            ['label' => 'تغییر رمز با پیوند', 'route' => 'password.reset', 'role' => 'public', 'parameters' => ['token' => 'health-check-token']],
            ['label' => 'پنل ادمین', 'route' => 'admin.dashboard', 'role' => 'admin'],
            ['label' => 'تست سلامت سامانه', 'route' => 'admin.health', 'role' => 'admin'],
            ['label' => 'مدیریت بنرها', 'route' => 'admin.banners.index', 'role' => 'admin'],
            ['label' => 'گفتگوهای هوش مصنوعی', 'route' => 'admin.ai-conversations.index', 'role' => 'admin'],
            ['label' => 'افزودن فرم پروژه', 'route' => 'admin.modules.create', 'role' => 'admin', 'parameters' => ['module' => 'project-forms']],
            ['label' => 'افزودن نماینده', 'route' => 'admin.modules.create', 'role' => 'admin', 'parameters' => ['module' => 'ambassadors']],
            ['label' => 'پنل همکار مدیر', 'route' => 'staff.dashboard', 'role' => 'admin_staff'],
            ['label' => 'افزودن فرم پروژه برای همکار', 'route' => 'staff.modules.create', 'role' => 'admin_staff', 'parameters' => ['module' => 'project-forms']],
            ['label' => 'پنل سرپرست', 'route' => 'supervisor.dashboard', 'role' => 'supervisor'],
            ['label' => 'پنل نماینده', 'route' => 'member.dashboard', 'role' => 'ambassador'],
            ['label' => 'دستیار هوشمند نماینده', 'route' => 'member.assistant', 'role' => 'ambassador'],
        ];
        $routeChecks = [];
        foreach ($endpoints as $endpoint) {
            try {
                $registered = Route::has($endpoint['route']);
                $route = $registered ? Route::getRoutes()->getByName($endpoint['route']) : null;
                $url = $registered ? route($endpoint['route'], $endpoint['parameters'] ?? []) : '#';
                $action = $route?->getActionName();
                $controllerReady = is_string($action) && str_contains($action, '@')
                    ? class_exists(strstr($action, '@', true)) && method_exists(strstr($action, '@', true), substr(strstr($action, '@'), 1))
                    : $registered;
                $middlewareText = $route ? implode('|', $route->gatherMiddleware()) : '';
                $accessReady = $endpoint['role'] === 'public'
                    || ((str_contains($middlewareText, 'auth') || str_contains($middlewareText, 'Authenticate')) && str_contains($middlewareText, $endpoint['role']));
                $routeReady = $registered && $controllerReady && in_array('GET', $route->methods(), true) && $accessReady;
                $checks[] = $this->check('مسیر '.$endpoint['label'], $routeReady, $routeReady ? 'مسیر GET، کنترلر و محدودهٔ دسترسی ثبت شده‌اند.' : 'مسیر GET، کنترلر یا محدودیت نقش مورد انتظار پیدا نشد.');
                $routeChecks[] = $endpoint + ['url' => $url, 'registered' => $routeReady];
            } catch (Throwable $error) {
                $checks[] = $this->check('مسیر '.$endpoint['label'], false, $error->getMessage());
                $routeChecks[] = $endpoint + ['url' => '#', 'registered' => false];
            }
        }

        $failed = count(array_filter($checks, fn ($item) => $item['status'] === 'fail'));
        $warning = count(array_filter($checks, fn ($item) => $item['status'] === 'warning'));
        return view('admin.health', [
            'checks' => $checks,
            'routeChecks' => $routeChecks,
            'failedCount' => $failed,
            'warningCount' => $warning,
            'currentRole' => (string) $request->user()->role,
            'checkedAt' => now()->format('Y/m/d H:i:s'),
        ]);
    }

    private function check(string $label, bool $passed, string $details): array
    {
        return ['label' => $label, 'status' => $passed ? 'ok' : 'fail', 'details' => $details];
    }

    private function writableDirectoryCheck(string $directory): array
    {
        try {
            if (! is_dir($directory) && ! @mkdir($directory, 0775, true) && ! is_dir($directory)) {
                return $this->check('دسترسی نوشتن '.basename($directory), false, 'پوشه ساخته نشد: '.$directory);
            }
            $probe = rtrim($directory, DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.'.health-'.bin2hex(random_bytes(6)).'.tmp';
            $written = @file_put_contents($probe, 'ok', LOCK_EX);
            if ($written === false) {
                return $this->check('دسترسی نوشتن '.basename($directory), false, 'نوشتن در این مسیر ممکن نیست: '.$directory);
            }
            @unlink($probe);
            return $this->check('دسترسی نوشتن '.basename($directory), true, 'ساخت و حذف فایل آزمایشی موفق بود.');
        } catch (Throwable $error) {
            return $this->check('دسترسی نوشتن '.basename($directory), false, $error->getMessage());
        }
    }

    private function iniBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '' || $value === '0') {
            return PHP_INT_MAX;
        }
        $unit = strtolower(substr($value, -1));
        $number = (float) $value;
        return (int) match ($unit) {
            'g' => $number * 1024 * 1024 * 1024,
            'm' => $number * 1024 * 1024,
            'k' => $number * 1024,
            default => $number,
        };
    }
}
