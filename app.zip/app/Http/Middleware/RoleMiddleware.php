<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, string $role): Response
    {
        abort_unless($request->user() && $request->user()->role === $role, 403, 'دسترسی به این بخش مجاز نیست.');
        if ($role === 'ambassador' && $request->user()->password_change_required && !$request->routeIs('member.password')) {
            return redirect()->route('member.password');
        }
        return $next($request);
    }
}
