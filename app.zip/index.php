<?php

declare(strict_types=1);

// Harmless install-time probe used to check clean URL rewriting. The install
// lock disables it once setup has completed.
$probe = isset($_GET['__peyvand_rewrite_probe']) ? (string) $_GET['__peyvand_rewrite_probe'] : '';
if ($probe !== '' && !is_file(__DIR__.'/storage/app/installer.lock') && preg_match('/^[a-f0-9]{32}$/D', $probe)) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    echo 'PEYVAND_REWRITE_OK:'.$probe;
    exit;
}

require __DIR__.'/public/index.php';
