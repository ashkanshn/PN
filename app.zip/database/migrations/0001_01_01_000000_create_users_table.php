<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('first_name', 100)->default('');
            $table->string('last_name', 100)->default('');
            $table->string('email')->nullable()->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('role', 24)->default('ambassador')->index();
            $table->string('status', 24)->default('pending')->index();
            $table->string('mobile', 32)->nullable()->unique();
            $table->text('national_id')->nullable();
            $table->char('national_id_hash',64)->nullable()->unique();
            $table->string('province', 100)->default('');
            $table->string('city', 100)->default('');
            $table->text('address')->nullable();
            $table->string('postal_code', 20)->default('');
            $table->boolean('no_postal_code')->default(false);
            $table->string('primary_segment', 80)->default('');
            $table->json('secondary_segments')->nullable();
            $table->unsignedBigInteger('supervisor_id')->nullable()->index();
            $table->foreignId('referrer_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('referral_code', 32)->unique()->nullable();
            $table->boolean('password_change_required')->default(false);
            $table->timestamp('last_activity_at')->nullable();
            $table->softDeletes();
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
