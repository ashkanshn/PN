<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('supervisors', function (Blueprint $t) {
            $t->id(); $t->string('name'); $t->string('email')->nullable(); $t->string('mobile', 32)->nullable();
            $t->json('provinces')->nullable(); $t->string('status', 24)->default('active'); $t->timestamps();
        });
        Schema::create('projects', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete(); $t->string('title');
            $t->string('customer_name')->nullable(); $t->string('customer_mobile', 32)->nullable();
            $t->string('province', 100)->default(''); $t->string('city', 100)->default(''); $t->decimal('estimated_amount', 16, 2)->default(0);
            $t->string('stage', 80)->default('new'); $t->string('status', 24)->default('pending')->index();
            $t->text('manager_note')->nullable(); $t->json('form_values')->nullable(); $t->timestamp('submitted_at')->nullable(); $t->timestamps();
            $t->index(['ambassador_id','created_at']);
        });
        Schema::create('project_forms', function (Blueprint $t) {
            $t->id(); $t->string('name'); $t->string('status', 24)->default('active'); $t->json('target_segments')->nullable(); $t->boolean('is_default')->default(false); $t->timestamps();
        });
        Schema::create('project_form_fields', function (Blueprint $t) {
            $t->id(); $t->foreignId('form_id')->constrained('project_forms')->cascadeOnDelete(); $t->string('label'); $t->string('field_key');
            $t->string('type', 24)->default('text'); $t->json('options')->nullable(); $t->boolean('required')->default(false); $t->boolean('enabled')->default(true); $t->unsignedInteger('sort_order')->default(0); $t->timestamps();
        });
        Schema::create('purchase_reports', function (Blueprint $t) {
            $t->id(); $t->foreignId('project_id')->constrained()->cascadeOnDelete(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete();
            $t->text('note')->nullable(); $t->text('review_note')->nullable(); $t->string('status', 24)->default('pending')->index(); $t->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete(); $t->timestamp('reviewed_at')->nullable(); $t->timestamps();
        });
        Schema::create('purchase_documents', function (Blueprint $t) {
            $t->id(); $t->foreignId('report_id')->constrained('purchase_reports')->cascadeOnDelete(); $t->foreignId('project_id')->constrained()->cascadeOnDelete(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete();
            $t->string('storage_key')->unique(); $t->string('original_name'); $t->string('mime_type',100); $t->unsignedBigInteger('file_size')->default(0); $t->char('sha256',64); $t->timestamp('created_at')->useCurrent();
        });
        Schema::create('project_status_history', function (Blueprint $t) {
            $t->id(); $t->foreignId('project_id')->constrained()->cascadeOnDelete(); $t->string('from_status', 24)->nullable(); $t->string('to_status', 24); $t->text('note')->nullable(); $t->foreignId('changed_by')->nullable()->constrained('users')->nullOnDelete(); $t->timestamp('created_at')->useCurrent();
        });
        Schema::create('points', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete(); $t->foreignId('project_id')->nullable()->constrained()->nullOnDelete();
            $t->integer('points'); $t->string('reason', 190); $t->string('source', 32)->default('admin'); $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete(); $t->timestamps();
            $t->index(['ambassador_id','created_at']);
        });
        Schema::create('rewards', function (Blueprint $t) {
            $t->id(); $t->string('title'); $t->text('description')->nullable(); $t->unsignedInteger('points_required')->default(0); $t->unsignedInteger('stock')->default(0); $t->json('segments')->nullable(); $t->string('image_path')->nullable(); $t->string('status', 24)->default('active'); $t->timestamps();
        });
        Schema::create('redemptions', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete(); $t->foreignId('reward_id')->constrained()->restrictOnDelete(); $t->unsignedInteger('points_spent');
            $t->string('status', 24)->default('pending')->index(); $t->text('review_note')->nullable(); $t->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete(); $t->timestamp('reviewed_at')->nullable(); $t->timestamps();
        });
        Schema::create('learning_contents', function (Blueprint $t) {
            $t->id(); $t->string('title'); $t->longText('body')->nullable(); $t->string('type', 32)->default('general'); $t->string('video_url')->nullable(); $t->string('image_path')->nullable();
            $t->json('visibility_targets')->nullable(); $t->boolean('is_published')->default(false); $t->timestamp('published_at')->nullable(); $t->timestamps();
        });
        Schema::create('learning_progress', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete(); $t->foreignId('learning_content_id')->constrained()->cascadeOnDelete();
            $t->unsignedTinyInteger('progress_percent')->default(0); $t->boolean('completed')->default(false); $t->timestamp('completed_at')->nullable(); $t->timestamps(); $t->unique(['ambassador_id','learning_content_id']);
        });
        Schema::create('exams', function (Blueprint $t) {
            $t->id(); $t->string('title'); $t->longText('description')->nullable(); $t->json('questions'); $t->unsignedTinyInteger('pass_score')->default(70); $t->unsignedInteger('time_limit_minutes')->nullable();
            $t->unsignedInteger('max_attempts')->default(0); $t->json('visibility_targets')->nullable(); $t->string('type', 32)->default('regular'); $t->boolean('is_published')->default(false); $t->timestamps();
        });
        Schema::create('exam_attempts', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete(); $t->foreignId('exam_id')->constrained()->cascadeOnDelete();
            $t->json('answers')->nullable(); $t->unsignedTinyInteger('score')->default(0); $t->boolean('passed')->default(false); $t->unsignedInteger('duration_seconds')->default(0); $t->timestamp('started_at')->nullable(); $t->timestamp('submitted_at')->nullable(); $t->timestamps();
        });
        Schema::create('pre_registration_exam_sessions', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete(); $t->string('token_hash', 64)->unique(); $t->unsignedInteger('attempts')->default(0); $t->boolean('passed')->default(false); $t->json('last_wrong_questions')->nullable(); $t->timestamp('expires_at')->nullable(); $t->timestamp('passed_at')->nullable(); $t->timestamps();
        });
        Schema::create('referrals', function (Blueprint $t) {
            $t->id(); $t->foreignId('referrer_id')->constrained('users')->cascadeOnDelete(); $t->foreignId('referred_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('invited_name')->nullable(); $t->string('invited_phone', 32)->nullable(); $t->string('invite_code', 40)->unique(); $t->string('status', 24)->default('invited'); $t->timestamps();
        });
        Schema::create('notices', function (Blueprint $t) {
            $t->id(); $t->string('title'); $t->longText('body')->nullable(); $t->string('image_path')->nullable(); $t->string('video_url')->nullable(); $t->string('document_path')->nullable(); $t->json('visibility_targets')->nullable(); $t->boolean('is_pinned')->default(false); $t->boolean('is_published')->default(false); $t->timestamp('published_at')->nullable(); $t->timestamps();
        });
        Schema::create('notifications', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->nullable()->constrained('users')->cascadeOnDelete(); $t->string('channel', 24)->default('in_app'); $t->string('event_key', 80); $t->string('recipient')->nullable(); $t->text('message'); $t->timestamp('read_at')->nullable(); $t->timestamps();
        });
        Schema::create('sms_logs', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->nullable()->constrained('users')->nullOnDelete(); $t->string('provider', 40); $t->string('recipient', 32); $t->string('event_key', 80)->nullable(); $t->text('message')->nullable(); $t->string('status', 32)->default('queued'); $t->string('provider_message_id')->nullable(); $t->text('error')->nullable(); $t->timestamps();
        });
        Schema::create('feedback_tickets', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete(); $t->string('subject'); $t->string('status', 24)->default('open')->index(); $t->string('priority', 16)->default('normal'); $t->timestamps();
        });
        Schema::create('feedback_messages', function (Blueprint $t) {
            $t->id(); $t->foreignId('ticket_id')->constrained('feedback_tickets')->cascadeOnDelete(); $t->foreignId('sender_id')->constrained('users')->cascadeOnDelete(); $t->longText('body'); $t->timestamps();
        });
        Schema::create('media_files', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->nullable()->constrained('users')->cascadeOnDelete(); $t->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete(); $t->string('storage_key')->unique(); $t->string('original_name'); $t->string('mime_type', 100); $t->unsignedBigInteger('file_size')->default(0); $t->char('sha256',64); $t->string('kind',32)->default('file'); $t->string('review_status',24)->default('pending'); $t->timestamps();
        });
        Schema::create('project_media', function (Blueprint $t) {
            $t->id(); $t->foreignId('project_id')->constrained()->cascadeOnDelete(); $t->foreignId('media_file_id')->constrained('media_files')->cascadeOnDelete(); $t->string('caption')->nullable(); $t->timestamps();
        });
        Schema::create('ai_knowledge', function (Blueprint $t) {
            $t->id(); $t->string('title'); $t->longText('body'); $t->string('type',32)->default('product'); $t->boolean('is_published')->default(true); $t->timestamps();
        });
        Schema::create('ai_chat_history', function (Blueprint $t) {
            $t->id(); $t->foreignId('ambassador_id')->constrained('users')->cascadeOnDelete(); $t->json('messages'); $t->unsignedInteger('tokens_used')->default(0); $t->date('chat_date')->index(); $t->timestamps();
        });
        Schema::create('events', function (Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete(); $t->string('event_key',100); $t->json('payload')->nullable(); $t->timestamp('created_at')->useCurrent();
        });
        Schema::create('srm_settings', function (Blueprint $t) {
            $t->string('key',120)->primary(); $t->longText('value')->nullable(); $t->timestamps();
        });
        Schema::create('audit_logs', function (Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete(); $t->string('event_key',100); $t->text('details')->nullable(); $t->string('ip',45)->default(''); $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['audit_logs','srm_settings','events','ai_chat_history','ai_knowledge','project_media','media_files','feedback_messages','feedback_tickets','sms_logs','notifications','notices','referrals','pre_registration_exam_sessions','exam_attempts','exams','learning_progress','learning_contents','redemptions','rewards','points','project_status_history','purchase_documents','purchase_reports','project_form_fields','project_forms','projects','supervisors'] as $table) Schema::dropIfExists($table);
    }
};
