<?php $__env->startSection('content'); ?>
<?php
    $statusLabels=['open'=>'باز','closed'=>'بسته','pending'=>'در انتظار'];
?>
<section class="card">
    <div class="row spread"><div><h2>درخواست‌های نمایندگان</h2><p class="muted">پیام‌های ارسالی نمایندگان را بررسی کنید، پاسخ دهید یا وضعیت گفتگو را تغییر دهید.</p></div><span class="tag"><?php echo e(number_format($rows->total())); ?> درخواست</span></div>
    <div class="table-wrap"><table><thead><tr><th>موضوع</th><th>نماینده</th><th>وضعیت</th><th>آخرین به‌روزرسانی</th><th>گفتگو</th></tr></thead><tbody>
    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr><td><?php echo e($ticket->subject); ?></td><td><?php echo e($ticket->representative_name); ?><br><small class="muted" dir="ltr"><?php echo e($ticket->mobile); ?></small></td><td><span class="tag"><?php echo e($statusLabels[$ticket->status]??$ticket->status); ?></span></td><td><?php echo e($ticket->updated_at); ?></td><td><a class="btn alt" href="<?php echo e(route($routePrefix.'.feedback.show',$ticket->id)); ?>">مشاهده و پاسخ</a></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="5">هنوز درخواستی ارسال نشده است.</td></tr>
    <?php endif; ?>
    </tbody></table></div>
    <div class="pagination"><?php echo e($rows->links()); ?></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.srm',['title'=>'بازخورد و پشتیبانی'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/plugbini/public_html/p11/resources/views/admin/feedback-index.blade.php ENDPATH**/ ?>