<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

// Harmless install-time probe used to check clean URL rewriting.
$probe = isset($_GET['__peyvand_rewrite_probe']) ? (string) $_GET['__peyvand_rewrite_probe'] : '';
if ($probe !== '' && !is_file(__DIR__.'/../storage/app/installer.lock') && preg_match('/^[a-f0-9]{32}$/D', $probe)) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    echo 'PEYVAND_REWRITE_OK:'.$probe;
    exit;
}

define('LARAVEL_START', microtime(true));

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register the Composer autoloader...
require __DIR__.'/../vendor/autoload.php';

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once __DIR__.'/../bootstrap/app.php';

$app->handleRequest(Request::capture());
