<?php

// Standalone, staged installer. Keep this file compatible with PHP 7 syntax so
// an older web runtime can display a useful version blocker before Laravel loads.

$bootstrapErrorLog = __DIR__.'/storage/logs/installer-bootstrap.log';
register_shutdown_function(function () use ($bootstrapErrorLog) {
    $error = error_get_last();
    if (!$error || !in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR), true)) {
        return;
    }
    $reference = 'BOOT-'.strtoupper(substr(hash('sha256', $error['message'].'|'.$error['file'].'|'.$error['line']), 0, 10));
    if (is_dir(dirname($bootstrapErrorLog)) && is_writable(dirname($bootstrapErrorLog))) {
        @file_put_contents($bootstrapErrorLog, '['.date(DATE_ATOM).'] '.$reference.' '.$error['message'].' in '.$error['file'].':'.$error['line']."\n", FILE_APPEND | LOCK_EX);
    }
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: no-store');
    }
    echo 'نصاب پیش از نمایش صفحه با خطای PHP متوقف شد. شناسه: '.$reference.'. اگر فایل storage/logs/installer-bootstrap.log قابل‌نوشتن باشد، جزئیات در آن ثبت شده است.';
});

$base = __DIR__;
if (!is_file($base.'/artisan') || !is_file($base.'/vendor/autoload.php')) {
    $candidate = dirname(__DIR__);
    if (is_file($candidate.'/artisan') && is_file($candidate.'/vendor/autoload.php')) {
        $base = $candidate;
    }
}
$base = realpath($base) ?: $base;
$envPath = $base.'/.env';
$lockPath = $base.'/storage/app/installer.lock';
$pendingPath = $base.'/storage/app/installer.in-progress';
$requestMethod = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
$scriptName = isset($_SERVER['SCRIPT_NAME']) ? (string) $_SERVER['SCRIPT_NAME'] : '/setup.php';
$setupPath = str_replace('\\', '/', $scriptName);
$requestUri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
$requestPath = parse_url($requestUri, PHP_URL_PATH);
$currentRequestPath = is_string($requestPath) && $requestPath !== '' && isset($requestPath[0]) && $requestPath[0] === '/' ? $requestPath : $setupPath;
$host = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? (string) $_SERVER['SERVER_NAME'] : 'localhost');
if (!preg_match('/^(?:\[[0-9a-fA-F:]+\]|[A-Za-z0-9.-]+)(?::[0-9]{1,5})?$/D', $host)) {
    $host = isset($_SERVER['SERVER_NAME']) ? (string) $_SERVER['SERVER_NAME'] : 'localhost';
}
$https = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
    || (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443');
$scheme = $https ? 'https' : 'http';
$documentRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath((string) $_SERVER['DOCUMENT_ROOT']) : false;
$baseUrlPath = '';
if ($documentRoot && strpos($base, rtrim($documentRoot, DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR) === 0) {
    $relative = substr($base, strlen(rtrim($documentRoot, DIRECTORY_SEPARATOR)) + 1);
    $baseUrlPath = '/'.trim(str_replace(DIRECTORY_SEPARATOR, '/', $relative), '/');
    if ($baseUrlPath === '/') {
        $baseUrlPath = '';
    }
}
$baseUrl = $scheme.'://'.$host.$baseUrlPath;
$rewriteUrl = $baseUrlPath.'/__peyvand_rewrite_probe';
$setupUrlPath = $currentRequestPath;

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_name('peyvand_setup_v2');
    @session_start();
}
$sessionOk = session_status() === PHP_SESSION_ACTIVE;
if (!$sessionOk && $requestMethod === 'POST') {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'نصاب نتوانست نشست PHP را ایجاد کند. مسیر ذخیرهٔ session در تنظیمات PHP هاست باید قابل‌نوشتن باشد.';
    exit;
}
if ($sessionOk) {
    if (!isset($_SESSION['setup_csrf_v2']) || !is_string($_SESSION['setup_csrf_v2'])) {
        $_SESSION['setup_csrf_v2'] = bin2hex(random_bytes(32));
    }
    if (!isset($_SESSION['setup_rewrite_nonce']) || !is_string($_SESSION['setup_rewrite_nonce'])) {
        $_SESSION['setup_rewrite_nonce'] = bin2hex(random_bytes(16));
    }
}
$csrf = $sessionOk ? (string) $_SESSION['setup_csrf_v2'] : '';
$rewriteNonce = $sessionOk ? (string) $_SESSION['setup_rewrite_nonce'] : '';
$rewritePassed = $sessionOk && !empty($_SESSION['setup_rewrite_passed']);
$pendingVerify = $sessionOk && !empty($_SESSION['setup_pending_verify']);
$done = is_file($lockPath);
$errors = array();
$checks = array();
$blockers = 0;

$h = function ($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};
$addCheck = function ($label, $ok, $detail) use (&$checks, &$blockers) {
    $checks[] = array('label' => $label, 'ok' => (bool) $ok, 'detail' => (string) $detail);
    if (!$ok) {
        $blockers++;
    }
};
$probeWrite = function ($directory) {
    if (!is_dir($directory)) {
        return false;
    }
    $path = rtrim($directory, '/\\').DIRECTORY_SEPARATOR.'.peyvand-check-'.bin2hex(random_bytes(8));
    $handle = @fopen($path, 'x');
    if (!$handle) {
        return false;
    }
    $written = @fwrite($handle, 'ok');
    @fclose($handle);
    $removed = @unlink($path);
    return $written === 2 && $removed;
};
$logFailure = function ($reference, $message, $trace = '') use ($base) {
    $logDir = $base.'/storage/logs';
    if (is_dir($logDir) && is_writable($logDir)) {
        $record = '['.date(DATE_ATOM).'] '.$reference.' '.$message."\n".$trace."\n\n";
        @file_put_contents($logDir.'/installer.log', $record, FILE_APPEND | LOCK_EX);
    }
};

$phpVersionOk = PHP_VERSION_ID >= 80300;
$addCheck('نسخهٔ PHP وب', $phpVersionOk, PHP_VERSION.'؛ نیاز این بسته PHP 8.3 یا بالاتر است.');
$requiredExtensions = array('ctype', 'curl', 'dom', 'fileinfo', 'filter', 'hash', 'mbstring', 'openssl', 'pcre', 'pdo', 'pdo_mysql', 'session', 'tokenizer', 'xml');
$missingExtensions = array();
foreach ($requiredExtensions as $extension) {
    if (!extension_loaded($extension)) {
        $missingExtensions[] = $extension;
    }
}
$addCheck('افزونه‌های PHP', count($missingExtensions) === 0, count($missingExtensions) ? 'غیرفعال: '.implode(', ', $missingExtensions) : 'همهٔ افزونه‌های موردنیاز فعال‌اند.');

$requiredFiles = array(
    'artisan' => $base.'/artisan',
    'Composer autoload' => $base.'/vendor/autoload.php',
    'Laravel bootstrap' => $base.'/bootstrap/app.php',
    'ورودی public' => $base.'/public/index.php',
    'قواعد .htaccess ریشه' => $base.'/.htaccess',
    'قواعد .htaccess پوشه public' => $base.'/public/.htaccess',
    'migration سامانه' => $base.'/database/migrations/2026_10_12_000001_create_peyvand_srm_tables.php',
);
$missingFiles = array();
foreach ($requiredFiles as $name => $path) {
    if (!is_file($path) || !is_readable($path)) {
        $missingFiles[] = $name;
    }
}
$addCheck('فایل‌های برنامه', count($missingFiles) === 0, count($missingFiles) ? 'ناقص یا غیرقابل‌خواندن: '.implode(', ', $missingFiles) : 'فایل‌های اصلی و migration موجودند.');

$dependencyOk = false;
$dependencyDetail = 'بارگذاری Laravel در بررسی اولیه انجام نمی‌شود تا صفحهٔ نصب سبک و مستقل از حافظهٔ موردنیاز برنامه بماند.';
if ($phpVersionOk && count($missingExtensions) === 0 && is_file($base.'/vendor/autoload.php') && is_readable($base.'/vendor/autoload.php')) {
    $dependencyFiles = array(
        $base.'/vendor/composer/autoload_real.php',
        $base.'/vendor/laravel/framework/src/Illuminate/Foundation/Application.php',
        $base.'/vendor/monolog/monolog/src/Monolog/Logger.php',
        $base.'/vendor/symfony/service-contracts/ResetInterface.php',
        $base.'/app/Models/User.php',
    );
    $dependencyMissing = array();
    foreach ($dependencyFiles as $dependencyFile) {
        if (!is_file($dependencyFile) || !is_readable($dependencyFile)) {
            $dependencyMissing[] = basename($dependencyFile);
        }
    }
    $dependencyOk = count($dependencyMissing) === 0;
    $dependencyDetail = $dependencyOk
        ? 'فایل‌های اصلی Laravel، Monolog، Symfony و مدل مدیر موجودند؛ بارگذاری چارچوب در مرحلهٔ نصب انجام می‌شود.'
        : 'فایل‌های وابستگی ناقص یا غیرقابل‌خواندن‌اند: '.implode(', ', $dependencyMissing);
}
$addCheck('وابستگی‌های Composer', $dependencyOk, $dependencyDetail);

$directories = array(
    'ریشهٔ پروژه برای ساخت .env' => $base,
    'storage/app برای قفل نصب' => $base.'/storage/app',
    'storage/logs برای گزارش خطا' => $base.'/storage/logs',
    'storage/framework/cache/data' => $base.'/storage/framework/cache/data',
    'storage/framework/sessions' => $base.'/storage/framework/sessions',
    'storage/framework/views' => $base.'/storage/framework/views',
    'bootstrap/cache' => $base.'/bootstrap/cache',
);
foreach ($directories as $label => $directory) {
    $ok = $probeWrite($directory);
    $addCheck('دسترسی نوشتن: '.$label, $ok, $ok ? 'نوشتن و پاک‌کردن فایل آزمایشی موفق بود.' : 'PHP نتوانست در این پوشه فایل آزمایشی بسازد و پاک کند.');
}
$addCheck('نشست PHP', $sessionOk, $sessionOk ? 'نشست برای محافظت از فرم نصب فعال است.' : 'PHP نتوانست نشست را شروع کند؛ مسیر session در تنظیمات هاست را بررسی کنید.');
$addCheck('نشانی نصب', filter_var($baseUrl, FILTER_VALIDATE_URL) !== false, $baseUrl);

if ($sessionOk && $requestMethod === 'POST') {
    $postedToken = isset($_POST['_token']) ? (string) $_POST['_token'] : '';
    if (!hash_equals($csrf, $postedToken)) {
        $errors[] = 'نشست نصب منقضی یا نامعتبر است. صفحه را تازه‌سازی کنید.';
    } else {
        $action = isset($_POST['action']) ? (string) $_POST['action'] : '';
        if ($action === 'record_rewrite_probe') {
            $postedNonce = isset($_POST['nonce']) ? (string) $_POST['nonce'] : '';
            if (hash_equals($rewriteNonce, $postedNonce)) {
                $_SESSION['setup_rewrite_passed'] = true;
                session_write_close();
                http_response_code(204);
                exit;
            }
            http_response_code(400);
            exit('probe token mismatch');
        }
        if ($action === 'finalize') {
            if (!$pendingVerify || empty($_POST['health_ok'])) {
                http_response_code(409);
                $errors[] = 'بررسی نهایی مسیر وب موفق اعلام نشده است؛ نصب هنوز قفل نشده.';
            } else {
                $lockContent = 'installed '.date(DATE_ATOM).PHP_EOL;
                if (@file_put_contents($lockPath, $lockContent, LOCK_EX) === false) {
                    $reference = 'FINALIZE-'.strtoupper(bin2hex(random_bytes(4)));
                    $logFailure($reference, 'Could not write installer lock: '.$lockPath);
                    http_response_code(500);
                    $errors[] = 'برنامه بالا آمد، اما نوشتن قفل نصب در storage/app ممکن نشد. شناسهٔ گزارش: '.$reference;
                } else {
                    $_SESSION['setup_pending_verify'] = false;
                    $_SESSION['setup_complete'] = true;
                    @unlink($pendingPath);
                    $done = true;
                }
            }
        } elseif ($action === 'install') {
            if ($done) {
                $errors[] = 'این برنامه قبلاً نصب شده است.';
            } elseif ($blockers > 0 || !$rewritePassed) {
                $errors[] = 'تا زمانی که همهٔ بررسی‌های سرور و بازنویسی مسیرها موفق نشده‌اند، نصب شروع نمی‌شود.';
            } else {
                $dbHost = trim(isset($_POST['db_host']) ? (string) $_POST['db_host'] : '127.0.0.1');
                $dbPort = trim(isset($_POST['db_port']) ? (string) $_POST['db_port'] : '3306');
                $dbName = trim(isset($_POST['db_database']) ? (string) $_POST['db_database'] : '');
                $dbUser = trim(isset($_POST['db_username']) ? (string) $_POST['db_username'] : '');
                $dbPass = isset($_POST['db_password']) ? (string) $_POST['db_password'] : '';
                $first = trim(isset($_POST['first_name']) ? (string) $_POST['first_name'] : '');
                $last = trim(isset($_POST['last_name']) ? (string) $_POST['last_name'] : '');
                $email = trim(isset($_POST['email']) ? (string) $_POST['email'] : '');
                $password = isset($_POST['admin_password']) ? (string) $_POST['admin_password'] : '';
                $confirmation = isset($_POST['admin_password_confirmation']) ? (string) $_POST['admin_password_confirmation'] : '';
                $mailer = isset($_POST['mail_mailer']) ? (string) $_POST['mail_mailer'] : 'log';
                $mailHost = trim(isset($_POST['mail_host']) ? (string) $_POST['mail_host'] : '');
                $mailPort = trim(isset($_POST['mail_port']) ? (string) $_POST['mail_port'] : '587');
                $mailUser = trim(isset($_POST['mail_username']) ? (string) $_POST['mail_username'] : '');
                $mailPass = isset($_POST['mail_password']) ? (string) $_POST['mail_password'] : '';
                $mailFrom = trim(isset($_POST['mail_from']) ? (string) $_POST['mail_from'] : '');
                $mailScheme = isset($_POST['mail_scheme']) ? (string) $_POST['mail_scheme'] : 'smtp';

                if ($dbHost === '' || !ctype_digit($dbPort) || (int) $dbPort < 1 || (int) $dbPort > 65535 || $dbName === '' || $dbUser === '') $errors[] = 'اطلاعات اتصال دیتابیس را کامل وارد کنید.';
                if (!filter_var($baseUrl, FILTER_VALIDATE_URL)) $errors[] = 'آدرس نصب معتبر نیست.';
                if ($first === '' || $last === '' || mb_strlen($first) > 100 || mb_strlen($last) > 100) $errors[] = 'نام و نام خانوادگی مدیر را وارد کنید.';
                if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) $errors[] = 'ایمیل مدیر معتبر نیست.';
                if (strlen($password) < 12 || $password !== $confirmation) $errors[] = 'رمز مدیر باید حداقل ۱۲ نویسه باشد و با تکرارش یکسان باشد.';
                if (!in_array($mailer, array('log', 'smtp'), true)) $errors[] = 'روش ایمیل معتبر نیست.';
                if ($mailer === 'smtp' && ($mailHost === '' || !ctype_digit($mailPort) || (int) $mailPort < 1 || (int) $mailPort > 65535 || !filter_var($mailFrom, FILTER_VALIDATE_EMAIL) || !in_array($mailScheme, array('smtp', 'smtps'), true))) $errors[] = 'اطلاعات SMTP را بررسی کنید.';

                $pdo = null;
                $resumeHash = hash('sha256', strtolower($dbHost).'|'.$dbPort.'|'.$dbName.'|'.$dbUser);
                $resumeInstall = false;
                if (!$errors) {
                    try {
                        $pdo = new PDO('mysql:host='.$dbHost.';port='.$dbPort.';dbname='.$dbName.';charset=utf8mb4', $dbUser, $dbPass, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 8));
                        $pdo->query('SELECT 1');
                        $dbVersion = (string) $pdo->query('SELECT VERSION()')->fetchColumn();
                        if (stripos($dbVersion, 'mariadb') !== false) {
                            preg_match('/(?:^|[- ])(\d+)\.(\d+)\.(\d+)-MariaDB/i', $dbVersion, $versionParts);
                            if (isset($versionParts[1]) && ((int) $versionParts[1] < 10 || ((int) $versionParts[1] === 10 && (int) $versionParts[2] < 3))) {
                                throw new RuntimeException('نسخهٔ MariaDB باید 10.3 یا بالاتر باشد؛ نسخهٔ سرور: '.$dbVersion);
                            }
                        } elseif (preg_match('/^(\d+)\.(\d+)/', $dbVersion, $versionParts) && ((int) $versionParts[1] < 5 || ((int) $versionParts[1] === 5 && (int) $versionParts[2] < 7))) {
                            throw new RuntimeException('نسخهٔ MySQL باید 5.7 یا بالاتر باشد؛ نسخهٔ سرور: '.$dbVersion);
                        }
                        if (is_file($pendingPath)) {
                            $savedHash = trim((string) @file_get_contents($pendingPath));
                            if ($savedHash === '' || !hash_equals($savedHash, $resumeHash) || !is_file($envPath)) {
                                throw new RuntimeException('نصب نیمه‌کاره‌ای برای دیتابیس دیگری ثبت شده؛ اطلاعات همان دیتابیس را وارد کنید یا از دیتابیس تازه استفاده کنید.');
                            }
                            $resumeInstall = true;
                        }
                        $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
                        if (count($tables) > 0 && !$resumeInstall) {
                            throw new RuntimeException('این دیتابیس خالی نیست. برای جلوگیری از تداخل، دیتابیس تازه و اختصاصی بسازید. هیچ جدولی حذف نشد.');
                        }
                        $probeTable = '__peyvand_probe_'.bin2hex(random_bytes(5));
                        $pdo->exec('CREATE TABLE `'.$probeTable.'` (`id` INT NOT NULL PRIMARY KEY, `value` INT NOT NULL, INDEX `probe_value_idx` (`value`)) ENGINE=InnoDB');
                        $pdo->exec('INSERT INTO `'.$probeTable.'` (`id`,`value`) VALUES (1,1)');
                        $pdo->query('SELECT `value` FROM `'.$probeTable.'` WHERE `id`=1')->fetchColumn();
                        $pdo->exec('UPDATE `'.$probeTable.'` SET `value`=2 WHERE `id`=1');
                        $pdo->exec('DELETE FROM `'.$probeTable.'` WHERE `id`=1');
                        $pdo->exec('DROP TABLE `'.$probeTable.'`');
                    } catch (Throwable $exception) {
                        $probeCleanupFailed = false;
                        if ($pdo instanceof PDO && isset($probeTable)) {
                            try { $pdo->exec('DROP TABLE IF EXISTS `'.$probeTable.'`'); } catch (Throwable $ignored) { $probeCleanupFailed = true; }
                        }
                        $errors[] = 'بررسی دیتابیس ناموفق بود؛ اتصال، خالی‌بودن دیتابیس و مجوز ساخت/حذف جدول را بررسی کنید. جزئیات: '.$exception->getMessage().($probeCleanupFailed ? ' جدول آزمایشی '.$probeTable.' را دستی حذف کنید.' : '');
                    }
                }

                if (!$errors) {
                    $backupPath = null;
                    $envWritten = false;
                    try {
                        if (!$resumeInstall) {
                            if (is_file($envPath)) {
                                $backupPath = $base.'/.env.backup-'.date('Ymd-His').'-'.bin2hex(random_bytes(3));
                                if (!@rename($envPath, $backupPath)) throw new RuntimeException('پشتیبان‌گیری از .env قبلی ممکن نشد.');
                            }
                            $appKey = 'base64:'.base64_encode(random_bytes(32));
                            $envQuote = function ($value) { return '"'.str_replace(array('\\', '"', '$'), array('\\\\', '\\"', '\\$'), (string) $value).'"'; };
                            $env = implode("\n", array(
                                'APP_NAME='.$envQuote('Peyvand SRM'), 'APP_ENV=production', 'APP_KEY='.$appKey, 'APP_DEBUG=false', 'APP_URL='.$envQuote($baseUrl),
                                'APP_LOCALE=fa', 'APP_FALLBACK_LOCALE=fa', 'APP_FAKER_LOCALE=fa_IR', 'APP_TIMEZONE=Asia/Tehran',
                                'APP_MAINTENANCE_DRIVER=file', 'BCRYPT_ROUNDS=12', 'LOG_CHANNEL=stack', 'LOG_STACK=single', 'LOG_LEVEL=warning',
                                'DB_CONNECTION=mysql', 'DB_HOST='.$envQuote($dbHost), 'DB_PORT='.$dbPort, 'DB_DATABASE='.$envQuote($dbName), 'DB_USERNAME='.$envQuote($dbUser), 'DB_PASSWORD='.$envQuote($dbPass),
                                'SESSION_DRIVER=file', 'SESSION_LIFETIME=120', 'SESSION_ENCRYPT=true', 'SESSION_PATH='.$envQuote($baseUrlPath !== '' ? $baseUrlPath : '/'), 'SESSION_DOMAIN=null', 'SESSION_SECURE_COOKIE='.($https ? 'true' : 'false'),
                                'BROADCAST_CONNECTION=log', 'FILESYSTEM_DISK=local', 'QUEUE_CONNECTION=sync', 'CACHE_STORE=file',
                                'MAIL_MAILER='.$envQuote($mailer), 'MAIL_SCHEME='.$envQuote($mailScheme), 'MAIL_HOST='.$envQuote($mailHost), 'MAIL_PORT='.$mailPort,
                                'MAIL_USERNAME='.$envQuote($mailUser), 'MAIL_PASSWORD='.$envQuote($mailPass), 'MAIL_FROM_ADDRESS='.$envQuote($mailer === 'smtp' ? $mailFrom : 'noreply@example.com'), 'MAIL_FROM_NAME="${APP_NAME}"', '',
                            ));
                            $temporaryEnv = tempnam($base, '.peyvand-env-');
                            if ($temporaryEnv === false || @file_put_contents($temporaryEnv, $env, LOCK_EX) === false || !@rename($temporaryEnv, $envPath)) {
                                if (is_string($temporaryEnv) && is_file($temporaryEnv)) @unlink($temporaryEnv);
                                throw new RuntimeException('ساخت امن فایل .env ناموفق بود.');
                            }
                            $envWritten = true;
                            if (@file_put_contents($pendingPath, $resumeHash, LOCK_EX) === false) throw new RuntimeException('ثبت نشانگر نصب نیمه‌کاره ناموفق بود.');
                        }
                        if (is_file($base.'/bootstrap/cache/config.php') && !@unlink($base.'/bootstrap/cache/config.php')) {
                            throw new RuntimeException('پاک‌کردن config cache قبلی ناموفق بود؛ bootstrap/cache را بررسی کنید.');
                        }
                        if (function_exists('set_time_limit')) @set_time_limit(180);
                        require_once $base.'/vendor/autoload.php';
                        $app = require $base.'/bootstrap/app.php';
                        $app->make('Illuminate\\Contracts\\Console\\Kernel')->bootstrap();
                        $migrationStatus = \Illuminate\Support\Facades\Artisan::call('migrate', array('--force' => true));
                        if ($migrationStatus !== 0) throw new RuntimeException('اجرای migration ناموفق بود: '.\Illuminate\Support\Facades\Artisan::output());

                        $adminExists = \App\Models\User::where('role', 'admin')->exists();
                        if (!$adminExists) {
                            \App\Models\User::create(array('name' => $first.' '.$last, 'first_name' => $first, 'last_name' => $last, 'email' => $email, 'password' => \Illuminate\Support\Facades\Hash::make($password), 'role' => 'admin', 'status' => 'active'));
                        }
                        foreach (array(
                            'segments' => json_encode(array('عمومی'), JSON_UNESCAPED_UNICODE),
                            'project_stages' => json_encode(array('new', 'qualified', 'proposal', 'negotiation', 'purchased', 'completed'), JSON_UNESCAPED_UNICODE),
                            'ranks' => json_encode(array(array('title' => 'عادی', 'min' => 0, 'max' => '')), JSON_UNESCAPED_UNICODE),
                            'sms_enabled' => '0', 'ai_enabled' => '0',
                        ) as $setting => $value) {
                            \Illuminate\Support\Facades\DB::table('srm_settings')->updateOrInsert(array('key' => $setting), array('value' => $value, 'created_at' => now(), 'updated_at' => now()));
                        }
                        $_SESSION['setup_pending_verify'] = true;
                        $_SESSION['setup_admin_exists'] = $adminExists;
                        $pendingVerify = true;
                        $messages[] = $adminExists ? 'جدول‌ها آماده‌اند و مدیر قبلی حفظ شد.' : 'جدول‌ها و مدیر اصلی ساخته شدند.';
                    } catch (Throwable $exception) {
                        if (!$envWritten && is_string($backupPath) && is_file($backupPath) && !is_file($envPath)) @rename($backupPath, $envPath);
                        $reference = 'INSTALL-'.strtoupper(bin2hex(random_bytes(4)));
                        $logFailure($reference, $exception->getMessage(), $exception->getTraceAsString());
                        $errors[] = 'نصب در مرحلهٔ ساخت تنظیمات یا دیتابیس متوقف شد. شناسهٔ گزارش: '.$reference.'؛ جزئیات: '.$exception->getMessage();
                    }
                }
            }
        }
    }
}

$done = $done || ($sessionOk && !empty($_SESSION['setup_complete']));
$canProceed = $blockers === 0 && $rewritePassed && !$done;
?><!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نصاب مرحله‌ای پیوند SRM</title>
<style>
body{margin:0;background:#f3f6fa;color:#172033;font:15px Tahoma,Arial,sans-serif}.wrap{max-width:900px;margin:28px auto;padding:18px}.card{background:#fff;border:1px solid #dce3ed;border-radius:16px;padding:24px;box-shadow:0 8px 24px #1b31500d}h1{margin-top:0;color:#173b70}.muted{color:#627087;font-size:13px;line-height:2}.checks{width:100%;border-collapse:collapse;margin:16px 0}.checks td{padding:10px;border-bottom:1px solid #e7ebf1;vertical-align:top}.ok{color:#176b35}.bad{color:#a52c27}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}.field{display:grid;gap:7px;margin:10px 0}input,select{padding:11px;border:1px solid #ccd5e2;border-radius:8px;font:inherit}.section{border-top:1px solid #e4e9f0;margin-top:20px;padding-top:14px}button,a.btn{display:inline-block;background:#1769aa;color:#fff;border:0;border-radius:9px;padding:12px 19px;font:inherit;text-decoration:none;cursor:pointer;margin:10px 0}button:disabled{background:#8b99aa;cursor:not-allowed}.notice,.error,.warn{padding:12px 14px;border-radius:9px;margin:10px 0;line-height:1.9}.notice{background:#e8f6ed;color:#175c2d}.error{background:#fff0ef;color:#942c27}.warn{background:#fff8e5;color:#76550b}fieldset{border:0;padding:0;margin:0}fieldset:disabled{opacity:.45}code{direction:ltr;unicode-bidi:embed}
</style></head><body><main class="wrap"><section class="card"><h1>نصاب مرحله‌ای پیوند SRM</h1>
<?php if ($done): ?>
<div class="notice">نصب کامل شد و مسیر سلامت برنامه پاسخ موفق داده است.</div><p>نشانی ورود:</p><a class="btn" href="<?= $h($baseUrl.'/login') ?>">ورود به سامانه</a><p class="warn">برای ایمنی، فایل‌های setup.php و installer.php را از File Manager هاست حذف کنید.</p>
<?php else: ?>
<p class="muted">ابتدا محیط اجرا، فایل‌ها، افزونه‌ها، نوشتن واقعی در پوشه‌ها و مسیرهای وب بررسی می‌شوند. تا وقتی همهٔ موارد ضروری سبز نشوند، نصاب به دیتابیس دست نمی‌زند.</p>
<?php foreach ($errors as $error): ?><div class="error"><?= $h($error) ?></div><?php endforeach; ?>
<?php if ($pendingVerify): ?>
<div class="notice">دیتابیس و مدیر آماده‌اند. اکنون مسیر وب برنامه بررسی می‌شود؛ قفل نصب تا پاسخ موفق این بررسی ساخته نخواهد شد.</div>
<p id="healthStatus" class="warn">در حال بررسی <?= $h($baseUrl.'/up') ?> ...</p>
<form id="finalizeForm" method="post" action="<?= $h($setupUrlPath) ?>"><input type="hidden" name="_token" value="<?= $h($csrf) ?>"><input type="hidden" name="action" value="finalize"><input type="hidden" name="health_ok" value="1"></form>
<button type="button" id="retryHealth">تلاش دوباره برای بررسی مسیر</button>
<?php else: ?>
<h3 class="section">مرحلهٔ ۱: بررسی نیازمندی‌ها</h3>
<table class="checks"><tbody><?php foreach ($checks as $check): ?><tr><td class="<?= $check['ok'] ? 'ok' : 'bad' ?>"><?= $check['ok'] ? '✓' : '✗' ?> <?= $h($check['label']) ?></td><td><?= $h($check['detail']) ?></td></tr><?php endforeach; ?>
<tr><td id="rewriteLabel" class="<?= $rewritePassed ? 'ok' : 'bad' ?>"><?= $rewritePassed ? '✓' : '✗' ?> بازنویسی مسیر وب</td><td id="rewriteDetail"><?= $rewritePassed ? 'درخواست آزمایشی از مسیر نصب به front controller رسید.' : 'در حال بررسی اینکه درخواست‌هایی مثل /login به public/index.php می‌رسند...' ?></td></tr>
</tbody></table>
<?php if ($blockers > 0): ?><div class="error">چند پیش‌نیاز لازم برآورده نشده است. موردهای قرمز را اصلاح کنید و صفحه را دوباره باز کنید؛ در این مرحله فایل تنظیمات و دیتابیس تغییر نمی‌کنند.</div><?php elseif (!$rewritePassed): ?><div class="warn" id="rewriteMessage">نصاب هنوز تأیید نکرده که مسیرهای تمیز کار می‌کنند. دکمهٔ نصب تا پایان آزمون مسیر غیرفعال است.</div><?php endif; ?>
<h3 class="section">مرحلهٔ ۲: اتصال دیتابیس و مدیر اصلی</h3>
<form method="post" action="<?= $h($setupUrlPath) ?>" autocomplete="off"><input type="hidden" name="_token" value="<?= $h($csrf) ?>"><input type="hidden" name="action" value="install">
<fieldset id="installFields" <?= $canProceed ? '' : 'disabled' ?>>
<div class="grid">
<label class="field">میزبان دیتابیس<input name="db_host" required value="<?= $h(isset($_POST['db_host']) ? $_POST['db_host'] : 'localhost') ?>"></label>
<label class="field">پورت دیتابیس<input name="db_port" required value="<?= $h(isset($_POST['db_port']) ? $_POST['db_port'] : '3306') ?>"></label>
<label class="field">نام دیتابیس<input name="db_database" required value="<?= $h(isset($_POST['db_database']) ? $_POST['db_database'] : '') ?>"></label>
<label class="field">نام کاربری دیتابیس<input name="db_username" required value="<?= $h(isset($_POST['db_username']) ? $_POST['db_username'] : '') ?>"></label>
<label class="field">رمز دیتابیس<input name="db_password" type="password" autocomplete="new-password"></label></div>
<h4 class="section">ایمیل بازیابی رمز</h4><div class="grid">
<label class="field">روش ارسال<select name="mail_mailer"><option value="log">ثبت در لاگ (ایمیل ارسال نمی‌شود)</option><option value="smtp">SMTP</option></select></label>
<label class="field">میزبان SMTP<input name="mail_host" value="<?= $h(isset($_POST['mail_host']) ? $_POST['mail_host'] : '') ?>"></label>
<label class="field">پورت SMTP<input name="mail_port" value="<?= $h(isset($_POST['mail_port']) ? $_POST['mail_port'] : '587') ?>"></label>
<label class="field">نوع اتصال<select name="mail_scheme"><option value="smtp">STARTTLS / SMTP</option><option value="smtps">SSL / SMTPS</option></select></label>
<label class="field">نام کاربری SMTP<input name="mail_username" autocomplete="off"></label><label class="field">رمز SMTP<input name="mail_password" type="password" autocomplete="new-password"></label><label class="field">ایمیل فرستنده<input name="mail_from" type="email" dir="ltr"></label></div>
<h4 class="section">مدیر اصلی</h4><div class="grid">
<label class="field">نام<input name="first_name" required value="<?= $h(isset($_POST['first_name']) ? $_POST['first_name'] : '') ?>"></label><label class="field">نام خانوادگی<input name="last_name" required value="<?= $h(isset($_POST['last_name']) ? $_POST['last_name'] : '') ?>"></label>
<label class="field">ایمیل ورود<input name="email" type="email" required value="<?= $h(isset($_POST['email']) ? $_POST['email'] : '') ?>"></label><label class="field">رمز مدیر، حداقل ۱۲ نویسه<input name="admin_password" type="password" minlength="12" required autocomplete="new-password"></label><label class="field">تکرار رمز مدیر<input name="admin_password_confirmation" type="password" minlength="12" required autocomplete="new-password"></label></div>
<button type="submit" id="installButton" <?= $canProceed ? '' : 'disabled' ?>>بررسی دسترسی دیتابیس و شروع نصب</button>
</fieldset></form>
<?php endif; ?>
<?php endif; ?></section></main>
<?php if (!$done && !$pendingVerify && $blockers === 0 && !$rewritePassed && $sessionOk): ?>
<script>
(function(){var probeUrl=<?= json_encode($rewriteUrl.'?__peyvand_rewrite_probe='.$rewriteNonce, JSON_UNESCAPED_SLASHES) ?>;var setupUrl=<?= json_encode($setupUrlPath, JSON_UNESCAPED_SLASHES) ?>;var token=<?= json_encode($csrf) ?>;var nonce=<?= json_encode($rewriteNonce) ?>;var detail=document.getElementById('rewriteDetail');
fetch(probeUrl,{cache:'no-store',credentials:'same-origin'}).then(function(r){return r.text().then(function(t){if(!r.ok||t.indexOf('PEYVAND_REWRITE_OK:'+nonce)===-1)throw new Error('HTTP '+r.status);});}).then(function(){var form=new URLSearchParams({_token:token,action:'record_rewrite_probe',nonce:nonce});return fetch(setupUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form.toString(),credentials:'same-origin'});}).then(function(r){if(!r.ok&&r.status!==204)throw new Error('ثبت نتیجهٔ آزمون ناموفق بود');location.reload();}).catch(function(e){document.getElementById('rewriteLabel').className='bad';detail.textContent='درخواست آزمایشی به front controller نرسید ('+e.message+'). .htaccess و mod_rewrite یا Document Root پوشهٔ public را بررسی کنید. نصب شروع نشد.';});})();
</script>
<?php endif; ?>
<?php if ($pendingVerify): ?>
<script>
(function(){var url=<?= json_encode(rtrim($baseUrl,'/').'/up', JSON_UNESCAPED_SLASHES) ?>;var form=document.getElementById('finalizeForm');var status=document.getElementById('healthStatus');function verify(){status.className='warn';status.textContent='در حال بررسی '+url+' ...';fetch(url,{cache:'no-store',credentials:'same-origin'}).then(function(r){if(!r.ok)throw new Error('آزمون /up با HTTP '+r.status);status.className='notice';status.textContent='پاسخ مسیر سلامت موفق بود؛ نصب نهایی می‌شود.';return fetch(form.getAttribute('action'),{method:'POST',body:new FormData(form),credentials:'same-origin'});}).then(function(r){return r.text().then(function(body){if(!r.ok){var detail=body.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,400);throw new Error('ثبت قفل با HTTP '+r.status+' در '+r.url+(detail?'؛ '+detail:''));}location.reload();});}).catch(function(e){status.className='error';status.textContent='بررسی نهایی ناموفق بود ('+e.message+'). قفل نصب نوشته نشد؛ پس از اصلاح خطای نمایش‌داده‌شده دوباره تلاش کنید.';});}document.getElementById('retryHealth').addEventListener('click',verify);verify();})();
</script>
<?php endif; ?>
</body></html>
