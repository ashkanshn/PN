<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use App\Http\Middleware\RoleMiddleware;
use App\Support\LocalErrorLog;

// Create the local log before Laravel starts booting providers, so boot-time
// failures can be recorded even when the configured log channel is unavailable.
try {
    LocalErrorLog::ensureFile();
} catch (Throwable $exception) {
    error_log('Could not initialize Laravel local error log: '.$exception->getMessage());
}

register_shutdown_function(static function (): void {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        try {
            LocalErrorLog::recordFatal($error);
        } catch (Throwable $exception) {
            error_log('Could not record Laravel fatal error: '.$exception->getMessage());
        }
    }
});

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias(['role' => RoleMiddleware::class]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->report(function (Throwable $exception) {
            try {
                LocalErrorLog::record($exception);
            } catch (Throwable $loggingException) {
                error_log('Could not record Laravel exception: '.$loggingException->getMessage());
            }

            // We already wrote the exception directly to laravel.log. Do not
            // initialize Laravel's Monolog channel here: some shared hosts
            // install an incompatible PSR logger extension that breaks it.
            return false;
        });
    })->create();
