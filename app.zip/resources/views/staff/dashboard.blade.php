@extends('layouts.srm',['title'=>'داشبورد همکار مدیر'])
@section('content')<section class="card"><h2>بخش‌های مجاز شما</h2><div class="tiles">@foreach($modules as $key=>$label)<a class="stat tile" href="{{ route('staff.modules.index',$key) }}">{{ $label }}<strong>›</strong></a>@endforeach</div><p class="muted">دسترسی شما به بخش‌های انتخاب‌شده توسط مدیر کل محدود است.</p></section>@endsection
