@extends('layouts.guest',['title'=>'بازیابی رمز عبور'])
@section('guest')
<div class="auth"><section class="card">
<h1>فراموشی رمز عبور</h1>
<p>ایمیل حساب خود را وارد کنید تا پیوند امن بازنشانی رمز برایتان ارسال شود.</p>
@if(session('status'))<div class="flash">{{ session('status') }}</div>@endif
<form method="post" action="{{ route('password.email') }}">@csrf
<label class="field">ایمیل ثبت‌شده<input type="email" name="email" value="{{ old('email') }}" required autocomplete="email" dir="ltr"></label>
@error('email')<p class="error">{{ $message }}</p>@enderror
<button class="btn">ارسال پیوند بازنشانی</button>
</form>
<p><a href="{{ route('login') }}">بازگشت به ورود</a></p>
<p class="muted">برای ارسال ایمیل، تنظیمات SMTP باید هنگام نصب وارد شده باشد.</p>
</section></div>
@endsection
