@extends('layouts.guest',['title'=>'درخواست عضویت'])
@section('guest')
<div class="auth"><section class="card">
<h1>درخواست عضویت نماینده</h1><p>پس از تأیید مدیریت با موبایل و کد ملی به‌عنوان رمز اولیه وارد شوید. سامانه در نخستین ورود تغییر رمز را اجباری می‌کند.</p>
<form method="post" action="{{ route('register') }}">@csrf
@if($errors->any())<div class="flash error" role="alert" tabindex="-1"><strong>ثبت‌نام انجام نشد؛ موارد زیر را اصلاح کنید:</strong>@foreach($errors->all() as $error)<div>{{ $error }}</div>@endforeach</div>@endif
@foreach(['first_name'=>'نام','last_name'=>'نام خانوادگی','mobile'=>'موبایل','national_id'=>'کد ملی','email'=>'ایمیل (اختیاری)','province'=>'استان','city'=>'شهر','address'=>'نشانی','primary_segment'=>'زمینه فعالیت'] as $key=>$label)
<label class="field">{{ $label }}
@if($key==='address')<textarea name="{{ $key }}" required>{{ old($key) }}</textarea>
@elseif($key==='province')<select id="province" name="province" required><option value="">انتخاب استان</option>@foreach($provinces as $province)<option value="{{ $province }}" @selected(old('province')===$province)>{{ $province }}</option>@endforeach</select>
@elseif($key==='city')<select id="city" name="city" required disabled><option value="">انتخاب شهر</option></select>
@elseif($key==='primary_segment')<select name="primary_segment" required><option value="">انتخاب زمینه</option>@foreach($segments as $segment)<option value="{{ is_array($segment)?($segment['key']??''):$segment }}">{{ is_array($segment)?($segment['label']??$segment['key']??''):$segment }}</option>@endforeach</select>
@else<input name="{{ $key }}" value="{{ old($key) }}" @if($key==='email')type="email" dir="ltr"@endif @if(in_array($key,['first_name','last_name','mobile','national_id']))required @endif>
@endif
</label>
@endforeach
<fieldset><legend>زمینه‌های فعالیت</legend>@foreach($segments as $segment)@php($segmentKey=is_array($segment)?($segment['key']??''):$segment)<label><input type="checkbox" name="secondary_segments[]" value="{{ $segmentKey }}"> {{ is_array($segment)?($segment['label']??$segmentKey):$segment }}</label>@endforeach</fieldset>
<label class="field">کدپستی ۱۰ رقمی<input name="postal_code" value="{{ old('postal_code') }}" inputmode="numeric"></label><label><input type="checkbox" name="no_postal_code" value="1" @checked(old('no_postal_code'))> کدپستی ندارم</label>
<label class="field">کد معرف (اختیاری)<input name="referral_code" value="{{ old('referral_code',$referralCode) }}" dir="ltr"></label><button class="btn">ثبت درخواست عضویت</button></form><p><a href="{{ route('login') }}">قبلاً ثبت‌نام کرده‌ام</a></p>
</section></div>
<script>(()=>{const p=document.getElementById('province'),c=document.getElementById('city');if(!p||!c)return;const citiesUrl=@json(route('geo.cities',['province'=>'__PROVINCE__'])),selectedCity=@json(old('city',''));async function fill(selected=''){c.replaceChildren(new Option(p.value?'در حال دریافت شهرها…':'ابتدا استان را انتخاب کنید',''));c.disabled=true;if(!p.value)return;try{const r=await fetch(citiesUrl.replace('__PROVINCE__',encodeURIComponent(p.value)),{headers:{'Accept':'application/json'}});if(!r.ok)throw new Error('HTTP '+r.status);const cities=await r.json();c.replaceChildren(new Option('انتخاب شهر',''));cities.forEach(city=>c.add(new Option(city,city,false,city===selected)));c.disabled=false}catch(error){c.replaceChildren(new Option('دریافت فهرست شهرها ناموفق بود',''));c.disabled=true}}p.addEventListener('change',()=>fill(''));if(p.value)fill(selectedCity)})();</script>
@endsection
