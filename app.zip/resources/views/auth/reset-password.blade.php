@extends('layouts.guest',['title'=>'تنظیم رمز عبور جدید'])
@section('guest')
<div class="auth"><section class="card">
<h1>تنظیم رمز عبور جدید</h1>
<form method="post" action="{{ route('password.update') }}">@csrf
<input type="hidden" name="token" value="{{ $token }}">
<label class="field">ایمیل حساب<input type="email" name="email" value="{{ old('email',$email) }}" required autocomplete="email" dir="ltr"></label>
<label class="field">رمز جدید<input type="password" name="password" minlength="12" required autocomplete="new-password"></label>
<label class="field">تکرار رمز جدید<input type="password" name="password_confirmation" minlength="12" required autocomplete="new-password"></label>
@if($errors->any())<div class="flash error">@foreach($errors->all() as $error)<div>{{ $error }}</div>@endforeach</div>@endif
<button class="btn">ذخیره رمز جدید</button>
</form>
<p><a href="{{ route('login') }}">بازگشت به ورود</a></p>
</section></div>
@endsection
