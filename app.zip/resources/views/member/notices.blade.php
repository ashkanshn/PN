@extends('layouts.srm',['title'=>'اطلاعیه‌ها'])
@section('content')<div class="stack">
    @forelse($rows as $notice)
        <article class="card member-notice-card"><div class="row spread"><h2>{{ $notice->title }}</h2>@if($notice->is_pinned)<span class="tag">سنجاق‌شده</span>@endif</div><div class="rich-content">{!! $notice->body !!}</div>
            @foreach(($noticeMedia['notice:'.$notice->id]??collect()) as $asset)
                <div class="content-asset">
                    @if(str_starts_with($asset->mime_type,'image/'))<a href="{{ route('member.media.preview',$asset->id) }}" target="_blank"><img class="content-image" src="{{ route('member.media.preview',$asset->id) }}" alt="{{ $asset->original_name }}"></a>
                    @elseif(str_starts_with($asset->mime_type,'video/'))<video class="content-video" controls preload="metadata" src="{{ route('member.media.preview',$asset->id) }}"></video>@endif
                    <a class="btn alt" href="{{ route('member.media.download',$asset->id) }}">دانلود {{ $asset->original_name }}</a>
                </div>
            @endforeach
            <p class="muted">{{ $notice->published_at }}</p>
        </article>
    @empty<div class="card">اطلاعیه‌ای منتشر نشده است.</div>@endforelse
</div>@endsection
