@extends('layouts.srm',['title'=>'دستیار هوشمند Peyvand AI'])
@section('content')
<section class="card ai-chat-card">
    <header class="ai-chat-heading"><div><h2>گفتگو با دستیار هوشمند</h2><p>گفتگوهای شما ذخیره می‌شوند و می‌توانید بعداً آن‌ها را مرور یا ادامه دهید.</p></div></header>
    <div class="ai-transcript" id="ai-transcript" aria-live="polite" aria-label="تاریخچه گفتگو">
        @forelse($history as $exchange)
            @php($messages=json_decode((string)$exchange->messages,true)?:[])
            @foreach($messages as $message)
                <article class="ai-message {{ ($message['role']??'user')==='assistant'?'ai-message-answer':'ai-message-question' }}">
                    <strong>{{ ($message['role']??'user')==='assistant'?'پاسخ هوش مصنوعی':'شما' }}</strong>
                    <div>{{ (string)($message['content']??'') }}</div>
                    @if($loop->last)<time>{{ \Illuminate\Support\Carbon::parse($exchange->created_at)->format('Y/m/d H:i') }}</time>@endif
                </article>
            @endforeach
        @empty
            <div class="ai-empty" id="ai-empty">هنوز گفتگویی ثبت نشده است. اولین پرسش خود را بنویسید.</div>
        @endforelse
    </div>
    {{ $history->links() }}
    <form method="post" action="{{ route('member.assistant.chat') }}" id="ai-chat-form">@csrf
        <label class="field" for="ai-question">پیام شما<textarea id="ai-question" name="question" required maxlength="5000" rows="3" placeholder="پرسش خود را بنویسید…">{{ old('question') }}</textarea></label>
        <div class="ai-chat-actions"><span id="ai-chat-status" role="status"></span><button class="btn" id="ai-send" type="submit">ارسال پرسش</button></div>
    </form>
</section>
<style>
.ai-chat-card{display:grid;gap:16px}.ai-chat-heading h2{margin:0 0 5px}.ai-chat-heading p{margin:0;color:#70818c}.ai-transcript{display:grid;gap:12px;max-height:58vh;min-height:180px;overflow:auto;padding:14px;background:#f5f8f9;border:1px solid #e2e9eb;border-radius:12px}.ai-message{max-width:min(88%,760px);padding:12px 15px;border-radius:12px;white-space:pre-wrap;overflow-wrap:anywhere}.ai-message strong{display:block;margin-bottom:5px;font-size:12px}.ai-message div{line-height:1.9}.ai-message time{display:block;margin-top:7px;color:#82919a;font-size:10px}.ai-message-question{justify-self:start;background:#e8f4f5;border:1px solid #d5e9ea}.ai-message-answer{justify-self:stretch;background:#fff;border:1px solid #e2e9eb}.ai-message-error{justify-self:stretch;background:#fff1f1;border:1px solid #f1d5d5;color:#9b3640}.ai-empty{padding:34px 12px;text-align:center;color:#788993}.ai-chat-actions{display:flex;justify-content:space-between;align-items:center;gap:12px}.ai-chat-actions #ai-chat-status{color:#74838b;font-size:12px}
</style>
<script>
(()=>{'use strict';const form=document.getElementById('ai-chat-form'),transcript=document.getElementById('ai-transcript'),input=document.getElementById('ai-question'),button=document.getElementById('ai-send'),status=document.getElementById('ai-chat-status');if(!form)return;
function bubble(role,label,text,extra=''){const item=document.createElement('article');item.className='ai-message '+role+(extra?' '+extra:'');const title=document.createElement('strong'),body=document.createElement('div');title.textContent=label;body.textContent=text;item.append(title,body);transcript.append(item);transcript.scrollTop=transcript.scrollHeight;return item}
form.addEventListener('submit',async event=>{event.preventDefault();const question=input.value.trim();if(!question)return;const formData=new FormData(form);bubble('ai-message-question','شما',question);document.getElementById('ai-empty')?.remove();input.value='';button.disabled=true;status.textContent='در حال دریافت پاسخ…';try{const response=await fetch(form.action,{method:'POST',body:formData,credentials:'same-origin',headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}});const result=await response.json();if(!response.ok||!result.ok)throw new Error(result.message||'ارسال پرسش ناموفق بود.');bubble('ai-message-answer','پاسخ هوش مصنوعی',result.answer);status.textContent='گفتگو ذخیره شد.'}catch(error){bubble('ai-message-error','خطا',String(error.message||error));status.textContent='پاسخ دریافت نشد؛ پرسش را دوباره ارسال کنید.';input.value=question}finally{button.disabled=false;input.focus()}});
transcript.scrollTop=transcript.scrollHeight;})();
</script>
@endsection
