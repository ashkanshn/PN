@extends('layouts.srm',['title'=>'آموزش و آزمون'])
@section('content')
<div class="stack">
    <section class="card"><h2>آموزش‌ها</h2><div class="tiles">
        @forelse($lessons as $lesson)
            <article class="stat tile member-learning-card"><h3>{{ $lesson->title }}</h3><div class="rich-content">{!! $lesson->body !!}</div>
                @foreach(($lessonMedia['lesson:'.$lesson->id]??collect()) as $asset)
                    <div class="content-asset">
                        @if(str_starts_with($asset->mime_type,'image/'))<a href="{{ route('member.media.preview',$asset->id) }}" target="_blank"><img class="content-image" src="{{ route('member.media.preview',$asset->id) }}" alt="{{ $asset->original_name }}"></a>
                        @elseif(str_starts_with($asset->mime_type,'video/'))<video class="content-video" controls preload="metadata" src="{{ route('member.media.preview',$asset->id) }}"></video>@endif
                        <a class="btn alt" href="{{ route('member.media.download',$asset->id) }}">دانلود {{ $asset->original_name }}</a>
                    </div>
                @endforeach
                @if(!($progress[$lesson->id]??false))<form method="post" action="{{ route('member.learning.complete',$lesson->id) }}">@csrf<button class="btn">ثبت اتمام آموزش</button></form>@else<span class="tag">تکمیل شده</span>@endif
            </article>
        @empty<p>آموزشی منتشر نشده است.</p>@endforelse
    </div></section>
    <section class="card"><h2>آزمون‌ها</h2>
        @forelse($exams as $exam)@php($questions=json_decode($exam->questions,true)??[])<article class="card" style="margin:12px 0"><h3>{{ $exam->title }}</h3><div class="rich-content">{!! $exam->description !!}</div>@foreach(($examMedia['exam:'.$exam->id]??collect()) as $asset)<div class="content-asset">@if(str_starts_with($asset->mime_type,'image/'))<a href="{{ route('member.media.preview',$asset->id) }}" target="_blank"><img class="content-image" src="{{ route('member.media.preview',$asset->id) }}" alt="{{ $asset->original_name }}"></a>@elseif(str_starts_with($asset->mime_type,'video/'))<video class="content-video" controls preload="metadata" src="{{ route('member.media.preview',$asset->id) }}"></video>@endif<a class="btn alt" href="{{ route('member.media.download',$asset->id) }}">دانلود {{ $asset->original_name }}</a></div>@endforeach<form method="post" action="{{ route('member.exams.submit',$exam->id) }}">@csrf
            @foreach($questions as $i=>$q)<div class="question"><strong>{{ $i+1 }}. {{ $q['q']??'' }}</strong>@foreach(($q['options']??[]) as $j=>$option)<label style="display:block;margin:8px"><input type="radio" name="answers[{{ $i }}]" value="{{ $j }}" required> {{ $option }}</label>@endforeach</div>@endforeach<button class="btn">ثبت پاسخ‌ها</button></form></article>
        @empty<p>آزمون فعالی وجود ندارد.</p>@endforelse
    </section>
</div>
@endsection
