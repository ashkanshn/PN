@extends('layouts.srm',['title'=>'پروفایل من'])
@section('content')
<section class="card"><form method="post" enctype="multipart/form-data" action="{{ route('member.profile') }}">@csrf<div class="grid">
<label class="field">تصویر پروفایل<input type="file" name="profile_photo" accept="image/jpeg,image/png,image/webp"><small class="muted">JPG، PNG یا WebP · حداکثر ۵ مگابایت</small></label>
@if($hasProfilePhoto)<div class="field"><span>تصویر فعلی</span><img src="{{ route('member.profile.photo') }}" alt="تصویر پروفایل فعلی" style="width:88px;height:88px;object-fit:cover;border-radius:50%;margin-top:8px"></div>@endif
@foreach(['first_name'=>'نام','last_name'=>'نام خانوادگی','mobile'=>'موبایل'] as $key=>$label)<label class="field">{{ $label }}<input name="{{ $key }}" value="{{ old($key,$user->{$key}) }}" required></label>@endforeach
<label class="field">استان<select name="province" id="province" required><option value="">انتخاب استان</option>@foreach($provinces as $province)<option value="{{ $province }}" @selected(old('province',$user->province)===$province)>{{ $province }}</option>@endforeach</select></label>
<label class="field">شهر<select name="city" id="city" required><option value="{{ old('city',$user->city) }}">{{ old('city',$user->city) }}</option></select></label>
<label class="field">کدپستی<input name="postal_code" value="{{ old('postal_code',$user->postal_code) }}" inputmode="numeric"></label>
<label><input type="checkbox" name="no_postal_code" value="1" @checked(old('no_postal_code',$user->no_postal_code))> کدپستی ندارم</label>
<label class="field">زمینه فعالیت<select name="primary_segment">@foreach($segments as $segment)@php($v=is_array($segment)?($segment['key']??''):$segment)<option value="{{ $v }}" @selected(old('primary_segment',$user->primary_segment)===$v)>{{ is_array($segment)?($segment['label']??$v):$segment }}</option>@endforeach</select></label>
<fieldset><legend>زمینه‌های دیگر</legend>@foreach($segments as $segment)@php($v=is_array($segment)?($segment['key']??''):$segment)<label><input type="checkbox" name="secondary_segments[]" value="{{ $v }}" @checked(in_array($v,old('secondary_segments',$user->secondary_segments??[]),true))> {{ is_array($segment)?($segment['label']??$v):$segment }}</label>@endforeach</fieldset>
<label class="field">نشانی<textarea name="address" required>{{ old('address',$user->address) }}</textarea></label>
</div><button class="btn">ذخیره پروفایل</button></form></section>
<script>(()=>{const p=document.getElementById('province'),c=document.getElementById('city');let selected=@json(old('city',$user->city));if(!p||!c)return;const citiesUrl=@json(route('geo.cities',['province'=>'__PROVINCE__']));async function fill(){if(!p.value)return;const r=await fetch(citiesUrl.replace('__PROVINCE__',encodeURIComponent(p.value)));const cities=await r.json();c.innerHTML='<option value="">انتخاب شهر</option>'+cities.map(x=>'<option '+(x===selected?'selected':'')+'>'+x+'</option>').join('')}p.addEventListener('change',()=>{selected='';fill()});fill()})();</script>
@endsection
