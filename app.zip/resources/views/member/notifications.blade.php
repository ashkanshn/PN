@extends('layouts.srm',['title'=>'اعلان‌ها'])
@section('content')<div class="stack">@forelse($rows as $n)<article class="card"><h2>{{ $n->event_key }}</h2><p>{{ $n->message }}</p><span class="muted">{{ $n->created_at }}</span></article>@empty<div class="card">اعلانی ثبت نشده است.</div>@endforelse</div>{{ $rows->links() }}@endsection
