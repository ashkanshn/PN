@extends('layouts.srm',['title'=>'داشبورد نماینده'])
@section('content')
<div class="card" style="margin-bottom:16px;background:linear-gradient(110deg,#075b76,#098779);color:white"><h2>سلام {{ auth()->user()->first_name }}!</h2><p>از این پنل پروژه‌ها، امتیازها، جوایز و آموزش‌های خود را مدیریت کنید.</p></div>
<div class="stats">@foreach(['پروژه‌های من'=>$stats['projects'],'امتیاز فعلی'=>$stats['points'],'رتبه فعلی'=>$stats['rank'],'معرفی‌ها'=>$stats['referrals'],'اعلان‌های خوانده‌نشده'=>$stats['unread']] as $label=>$value)<div class="stat">{{ $label }}<strong>{{ is_numeric($value)?number_format($value):$value }}</strong></div>@endforeach</div>
<div class="tiles">@foreach(['member.projects'=>'پروژه‌های من','member.referrals'=>'معرفی دوستان','member.points'=>'امتیازات','member.rewards'=>'دریافت جایزه','member.learning'=>'آموزش و آزمون','member.notices'=>'اطلاعیه‌ها'] as $route=>$label)<a class="stat tile" href="{{ route($route) }}">{{ $label }} ←</a>@endforeach</div>
@endsection
