@extends('layouts.srm',['title'=>'پروفایل حساب'])
@section('content')
<section class="card account-profile-card">
    <div class="account-profile-heading">
        <div><h2>پروفایل حساب</h2><p>تصویر و اطلاعات نمایشی حساب خود را مدیریت کنید.</p></div>
        @if($hasProfilePhoto)<img src="{{ route($photoRoute) }}" alt="تصویر پروفایل" class="account-profile-preview">@else<div class="account-profile-preview account-profile-initial">{{ mb_substr($user->name,0,1) }}</div>@endif
    </div>
    <form method="post" enctype="multipart/form-data" action="{{ route(match($user->role){'admin_staff'=>'staff.profile','supervisor'=>'supervisor.profile',default=>'admin.profile'}) }}">
        @csrf
        <div class="grid account-profile-fields">
            <label class="field">نام نمایشی<input name="name" value="{{ old('name',$user->name) }}" required maxlength="190"></label>
            <label class="field">ایمیل<input type="email" name="email" value="{{ old('email',$user->email) }}" maxlength="190"></label>
            <label class="field account-profile-upload">تصویر پروفایل<input type="file" name="profile_photo" accept="image/jpeg,image/png,image/webp"><small class="muted">JPG، PNG یا WebP · حداکثر ۵ مگابایت</small></label>
        </div>
        <button class="btn" type="submit">ذخیرهٔ پروفایل</button>
    </form>
</section>
<section class="card account-password-card">
    <h2>تغییر رمز عبور</h2>
    <p class="account-password-help">برای تغییر رمز، رمز فعلی و رمز جدید را وارد کنید.</p>
    <form method="post" action="{{ route(match($user->role){'admin_staff'=>'staff.profile','supervisor'=>'supervisor.profile',default=>'admin.profile'}) }}">
        @csrf
        <input type="hidden" name="change_password" value="1">
        <div class="grid account-password-fields">
            <label class="field">رمز عبور فعلی<input type="password" name="current_password" autocomplete="current-password" required></label>
            <label class="field">رمز عبور جدید<input type="password" name="password" autocomplete="new-password" minlength="10" required><small class="muted">حداقل ۱۰ نویسه</small></label>
            <label class="field">تکرار رمز عبور جدید<input type="password" name="password_confirmation" autocomplete="new-password" minlength="10" required></label>
        </div>
        <button class="btn" type="submit">تغییر رمز عبور</button>
    </form>
</section>
<style>.account-profile-card,.account-password-card{max-width:900px}.account-profile-heading{display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:20px}.account-profile-heading h2{margin:0 0 4px!important}.account-profile-heading p,.account-password-help{margin:0 0 16px;color:var(--muted);font-size:12px}.account-profile-preview{width:76px;height:76px;object-fit:cover;border-radius:22px;border:3px solid #edf2ff}.account-profile-initial{display:grid;place-items:center;background:#edf2ff;color:#477cff;font-size:28px;font-weight:800}.account-profile-fields,.account-password-fields{grid-template-columns:repeat(2,minmax(0,1fr));margin-bottom:18px}.account-profile-upload{grid-column:1/-1}@media(max-width:600px){.account-profile-fields,.account-password-fields{grid-template-columns:1fr}.account-profile-upload{grid-column:auto}}</style>
@endsection
