@extends('layouts.srm',['title'=>'بررسی پروژه'])
@section('content')
<section class="card">
    <div class="row spread"><div><h2>بررسی پروژه: {{ $row->title }}</h2><p class="muted">اطلاعات ثبت‌شده توسط نماینده را ببینید و نتیجهٔ بررسی را ثبت کنید.</p></div><span class="tag">{{ $row->status }}</span></div>
    <div class="grid">
        <div><b>نماینده</b><p>{{ $representative?->name ?? '—' }}</p></div><div><b>مشتری</b><p>{{ $row->customer_name ?: '—' }}</p></div><div><b>موبایل مشتری</b><p>{{ $row->customer_mobile ?: '—' }}</p></div><div><b>استان و شهر</b><p>{{ $row->province }}، {{ $row->city }}</p></div><div><b>مبلغ برآوردی</b><p>{{ $row->estimated_amount !== null ? number_format((float)$row->estimated_amount).' تومان' : '—' }}</p></div><div><b>فرایندها</b><p>{{ implode('،',(array)($row->form_values['_project_processes']??[])) ?: '—' }}</p></div>
    </div>
    <h3>اطلاعات فرم پروژه</h3>
    <div class="stack">@forelse($submittedFields as $item)<div class="card"><b>{{ $item['label'] }}</b><p>@if($item['media_id'])<a href="{{ route($routePrefix.'.content-media.download',$item['media_id']) }}">{{ is_array($item['value'])?($item['value']['name']??'دریافت فایل'):'دریافت فایل' }}</a>@elseif(is_array($item['value'])){{ implode('،',array_map('strval',$item['value'])) ?: '—' }}@else{{ $item['value'] === null || $item['value'] === '' ? '—' : $item['value'] }}@endif</p></div>@empty<p class="muted">اطلاعات فرم اضافه‌ای ثبت نشده است.</p>@endforelse</div>
    @if($attachments->isNotEmpty())<h3>فایل‌های پرونده</h3><ul>@foreach($attachments as $file)<li><a href="{{ route($routePrefix.'.content-media.download',$file->media_id) }}">{{ $file->caption ?: $file->original_name }}</a></li>@endforeach</ul>@endif
</section>
<section class="card"><h2>نتیجهٔ بررسی و نظر مدیر</h2><form method="post" action="{{ route($routePrefix.'.projects.status',$row->id) }}">@csrf
    <div class="grid"><label class="field">نتیجه<select name="status" required>@foreach(['pending'=>'در انتظار بررسی','approved'=>'تأیید','rejected'=>'رد','active'=>'فعال','completed'=>'تکمیل‌شده','cancelled'=>'لغوشده'] as $value=>$label)<option value="{{ $value }}" @selected($row->status===$value)>{{ $label }}</option>@endforeach</select></label></div>
    <label class="field">نظر مدیر<textarea name="manager_note" rows="4">{{ old('manager_note',$row->manager_note) }}</textarea></label><button class="btn">ذخیرهٔ بررسی</button>
</form></section>
@endsection
