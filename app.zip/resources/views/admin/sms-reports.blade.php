@extends('layouts.srm',['title'=>'گزارش پیامک'])
@section('content')
<section class="card"><div class="row spread"><div><h2>عملکرد پیامک‌های سامانه</h2><p class="muted">این گزارش به‌صورت خودکار از رویدادهای ارسال سیستم ساخته می‌شود.</p></div><span class="tag">{{ number_format($rows->total()) }} پیامک</span></div>
    <div class="table-wrap"><table><thead><tr><th>زمان</th><th>نماینده</th><th>گیرنده</th><th>درگاه</th><th>رویداد</th><th>پیام</th><th>وضعیت</th><th>خطا</th></tr></thead><tbody>
        @forelse($rows as $row)<tr><td>{{ $row->created_at }}</td><td>{{ $row->representative_name??'—' }}</td><td dir="ltr">{{ $row->recipient }}</td><td>{{ $row->provider }}</td><td>{{ $row->event_key??'—' }}</td><td class="sms-message-cell">{{ $row->message }}</td><td><span class="tag">{{ $row->status }}</span></td><td>{{ $row->error??'—' }}</td></tr>
        @empty<tr><td colspan="8">گزارش پیامکی ثبت نشده است.</td></tr>@endforelse
    </tbody></table></div><div class="pagination">{{ $rows->links() }}</div>
</section>
@endsection
