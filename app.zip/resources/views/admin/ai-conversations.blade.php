@extends('layouts.srm',['title'=>'گفتگوهای هوش مصنوعی'])
@section('content')
<section class="card ai-admin-list" dir="rtl">
    <div class="ai-admin-heading"><div><h2>گفتگوهای نمایندگان</h2><p>تاریخچهٔ هر نماینده را باز کنید تا پرسش‌ها و پاسخ‌ها را به‌ترتیب بخوانید.</p></div></div>
    <form method="get" action="{{ route('admin.ai-conversations.index') }}" class="ai-search"><label class="field">جستجو بر اساس نام، شماره همراه یا ایمیل<input type="search" name="q" value="{{ $search }}" placeholder="نام نماینده یا شماره همراه"></label><button class="btn" type="submit">جستجو</button>@if($search)<a class="btn alt" href="{{ route('admin.ai-conversations.index') }}">پاک‌کردن</a>@endif</form>
    <div class="table-wrap"><table><thead><tr><th>نماینده</th><th>شماره همراه</th><th>ایمیل</th><th>تعداد پرسش‌ها</th><th>آخرین گفتگو</th><th></th></tr></thead><tbody>
    @forelse($representatives as $item)<tr><td>{{ $item->name }}</td><td>{{ $item->mobile }}</td><td>{{ $item->email }}</td><td>{{ number_format((int)$item->exchange_count) }}</td><td>{{ $item->last_message_at ? \Illuminate\Support\Carbon::parse($item->last_message_at)->format('Y/m/d H:i') : '—' }}</td><td><a class="btn alt" href="{{ route('admin.ai-conversations.show',$item->id) }}">خواندن گفتگوها</a></td></tr>
    @empty<tr><td colspan="6">گفتگویی برای نمایش پیدا نشد.</td></tr>@endforelse
    </tbody></table></div>{{ $representatives->links() }}
</section>
<style>.ai-admin-list{display:grid;gap:16px}.ai-admin-heading h2{margin:0 0 6px}.ai-admin-heading p{margin:0;color:#70818c}.ai-search{display:flex;align-items:end;gap:10px;flex-wrap:wrap}.ai-search .field{flex:1;min-width:240px;margin:0}.ai-search input{display:block;width:100%;padding:10px;border:1px solid #d6e0e4;border-radius:8px}@media(max-width:620px){.ai-search .btn{flex:1}}</style>
@endsection
