@extends('layouts.srm',['title'=>'تنظیمات'])
@section('content')
<div class="settings-page">
    <form method="post" enctype="multipart/form-data" action="{{ route('admin.settings') }}" class="card settings-section">
        @csrf<input type="hidden" name="section" value="general">
        <header><div><h2>تنظیمات عمومی</h2><p>زمینه‌های فعالیت، مراحل پیگیری فروش، برند و تنظیمات پایهٔ سامانه.</p></div></header>
        <div class="settings-brand-panel">
            <div class="settings-brand-preview">@if(!empty($values['system_brand_logo']))<img src="{{ route('brand.logo') }}" alt="لوگوی سامانه">@else<span>{{ mb_substr($values['system_brand_name']??'پیوند',0,1) }}</span>@endif</div>
            <div class="settings-grid settings-brand-fields">
                <label class="field">نام برند سامانه<input name="brand_name" value="{{ old('brand_name',$values['system_brand_name']??'پیوند') }}" maxlength="100" placeholder="پیوند"></label>
                <label class="field">زیرعنوان برند<input name="brand_tagline" value="{{ old('brand_tagline',$values['system_brand_tagline']??'مدیریت ارتباط با نمایندگان فروش') }}" maxlength="160"></label>
                <label class="field settings-brand-logo">لوگوی سامانه<input type="file" name="brand_logo" accept="image/jpeg,image/png,image/webp"><small>JPG، PNG یا WebP · حداکثر ۲ مگابایت</small></label>
            </div>
        </div>
        @error('brand_name')<p class="settings-error">{{ $message }}</p>@enderror @error('brand_tagline')<p class="settings-error">{{ $message }}</p>@enderror @error('brand_logo')<p class="settings-error">{{ $message }}</p>@enderror
        <div class="settings-grid">
            <label class="field">زمینه‌های فعالیت
                <textarea name="segments" rows="6" required placeholder="ساختمان‌سازی&#10;تأسیسات&#10;بازرگانی">{{ old('segments',$values['segments']??'عمومی') }}</textarea>
                <small>هر زمینه را در یک خط بنویسید. همین گزینه‌ها در ثبت‌نام و پروفایل نمایندگان نمایش داده می‌شود.</small>
            </label>
            <label class="field">مراحل فروش
                <textarea name="project_stages" rows="6" required placeholder="سرنخ جدید&#10;ارزیابی نیاز&#10;ارائه پیشنهاد&#10;مذاکره&#10;فروش قطعی">{{ old('project_stages',$values['project_stages']??'سرنخ جدید') }}</textarea>
                <small>این فهرست، گام پیگیری فروش هر پروژه را مشخص می‌کند و در ویرایش پروژه توسط مدیر قابل انتخاب است. با وضعیت پروژه (مثل در انتظار یا تأییدشده) تفاوت دارد.</small>
            </label>
            <label class="field">فرایندهای پروژه
                <textarea name="project_processes" rows="6" placeholder="نقشه‌برداری&#10;گودبرداری&#10;نازک‌کاری">{{ old('project_processes',$values['project_processes']??'') }}</textarea>
                <small>هر فرایند را در یک خط وارد کنید.</small>
            </label>
            <div class="settings-control-stack">
                <label class="field">ماه‌های کم‌فعال<input type="number" min="1" max="60" name="low_activity_months" value="{{ old('low_activity_months',$values['low_activity_months']??3) }}" required></label>
                <label class="field">ماه‌های غیرفعال<input type="number" min="1" max="120" name="inactive_months" value="{{ old('inactive_months',$values['inactive_months']??6) }}" required></label>
                <label class="settings-check"><input type="checkbox" name="project_processes_enabled" value="1" @checked(old('project_processes_enabled',filter_var($values['project_processes_enabled']??false,FILTER_VALIDATE_BOOLEAN)))> نمایش و الزام انتخاب فرایند هنگام معرفی پروژه</label>
                <label class="settings-check"><input type="checkbox" name="require_registration_exam" value="1" @checked(old('require_registration_exam',filter_var($values['require_registration_exam']??false,FILTER_VALIDATE_BOOLEAN)))> آزمون پیش‌ثبت‌نام الزامی باشد</label>
            </div>
        </div>
        @error('segments')<p class="settings-error">{{ $message }}</p>@enderror @error('project_stages')<p class="settings-error">{{ $message }}</p>@enderror @error('project_processes')<p class="settings-error">{{ $message }}</p>@enderror
        <footer><button class="btn" type="submit">ذخیره تنظیمات عمومی</button></footer>
    </form>

    <form method="post" action="{{ route('admin.settings') }}" class="card settings-section">
        @csrf<input type="hidden" name="section" value="sms">
        <header><div><h2>درگاه پیامک</h2><p>تنظیمات ارسال پیامک سامانه را مدیریت کنید.</p></div></header>
        <div class="settings-grid settings-grid-3">
            <label class="settings-check"><input type="checkbox" name="sms_enabled" value="1" @checked(old('sms_enabled',filter_var($values['sms_enabled']??false,FILTER_VALIDATE_BOOLEAN)))> فعال‌سازی پیامک</label>
            <label class="field">ارائه‌دهنده پیامک<select name="sms_provider" required>@foreach(['kavenegar'=>'کاوه‌نگار','smsir'=>'SMS.ir','ippanel'=>'IPPanel','farazsms'=>'فراز اس‌ام‌اس','melipayamak'=>'ملی‌پیامک','ghasedak'=>'قاصدک','first_portal'=>'پنل اول','parsgreen'=>'پارس‌گرین'] as $v=>$text)<option value="{{ $v }}" @selected(old('sms_provider',$values['sms_provider']??'kavenegar')===$v)>{{ $text }}</option>@endforeach</select></label>
            <label class="field">کلید API<input type="password" name="sms_api_key" placeholder="خالی بگذارید تا مقدار فعلی حفظ شود" autocomplete="new-password"></label>
            <label class="field">نام کاربری<input name="sms_username" value="{{ old('sms_username',$values['sms_username']??'') }}"></label>
            <label class="field">رمز عبور<input type="password" name="sms_password" placeholder="خالی بگذارید تا مقدار فعلی حفظ شود" autocomplete="new-password"></label>
            <label class="field">شماره خط<input name="sms_line_number" value="{{ old('sms_line_number',$values['sms_line_number']??'') }}"></label>
        </div>
        @error('sms_provider')<p class="settings-error">{{ $message }}</p>@enderror
        <footer><button class="btn" type="submit">ذخیره تنظیمات درگاه پیامک</button></footer>
    </form>

    <form method="post" action="{{ route('admin.settings') }}" class="card settings-section" id="aiSettingsForm">
        @csrf<input type="hidden" name="section" value="ai">
        <header><div><h2>دستیار هوشمند</h2><p>اتصال ثابت به HeroAI.ir؛ کلید را وارد کنید و فهرست مدل‌ها را دریافت کنید.</p></div></header>
        <div class="settings-grid settings-grid-3">
            <label class="settings-check"><input type="checkbox" name="ai_enabled" value="1" @checked(old('ai_enabled',filter_var($values['ai_enabled']??false,FILTER_VALIDATE_BOOLEAN)))> فعال‌سازی AI</label>
            <label class="field">کلید API هوش مصنوعی<input type="password" id="aiApiKey" name="ai_api_key" placeholder="خالی بگذارید تا مقدار فعلی حفظ شود" autocomplete="new-password"></label>
            <label class="field">مدل HeroAI.ir<select name="ai_model" id="aiModelSelect"><option value="{{ old('ai_model',$values['ai_model']??'') }}">{{ old('ai_model',$values['ai_model']??'ابتدا مدل‌ها را دریافت کنید') }}</option></select><button class="btn alt" type="button" id="loadAiModels" style="margin-top:8px">دریافت مدل‌ها از HeroAI.ir</button><small id="aiModelStatus" aria-live="polite">پس از واردکردن کلید، فهرست مدل‌ها را دریافت کنید.</small></label>
            <label class="field">سقف روزانه هر نماینده<input type="number" name="ai_daily_limit" min="1" max="100000" value="{{ old('ai_daily_limit',$values['ai_daily_limit']??20) }}" required></label>
            <label class="field">حداکثر توکن پاسخ AI<input type="number" name="ai_max_output_tokens" min="1" max="100000" value="{{ old('ai_max_output_tokens',$values['ai_max_output_tokens']??1000) }}" required></label>
            <label class="field">مهلت اتصال (ثانیه)<input type="number" name="ai_timeout" min="1" max="180" value="{{ old('ai_timeout',$values['ai_timeout']??30) }}" required></label>
            <label class="field settings-full">یادداشت دانش AI<textarea name="ai_knowledge_notes" rows="5">{{ old('ai_knowledge_notes',$values['ai_knowledge_notes']??'') }}</textarea><small>این یادداشت به‌عنوان راهنمای پاسخ‌گویی به دستیار افزوده می‌شود.</small></label>
        </div>
        <footer><button class="btn" type="submit">ذخیره تنظیمات دستیار هوشمند</button></footer>
    </form>

    <form method="post" action="{{ route('admin.settings') }}" class="card settings-section">
        @csrf<input type="hidden" name="section" value="points">
        <header><div><h2>مدیریت امتیازها</h2><p>برای هر فعالیت، امتیاز دلخواه را وارد کنید. فیلد خالی یعنی از آن فعالیت امتیازی داده نشود؛ امتیاز هر فعالیت برای هر رکورد فقط یک‌بار محاسبه می‌شود.</p></div></header>
        <div class="settings-grid settings-grid-3">
            @foreach($activityLabels as $key=>$label)
                <label class="field">{{ $label }}<input type="number" name="activity_points[{{ $key }}]" min="0" max="100000" value="{{ old('activity_points.'.$key,$values['activity_points'][$key]??'') }}" placeholder="خالی = بدون امتیاز"></label>
            @endforeach
        </div>
        @foreach($activityLabels as $key=>$label)@error('activity_points.'.$key)<p class="settings-error">{{ $message }}</p>@enderror @endforeach
        <footer><button class="btn" type="submit">ذخیره مدیریت امتیازها</button></footer>
    </form>

    <form method="post" action="{{ route('admin.settings') }}" class="card settings-section" id="rankSettingsForm">
        @csrf<input type="hidden" name="section" value="ranks">
        <header><div><h2>رتبه‌بندی نمایندگان</h2><p>برای هر رتبه، نام و بازهٔ امتیاز را تعیین کنید. رتبهٔ منطبق با امتیاز کل نماینده در داشبورد او نمایش داده می‌شود. بازه‌ها باید از صفر و بدون فاصله یا هم‌پوشانی باشند؛ «تا» را فقط برای آخرین رتبه خالی بگذارید.</p></div></header>
        <div class="rank-list-heading"><span>نام رتبه</span><span>از امتیاز</span><span>تا امتیاز</span><span></span></div>
        <div id="rankRows">
            @foreach(old('ranks',$values['ranks']) as $index=>$rank)
                <div class="rank-row"><label class="field"><span class="sr-only">نام رتبه</span><input name="ranks[{{ $index }}][title]" value="{{ old('ranks.'.$index.'.title',$rank['title']) }}" placeholder="مثلاً برنزی" required></label><label class="field"><span class="sr-only">از امتیاز</span><input type="number" min="0" name="ranks[{{ $index }}][min]" value="{{ old('ranks.'.$index.'.min',$rank['min']) }}" placeholder="از" required></label><label class="field"><span class="sr-only">تا امتیاز</span><input type="number" min="0" name="ranks[{{ $index }}][max]" value="{{ old('ranks.'.$index.'.max',$rank['max']??'') }}" placeholder="بدون سقف"></label><button class="btn danger remove-rank" type="button" aria-label="حذف رتبه">حذف</button></div>
            @endforeach
        </div>
        <div class="rank-actions"><button class="btn alt" type="button" id="addRank">افزودن رتبه</button></div>
        @error('ranks')<p class="settings-error">{{ $message }}</p>@enderror @foreach($values['ranks'] as $index=>$rank)@error('ranks.'.$index.'.title')<p class="settings-error">{{ $message }}</p>@enderror @error('ranks.'.$index.'.min')<p class="settings-error">{{ $message }}</p>@enderror @error('ranks.'.$index.'.max')<p class="settings-error">{{ $message }}</p>@enderror @endforeach
        <footer><button class="btn" type="submit">ذخیره رتبه‌بندی</button></footer>
    </form>
</div>
<p class="muted admin-settings-note">نشانی اتصال به HeroAI.ir ثابت است و کلید API در مرورگر ذخیره نمی‌شود. کلیدهای پیامک و هوش مصنوعی خالی، مقدار فعلی را حفظ می‌کنند.</p>
<style>
.settings-page{display:grid;gap:18px}.settings-section{padding:22px}.settings-section>header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:18px}.settings-section h2{margin:0 0 6px}.settings-section header p{margin:0;color:var(--muted,#64748b);max-width:850px;line-height:1.9}.settings-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.settings-grid-3{grid-template-columns:repeat(3,minmax(0,1fr))}.settings-grid .field{margin:0}.settings-grid textarea{resize:vertical;line-height:1.9}.settings-grid small{display:block;color:var(--muted,#64748b);margin-top:6px;line-height:1.8}.settings-control-stack{display:grid;gap:12px}.settings-check{display:flex;align-items:center;gap:10px;min-height:42px;padding:10px 12px;border:1px solid var(--line,#dce5ec);border-radius:10px;background:#fafcfd}.settings-check input{width:18px;height:18px}.settings-section footer{display:flex;justify-content:flex-end;border-top:1px solid var(--line,#e5eaf0);padding-top:16px;margin-top:18px}.settings-error{color:#b42318;margin:8px 0}.settings-full{grid-column:1/-1}.rank-list-heading,.rank-row{display:grid;grid-template-columns:minmax(180px,2fr) minmax(110px,1fr) minmax(110px,1fr) 76px;gap:12px;align-items:center}.rank-list-heading{padding:0 8px 8px;color:var(--muted,#64748b);font-size:13px}.rank-row{padding:10px;margin-bottom:8px;border:1px solid var(--line,#dce5ec);border-radius:12px;background:#fbfdfe}.rank-row .field{margin:0}.rank-actions{margin-top:12px}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:900px){.settings-grid-3{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:650px){.settings-grid,.settings-grid-3{grid-template-columns:1fr}.rank-list-heading{display:none}.rank-row{grid-template-columns:1fr 1fr}.rank-row .field:first-child{grid-column:1/-1}.rank-row .remove-rank{justify-self:start}}
.settings-brand-panel{display:grid;grid-template-columns:88px minmax(0,1fr);gap:18px;align-items:center;margin:0 0 18px;padding:16px;border:1px solid #edf0f4;border-radius:12px;background:#fafbfc}.settings-brand-preview{width:76px;height:76px;display:grid;place-items:center;overflow:hidden;border-radius:18px;background:#edf2ff;color:#477cff;font-size:28px;font-weight:800}.settings-brand-preview img{width:100%;height:100%;object-fit:contain;padding:8px}.settings-brand-fields{grid-template-columns:repeat(2,minmax(0,1fr))}.settings-brand-fields .field{margin:0}.settings-brand-logo{grid-column:1/-1}@media(max-width:650px){.settings-brand-panel{grid-template-columns:1fr}.settings-brand-fields{grid-template-columns:1fr}.settings-brand-logo{grid-column:auto}}
</style>
<script>
(function(){
    var rows=document.getElementById('rankRows'),add=document.getElementById('addRank');
    if(rows&&add){var nextIndex=rows.querySelectorAll('.rank-row').length;function bindRemove(button){button.addEventListener('click',function(){if(rows.querySelectorAll('.rank-row').length>1)button.closest('.rank-row').remove();});}rows.querySelectorAll('.remove-rank').forEach(bindRemove);add.addEventListener('click',function(){var row=document.createElement('div');row.className='rank-row';row.innerHTML='<label class="field"><span class="sr-only">نام رتبه</span><input name="ranks['+nextIndex+'][title]" placeholder="مثلاً برنزی" required></label><label class="field"><span class="sr-only">از امتیاز</span><input type="number" min="0" name="ranks['+nextIndex+'][min]" placeholder="از" required></label><label class="field"><span class="sr-only">تا امتیاز</span><input type="number" min="0" name="ranks['+nextIndex+'][max]" placeholder="بدون سقف"></label><button class="btn danger remove-rank" type="button">حذف</button>';rows.appendChild(row);bindRemove(row.querySelector('.remove-rank'));nextIndex++;});}
    var button=document.getElementById('loadAiModels');if(!button)return;button.addEventListener('click',async function(){var status=document.getElementById('aiModelStatus'),key=document.getElementById('aiApiKey').value,select=document.getElementById('aiModelSelect');button.disabled=true;status.textContent='در حال دریافت مدل‌ها…';try{var response=await fetch(@json(route('admin.settings.ai-models')),{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').content,'X-Requested-With':'XMLHttpRequest'},body:JSON.stringify({api_key:key})});var result=await response.json();if(!response.ok)throw new Error(result.message||'دریافت مدل‌ها انجام نشد.');var selected=select.value;select.replaceChildren();result.models.forEach(function(model){var option=document.createElement('option');option.value=model;option.textContent=model;select.appendChild(option);});if(result.models.includes(selected))select.value=selected;status.textContent=result.models.length+' مدل دریافت شد.';}catch(error){status.textContent=error.message;}finally{button.disabled=false;}});
})();
</script>
@endsection
