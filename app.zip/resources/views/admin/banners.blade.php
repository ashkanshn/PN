@extends('layouts.srm',['title'=>'مدیریت بنرها'])
@section('content')
<div class="banner-admin-page" dir="rtl">
    <section class="banner-card">
        <h2>بارگذاری بنر داشبورد نماینده</h2>
        <p>تصویر باید دقیقاً ۱۰۶۴ در ۱۲۰ پیکسل و از نوع JPG یا PNG باشد. برای هر زمینهٔ فعالیت فقط یک بنر نگهداری می‌شود؛ بارگذاری دوباره برای همان مورد، بنر قبلی را جایگزین می‌کند.</p>
        <form method="post" enctype="multipart/form-data" action="{{ route('admin.banners.store') }}" class="banner-upload-form">
            @csrf
            <label class="field">محل نمایش
                <select name="scope" required>
                    <option value="*" @selected(old('scope')==='*')>نمایش برای همهٔ نمایندگان</option>
                    @foreach($segments as $key=>$label)<option value="{{ $key }}" @selected(old('scope')===(string)$key)>{{ $label }}</option>@endforeach
                </select>
            </label>
            <label class="field">فایل بنر
                <input type="file" name="banner" accept="image/jpeg,image/png" required>
                <small>فرمت JPG یا PNG · حداکثر ۵ مگابایت · ابعاد دقیق ۱۰۶۴ × ۱۲۰</small>
            </label>
            <button class="btn" type="submit">بارگذاری و فعال‌سازی</button>
        </form>
    </section>

    <section class="banner-card">
        <div class="banner-list-heading"><div><h2>بنرهای فعال</h2><p>نماینده بنر زمینهٔ فعالیت اصلی خود را می‌بیند؛ اگر برای آن زمینه بنری نباشد، بنر عمومی نمایش داده می‌شود.</p></div><span>{{ count($rows) }} بنر</span></div>
        @if($rows)
            <div class="banner-list">
                @foreach($rows as $row)
                    <article class="banner-row">
                        <div class="banner-preview"><img src="{{ $row['image_url'] }}" alt="بنر {{ $row['label'] }}"></div>
                        <div class="banner-row-meta"><strong>{{ $row['label'] }}</strong><small>{{ $row['updated_at'] ? \Illuminate\Support\Carbon::parse($row['updated_at'])->format('Y/m/d H:i') : '' }}</small></div>
                        <form method="post" action="{{ route('admin.banners.delete') }}" onsubmit="return confirm('این بنر حذف شود؟')">
                            @csrf @method('DELETE')<input type="hidden" name="scope" value="{{ $row['scope'] }}"><button class="btn danger" type="submit">حذف بنر</button>
                        </form>
                    </article>
                @endforeach
            </div>
        @else
            <div class="banner-empty">هنوز بنری بارگذاری نشده است.</div>
        @endif
    </section>
</div>
<style>
.banner-admin-page{display:grid;gap:18px}.banner-card{padding:22px;background:#fff;border:1px solid #e2e9ed;border-radius:15px;box-shadow:0 8px 24px #15303d0a}.banner-card h2{margin:0 0 8px;font-size:17px}.banner-card p{margin:0 0 17px;color:#71818a;font-size:13px;line-height:1.8}.banner-upload-form{display:grid;grid-template-columns:minmax(220px,1fr) minmax(260px,1.5fr) auto;align-items:end;gap:14px}.banner-upload-form .field{display:grid;gap:8px;font-weight:700}.banner-upload-form select,.banner-upload-form input{min-height:43px;padding:9px 12px;border:1px solid #d7e0e4;border-radius:9px;background:#fff;font:inherit}.banner-upload-form small{font-size:11px;font-weight:400;color:#71818a}.banner-list-heading{display:flex;justify-content:space-between;align-items:center;gap:12px}.banner-list-heading>span{padding:6px 10px;border-radius:999px;background:#eaf5f3;color:#087f75;font-size:12px}.banner-list{display:grid;gap:12px}.banner-row{display:grid;grid-template-columns:minmax(250px,1fr) minmax(150px,.5fr) auto;align-items:center;gap:16px;padding:12px;border:1px solid #e5ebee;border-radius:12px}.banner-preview{overflow:hidden;border:1px solid #e1e7ea;border-radius:7px;background:#f5f7f8;aspect-ratio:1064/120}.banner-preview img{display:block;width:100%;height:100%;object-fit:cover}.banner-row-meta{display:grid;gap:6px}.banner-row-meta small{color:#829098;font-size:11px}.banner-empty{padding:25px;border-radius:10px;background:#f5f8f9;color:#71818a;text-align:center}.btn.danger{background:#fff0f0;color:#a3323d;border:1px solid #f0cdd0}@media(max-width:760px){.banner-upload-form{grid-template-columns:1fr}.banner-upload-form .btn{width:100%}.banner-row{grid-template-columns:1fr}.banner-row-meta{padding:2px 0}.banner-row form .btn{width:100%}}
</style>
@endsection
