@extends('layouts.srm',['title'=>'گفتگوهای نماینده'])
@section('content')
<section class="card ai-admin-transcript" dir="rtl">
    <div class="ai-admin-heading"><div><h2>{{ $representative->name }}</h2><p>{{ $representative->mobile }} · {{ $representative->email }}</p></div><a class="btn alt" href="{{ route('admin.ai-conversations.index') }}">بازگشت به فهرست گفتگوها</a></div>
    <div class="ai-transcript">
        @forelse($exchanges as $exchange)
            @php($messages=json_decode((string)$exchange->messages,true)?:[])
            <article class="ai-exchange"><time>{{ \Illuminate\Support\Carbon::parse($exchange->created_at)->format('Y/m/d H:i') }} · {{ number_format((int)$exchange->tokens_used) }} توکن</time>
                @foreach($messages as $message)<div class="ai-message {{ ($message['role']??'user')==='assistant'?'ai-message-answer':'ai-message-question' }}"><strong>{{ ($message['role']??'user')==='assistant'?'پاسخ هوش مصنوعی':'پرسش نماینده' }}</strong><p>{{ (string)($message['content']??'') }}</p></div>@endforeach
            </article>
        @empty<div class="muted">گفتگویی ثبت نشده است.</div>@endforelse
    </div>{{ $exchanges->links() }}
</section>
<style>.ai-admin-transcript{display:grid;gap:16px}.ai-admin-heading{display:flex;justify-content:space-between;align-items:center;gap:14px}.ai-admin-heading h2{margin:0 0 5px}.ai-admin-heading p{margin:0;color:#70818c}.ai-transcript{display:grid;gap:14px}.ai-exchange{display:grid;gap:9px;padding:14px;border:1px solid #e1e8eb;border-radius:12px;background:#f8fafb}.ai-exchange>time{font-size:11px;color:#7b8a93}.ai-message{max-width:900px;padding:12px 14px;border-radius:10px;white-space:pre-wrap;overflow-wrap:anywhere}.ai-message strong{display:block;margin-bottom:5px;font-size:12px}.ai-message p{margin:0;line-height:1.9}.ai-message-question{justify-self:start;background:#e8f4f5}.ai-message-answer{justify-self:stretch;background:#fff;border:1px solid #e7edef}@media(max-width:650px){.ai-admin-heading{align-items:stretch;flex-direction:column}.ai-admin-heading .btn{width:100%}}</style>
@endsection
