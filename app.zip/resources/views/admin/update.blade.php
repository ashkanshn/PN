@extends('layouts.srm',['title'=>'به‌روزرسانی سامانه'])
@section('content')
<div class="admin-stack">
    <section class="card">
        <h2>نصب به‌روزرسانی</h2>
        <p>بستهٔ ZIP نسخهٔ جدید را بارگذاری کنید. سامانه فایل‌های کد را مرحله‌به‌مرحله جایگزین می‌کند و در صورت بروز خطا، فایل‌های قبلی را خودکار بازمی‌گرداند.</p>
        <div class="flash" style="background:#f2f8fb;border-color:#d5e6ee">
            این فرایند به نصب مجدد نیاز ندارد و به پایگاه‌داده دست نمی‌زند. فایل <code dir="ltr">.env</code>، تنظیمات هاست، فایل‌های رسانه‌ای و بارگذاری‌شده، <code dir="ltr">vendor</code> و migrationها حفظ می‌شوند. بسته باید فایل‌های پروژه را مستقیماً در ریشهٔ ZIP داشته باشد. تغییر وابستگی‌های Composer یا ساختار پایگاه‌داده از این بخش پشتیبانی نمی‌شود.
        </div>
        <form id="systemUpdateForm" method="post" enctype="multipart/form-data" action="{{ route('admin.update.upload') }}">
            @csrf
            <label class="field">بستهٔ به‌روزرسانی ZIP
                <input type="file" name="package" accept=".zip,application/zip" required>
            </label>
            <label class="field">برای تأیید عملیات، رمز مدیر را وارد کنید
                <input type="password" name="password" autocomplete="current-password" required>
            </label>
            <button class="btn" type="submit" id="systemUpdateSubmit">بارگذاری و شروع به‌روزرسانی</button>
        </form>
        <section id="updateProgress" hidden aria-live="polite" style="margin-top:22px">
            <h3 id="updateStatusTitle">آماده‌سازی</h3>
            <p id="updateStatusMessage" class="muted">در حال آماده‌سازی...</p>
            <progress id="updateProgressBar" max="100" value="0" style="width:100%;height:18px"></progress>
            <div id="updateProgressCount" class="muted" style="margin-top:6px"></div>
            <ol id="updateStages" style="line-height:2.1">
                <li data-stage="upload">بارگذاری بسته</li>
                <li data-stage="verify">بررسی ساختار و فایل‌ها</li>
                <li data-stage="backup">ذخیرهٔ نسخهٔ بازگشت</li>
                <li data-stage="apply">جایگزینی فایل‌های برنامه</li>
                <li data-stage="finish">پاک‌سازی cache و بررسی نتیجه</li>
            </ol>
        </section>
    </section>
</div>
<script>
(function(){
    var form=document.getElementById('systemUpdateForm');
    if(!form||form.dataset.bound==='1')return;
    form.dataset.bound='1';
    var panel=document.getElementById('updateProgress');
    var bar=document.getElementById('updateProgressBar');
    var message=document.getElementById('updateStatusMessage');
    var title=document.getElementById('updateStatusTitle');
    var count=document.getElementById('updateProgressCount');
    var submit=document.getElementById('systemUpdateSubmit');
    var stages=Array.from(document.querySelectorAll('#updateStages [data-stage]'));
    function stage(name,state){var item=stages.find(function(node){return node.dataset.stage===name});if(item){item.style.color=state==='done'?'#18794e':state==='active'?'#087f83':state==='error'?'#b53f48':'';item.style.fontWeight=state==='active'||state==='error'?'700':'';if(state==='done'&&!item.textContent.startsWith('✓'))item.textContent='✓ '+item.textContent;}}
    function setProgress(value,text){bar.value=Math.max(0,Math.min(100,value));if(text)count.textContent=text;}
    function fail(text){title.textContent='به‌روزرسانی ناموفق';message.textContent=text;message.className='error';stage('apply','error');submit.disabled=false;}
    async function advance(id){
        var lastError;
        for(var attempt=0;attempt<3;attempt++){
            try{
                var response=await fetch(@json(route('admin.update.advance',['id'=>'__UPDATE_ID__'])).replace('__UPDATE_ID__',encodeURIComponent(id)),{method:'POST',credentials:'same-origin',headers:{'X-CSRF-TOKEN':form.querySelector('[name="_token"]').value,'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}});
                var data=await response.json();
                if(!response.ok)throw new Error(data.message||'ادامهٔ به‌روزرسانی از سرور پاسخ نگرفت.');
                return data;
            }catch(error){lastError=error;if(attempt<2)await new Promise(function(resolve){window.setTimeout(resolve,1000*(attempt+1))});}
        }
        throw lastError||new Error('ارتباط با سرور برقرار نشد.');
    }
    function upload(){return new Promise(function(resolve,reject){
        var xhr=new XMLHttpRequest();xhr.open('POST',form.action);xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');xhr.setRequestHeader('Accept','application/json');
        xhr.upload.onprogress=function(event){if(event.lengthComputable){setProgress(Math.round(event.loaded/event.total*20),'بارگذاری بسته: '+Math.round(event.loaded/event.total*100)+'٪');}};
        xhr.onload=function(){var data;try{data=JSON.parse(xhr.responseText)}catch(e){reject(new Error('پاسخ سرور قابل خواندن نیست.'));return;}if(xhr.status<200||xhr.status>=300){reject(new Error(data.message||'بارگذاری بسته ناموفق بود.'));return;}resolve(data);};
        xhr.onerror=function(){reject(new Error('ارتباط هنگام بارگذاری قطع شد.'));};xhr.send(new FormData(form));
    });}
    form.addEventListener('submit',async function(event){
        event.preventDefault();event.stopImmediatePropagation();
        if(!form.reportValidity())return;
        submit.disabled=true;panel.hidden=false;message.className='muted';title.textContent='در حال بارگذاری';message.textContent='بستهٔ به‌روزرسانی در حال بارگذاری است.';setProgress(0,'');stage('upload','active');
        try{
            var staged=await upload();stage('upload','done');stage('verify','done');title.textContent='در حال به‌روزرسانی';message.textContent='بسته معتبر است؛ در حال ذخیرهٔ نسخه‌های بازگشت و اعمال فایل‌ها.';stage('backup','active');
            var state;
            do{
                state=await advance(staged.id);
                if(state.status==='failed'){fail(state.message);return;}
                stage('backup','done');stage('apply',state.status==='complete'||state.status==='finalizing'?'done':'active');
                var percent=20+Math.round((state.percent||0)*.7);setProgress(percent,'فایل‌های اعمال‌شده: '+state.completed+' از '+state.total);
                message.textContent=state.message;
            }while(state.status!=='complete'&&state.status!=='failed');
            stage('apply','done');stage('finish','active');
            title.textContent='به‌روزرسانی موفق';message.textContent=state.message;message.className='flash';setProgress(100,'تمام مراحل با موفقیت انجام شد.');stage('finish','done');
        }catch(error){fail(error.message||'خطای ناشناخته هنگام به‌روزرسانی.');}
    },true);
})();
</script>
@endsection
