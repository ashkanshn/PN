@extends('layouts.srm',['title'=>'پشتیبان‌گیری و بازیابی'])
@section('content')
<div class="admin-stack">
    <section class="card">
        <div class="admin-section-heading"><div><h2>پشتیبان‌گیری خودکار</h2><p>تناوب تهیهٔ پشتیبان را انتخاب کنید. این پشتیبان فقط داده‌های پایگاه‌داده را شامل می‌شود؛ فایل‌های بارگذاری‌شده باید جداگانه از storage/app/private نگهداری شوند.</p></div></div>
        <form method="post" action="{{ route('admin.backup.schedule.update') }}" class="row">
            @csrf
            <label class="field">تناوب پشتیبان‌گیری<select name="frequency"><option value="off" @selected($frequency==='off')>خاموش</option><option value="daily" @selected($frequency==='daily')>روزانه</option><option value="weekly" @selected($frequency==='weekly')>هفتگی</option><option value="monthly" @selected($frequency==='monthly')>ماهانه</option></select></label>
            <button class="btn" type="submit">ذخیره زمان‌بندی</button>
        </form>
        @if($frequency!=='off'&&$scheduleUrl)
            <div class="flash"><strong>یک‌بار در سی‌پنل تنظیم کنید:</strong> در بخش Cron Jobs، یک کار روزانه (مثلاً ساعت ۲ بامداد) بسازید و دستور زیر را وارد کنید. سیستم مطابق تناوب انتخاب‌شده، فقط هنگام سررسید نسخه می‌سازد؛ برای این کار SSH لازم نیست.<br><code dir="ltr" style="display:block;overflow-wrap:anywhere;margin-top:8px">curl -fsS '{{ $scheduleUrl }}' &gt;/dev/null 2&gt;&amp;1</code></div>
        @elseif($frequency==='off')
            <p class="muted">برای اجرای خودکار باید Cron Job سی‌پنل روزی یک‌بار این برنامه را فراخوانی کند؛ سی‌پنل از طریق پنل وب قابل تنظیم است.</p>
        @endif
    </section>

    <section class="card">
        <div class="row spread"><div><h2>نسخه‌های پشتیبان ذخیره‌شده</h2><p class="muted">فایل‌ها در فضای خصوصی برنامه، خارج از دسترس مستقیم وب، ذخیره می‌شوند.</p></div>
            <form method="post" action="{{ route('admin.backup.create') }}">@csrf<button class="btn" type="submit">تهیهٔ پشتیبان همین حالا</button></form>
        </div>
        <div class="table-wrap"><table><thead><tr><th>نام فایل</th><th>زمان</th><th>حجم</th><th>عملیات</th></tr></thead><tbody>
        @forelse($files as $file)
            <tr><td dir="ltr">{{ $file['filename'] }}</td><td>{{ date('Y/m/d H:i',$file['created_at']) }}</td><td>{{ number_format($file['size']/1024,1) }} KB</td><td class="row">
                <a class="btn alt" href="{{ route('admin.backup.download',$file['filename']) }}">دانلود</a>
                <form method="post" action="{{ route('admin.backup.restore-saved',$file['filename']) }}" class="row" onsubmit="return confirm('اطلاعات فعلی با این نسخه جایگزین می‌شود. ادامه می‌دهید؟')">@csrf<input type="hidden" name="confirmation" value="RESTORE"><input type="password" name="password" required placeholder="رمز مدیر" aria-label="رمز مدیر برای بازیابی"><button class="btn danger" type="submit">بازیابی</button></form>
                <form method="post" action="{{ route('admin.backup.delete',$file['filename']) }}" onsubmit="return confirm('این فایل پشتیبان حذف شود؟')">@csrf @method('DELETE')<button class="btn alt" type="submit">حذف</button></form>
            </td></tr>
        @empty
            <tr><td colspan="4">هنوز نسخهٔ پشتیبانی ذخیره نشده است.</td></tr>
        @endforelse
        </tbody></table></div>
    </section>

    <section class="card">
        <h2>بازیابی از فایل JSON</h2>
        <p class="error">بازیابی، داده‌های فعلی پایگاه‌داده را جایگزین می‌کند. پیش از اجرا، یک نسخهٔ پشتیبان تازه بگیرید.</p>
        <form method="post" enctype="multipart/form-data" action="{{ route('admin.backup.restore') }}" class="grid">@csrf
            <label class="field">فایل JSON<input type="file" name="backup" accept=".json,application/json" required></label>
            <label class="field">رمز مدیر<input type="password" name="password" required></label>
            <label class="field">برای تأیید عبارت RESTORE را وارد کنید<input name="confirmation" required></label>
            <div class="admin-form-actions"><button class="btn danger" type="submit">بازیابی فایل</button></div>
        </form>
    </section>
</div>
@endsection
