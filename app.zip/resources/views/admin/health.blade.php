@extends('layouts.srm',['title'=>'تست سلامت سامانه'])
@section('content')
<div class="health-page" dir="rtl" data-current-role="{{ $currentRole }}">
    <section class="health-intro">
        <div><span class="health-kicker">بررسی فنی و مسیرها</span><h1>تست سلامت سامانه</h1><p>بررسی خواندنی اتصال پایگاه‌داده، فایل‌ها، cache، ثبت خطا، قالب‌ها و نشانی‌های اصلی. آزمون‌های مرورگر با نشست فعلی شما انجام می‌شوند.</p><small>آخرین بررسی سرور: {{ $checkedAt }}</small></div>
        <button class="btn" type="button" id="health-run">اجرای دوبارهٔ بررسی‌ها</button>
    </section>
    <section class="health-summary" aria-live="polite">
        <div class="health-summary-card"><strong>{{ count($checks) }}</strong><span>بررسی سرور</span></div>
        <div class="health-summary-card {{ $failedCount?'is-fail':'is-ok' }}"><strong>{{ $failedCount }}</strong><span>مورد نیازمند رفع</span></div>
        <div class="health-summary-card {{ $warningCount?'is-warning':'is-ok' }}"><strong>{{ $warningCount }}</strong><span>هشدار</span></div>
        <div class="health-summary-card"><strong id="browser-total">۰</strong><span>بررسی مرورگر</span></div>
    </section>
    <section class="health-card">
        <header><div><h2>وضعیت سرور</h2><p>مواردی که در این اجرا به‌صورت مستقیم بررسی شده‌اند.</p></div></header>
        <div class="health-grid">
            @foreach($checks as $check)
                <article class="health-check {{ 'status-'.$check['status'] }}"><div><strong>{{ $check['label'] }}</strong><span class="health-status">{{ ['ok'=>'سالم','warning'=>'هشدار','fail'=>'خطا'][$check['status']] }}</span></div><p>{{ $check['details'] }}</p></article>
            @endforeach
        </div>
    </section>
    <section class="health-card">
        <header><div><h2>نشانی‌های اصلی سامانه</h2><p>نشانی‌ها از routeهای ثبت‌شده ساخته شده‌اند؛ دکمهٔ بررسی، پاسخ واقعی GET را با نشست فعلی می‌سنجد.</p></div><span id="route-progress" class="health-status status-pending">در انتظار بررسی</span></header>
        <div class="table-wrap"><table class="health-routes"><thead><tr><th>بخش</th><th>نشانی</th><th>دسترسی موردنیاز</th><th>ثبت مسیر</th><th>پاسخ مرورگر</th><th></th></tr></thead><tbody>
        @foreach($routeChecks as $routeCheck)
            <tr data-health-route data-url="{{ $routeCheck['url'] }}" data-required-role="{{ $routeCheck['role'] }}" data-registered="{{ $routeCheck['registered']?'1':'0' }}">
                <td>{{ $routeCheck['label'] }}</td><td dir="ltr"><a href="{{ $routeCheck['url'] }}" target="_blank" rel="noopener">{{ $routeCheck['url'] }}</a></td><td>{{ ['public'=>'عمومی','admin'=>'مدیر کل','admin_staff'=>'همکار مدیر','supervisor'=>'سرپرست','ambassador'=>'نماینده'][$routeCheck['role']]??$routeCheck['role'] }}</td>
                <td><span class="health-status {{ $routeCheck['registered']?'status-ok':'status-fail' }}">{{ $routeCheck['registered']?'ثبت شده':'پیدا نشد' }}</span></td><td data-probe-result><span class="health-status status-pending">بررسی نشده</span></td><td><button class="btn alt health-probe" type="button" {{ $routeCheck['registered']?'':'disabled' }}>بررسی GET</button></td>
            </tr>
        @endforeach
        </tbody></table></div>
        <p class="health-note">نشانی‌های پنل با نقش مجاز خودشان به‌صورت کامل بررسی می‌شوند. برای نقش‌های دیگر، پاسخ 403 در نشست فعلی نتیجهٔ مورد انتظار کنترل دسترسی است و در کنار بررسی سروری مسیر نمایش داده می‌شود. عملیات POST مانند ساخت یا حذف رکورد اجرا نمی‌شوند تا دادهٔ واقعی تغییر نکند.</p>
    </section>
    <section class="health-card">
        <header><div><h2>قابلیت‌های مرورگر</h2><p>ویژگی‌های لازم برای فرم‌ها، درخواست Ajax و رابط کاربری.</p></div></header>
        <div id="browser-checks" class="health-grid"></div>
    </section>
</div>
<style>
.health-page{display:grid;gap:18px;color:#203844}.health-intro,.health-card{background:#fff;border:1px solid #e1e9eb;border-radius:16px;box-shadow:0 8px 24px #18343d0b}.health-intro{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:24px}.health-intro h1{font-size:24px;margin:7px 0}.health-intro p,.health-card header p{color:#71838d;margin:4px 0 8px;line-height:1.8}.health-intro small{color:#82939b}.health-kicker{color:#087f83;font-size:12px;font-weight:800}.health-summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}.health-summary-card{background:#fff;border:1px solid #e1e9eb;border-radius:13px;padding:16px}.health-summary-card strong{display:block;color:#087f83;font-size:27px}.health-summary-card span{color:#71838d;font-size:12px}.health-summary-card.is-fail strong{color:#b53f48}.health-summary-card.is-warning strong{color:#9a6d16}.health-card{padding:20px}.health-card>header{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:15px}.health-card h2{font-size:17px;margin:0}.health-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px}.health-check{border:1px solid #e6ecee;border-right:4px solid #82939b;border-radius:10px;padding:12px}.health-check.status-ok{border-right-color:#21825b}.health-check.status-warning{border-right-color:#bd871d}.health-check.status-fail{border-right-color:#bd4650}.health-check>div{display:flex;justify-content:space-between;align-items:center;gap:8px}.health-check p{font-size:12px;line-height:1.7;color:#71838d;margin:8px 0 0;overflow-wrap:anywhere}.health-status{display:inline-block;border-radius:999px;padding:4px 9px;background:#eef2f4;color:#5f7078;font-size:11px;white-space:nowrap}.status-ok .health-status,.health-status.status-ok{background:#e6f5ed;color:#176742}.status-warning .health-status,.health-status.status-warning{background:#fff4d9;color:#805b12}.status-fail .health-status,.health-status.status-fail{background:#ffeaeb;color:#9e303c}.health-status.status-pending{background:#edf1f4;color:#687982}.health-routes{min-width:780px}.health-routes td{vertical-align:middle}.health-routes a{color:#087f83}.health-routes .btn{padding:7px 10px;font-size:11px}.health-note{margin:14px 0 0;padding:12px;border-radius:9px;background:#f2f7f8;color:#637780;font-size:12px;line-height:1.8}.health-probe[disabled]{opacity:.45;cursor:not-allowed}@media(max-width:650px){.health-intro{align-items:stretch;flex-direction:column}.health-intro .btn{width:100%}.health-card{padding:15px}}
</style>
<script>
(()=>{'use strict';const page=document.querySelector('.health-page');if(!page)return;const currentRole=page.dataset.currentRole;const rows=Array.from(document.querySelectorAll('[data-health-route]'));const browserBox=document.getElementById('browser-checks');const total=document.getElementById('browser-total');const progress=document.getElementById('route-progress');
function browserCheck(label,ok,detail){const card=document.createElement('article');card.className='health-check '+(ok?'status-ok':'status-fail');const head=document.createElement('div'),name=document.createElement('strong'),state=document.createElement('span'),text=document.createElement('p');name.textContent=label;state.className='health-status';state.textContent=ok?'سالم':'پشتیبانی نمی‌شود';text.textContent=detail;head.append(name,state);card.append(head,text);browserBox.append(card);return ok}
function checkBrowser(){browserBox.replaceChildren();let passed=0;passed+=browserCheck('جاوااسکریپت',true,'اسکریپت آزمون در مرورگر اجرا شد.')?1:0;passed+=browserCheck('Fetch API',typeof window.fetch==='function','برای بررسی GET و درخواست‌های Ajax استفاده می‌شود.')?1:0;passed+=browserCheck('FormData',typeof window.FormData==='function','برای ارسال فرم‌ها و بارگذاری فایل‌ها لازم است.')?1:0;passed+=browserCheck('URL API',typeof window.URL==='function','برای ساخت نشانی‌ها و مسیرهای درخواست لازم است.')?1:0;passed+=browserCheck('DOM و رویدادها',!!(document.querySelector&&document.addEventListener),'برای تعامل با فرم‌ها و رابط کاربری لازم است.')?1:0;passed+=browserCheck('اعتبارسنجی HTML فرم',!!(document.createElement('input').checkValidity),'برای نمایش خطاهای پایهٔ فیلدهای اجباری و الگوها استفاده می‌شود.')?1:0;total.textContent=new Intl.NumberFormat('fa-IR').format(passed)+' / ۶';return passed}
async function probe(row){const cell=row.querySelector('[data-probe-result]');const pill=document.createElement('span');pill.className='health-status status-pending';pill.textContent='در حال بررسی';cell.replaceChildren(pill);try{const response=await fetch(row.dataset.url,{method:'GET',credentials:'same-origin',cache:'no-store',headers:{'Accept':'text/html','X-Requested-With':'XMLHttpRequest'}});const required=row.dataset.requiredRole;const redirectedToLogin=/\/login(?:\?|$)/.test(new URL(response.url).pathname);let ok=response.ok;let detail='HTTP '+response.status;if(required!=='public'&&required!==currentRole){ok=response.status===401||response.status===403||redirectedToLogin;detail=ok?'کنترل نقش فعال است؛ نشست فعلی مجاز نیست.':'این پنل به نقش دیگری تعلق دارد اما پاسخ مجاز دریافت شد.'}else if(redirectedToLogin){ok=false;detail='به صفحهٔ ورود هدایت شد.'}pill.className='health-status '+(ok?'status-ok':'status-fail');pill.textContent=ok?'پاسخ مناسب':'HTTP '+response.status;pillTitle(pill,detail);}catch(error){pill.className='health-status status-fail';pill.textContent='خطای شبکه';pill.title=String(error&&error.message||error)}}
function pillTitle(node,value){node.title=value}
async function run(){checkBrowser();progress.className='health-status status-pending';progress.textContent='در حال بررسی';await Promise.all(rows.map(row=>row.dataset.registered==='1'?probe(row):Promise.resolve()));const failures=rows.filter(row=>row.dataset.registered!=='1'||row.querySelector('[data-probe-result] .status-fail')).length;progress.className='health-status '+(failures?'status-fail':'status-ok');progress.textContent=failures?failures+' مسیر نیازمند بررسی':'بررسی نشانی‌ها پایان یافت';}
document.getElementById('health-run').addEventListener('click',run);document.querySelectorAll('.health-probe').forEach(button=>button.addEventListener('click',()=>probe(button.closest('[data-health-route]'))));run();})();
</script>
@endsection
