@extends('layouts.srm',['title'=>'فیلدهای فرم پروژه'])
@section('content')
<div class="admin-stack">
    <section class="card">
        <h2>افزودن فیلد به {{ $form->name }}</h2>
        <p class="muted">متن راهنما و placeholder اختیاری‌اند. برای فیلدهای انتخابی، هر گزینه را در یک خط بنویسید.</p>
        <form method="post" action="{{ route('admin.project-forms.fields.save',$form->id) }}" class="grid">
            @csrf
            <label class="field">عنوان فیلد<input name="label" value="{{ old('label') }}" required></label>
            <label class="field">کلید انگلیسی<input name="field_key" value="{{ old('field_key') }}" pattern="[A-Za-z0-9_-]+" required><small class="muted">مثال: customer_phone</small></label>
            <label class="field">نوع فیلد
                <select name="type" id="newFieldType">
                    @foreach(['text'=>'متن کوتاه','textarea'=>'متن بلند','tel'=>'شماره تلفن (فقط عدد)','email'=>'ایمیل','count'=>'تعداد (عدد صحیح)','video'=>'ویدیو MP4','image'=>'تصویر JPG یا PNG','document'=>'سند PDF یا ZIP','radio'=>'انتخاب تکی (رادیویی)','checkbox'=>'انتخاب چندگانه (چک‌باکس)','jalali_date'=>'تاریخ شمسی','time'=>'ساعت'] as $key=>$label)<option value="{{ $key }}" @selected(old('type')===$key)>{{ $label }}</option>@endforeach
                </select>
            </label>
            <label class="field field-choices" hidden>گزینه‌ها<textarea name="options" rows="5" placeholder="هر گزینه در یک خط"></textarea></label>
            <label class="field">متن راهنما<textarea name="help_text" rows="2" maxlength="500" placeholder="راهنمایی که زیر فیلد به نماینده نمایش داده می‌شود"></textarea></label>
            <label class="field">متن نمونه داخل فیلد<input name="placeholder" maxlength="190"></label>
            <label class="field">ترتیب نمایش<input type="number" name="sort_order" min="0" value="{{ old('sort_order',0) }}"></label>
            <label class="field"><input type="checkbox" name="required" value="1" @checked(old('required'))> این فیلد الزامی است</label>
            <input type="hidden" name="enabled" value="1">
            <div class="admin-form-actions"><button class="btn" type="submit">افزودن فیلد</button></div>
        </form>
    </section>

    <section class="card">
        <h2>فیلدهای فرم</h2>
        @forelse($fields as $field)
            @php
                $meta=json_decode((string)$field->options,true)??[];
                $choices=array_is_list($meta)?$meta:($meta['choices']??[]);
                $helpText=is_array($meta)?($meta['help_text']??''):'';
                $placeholder=is_array($meta)?($meta['placeholder']??''):'';
                $choicesText=implode("\n",array_map(fn($choice)=>is_array($choice)?($choice['label']??$choice['value']??''):$choice,is_array($choices)?$choices:[]));
                $typeLabels=['text'=>'متن کوتاه','textarea'=>'متن بلند','tel'=>'شماره تلفن','email'=>'ایمیل','count'=>'تعداد','number'=>'عدد','video'=>'ویدیو MP4','image'=>'تصویر JPG/PNG','document'=>'سند PDF/ZIP','radio'=>'انتخاب تکی','checkbox'=>'انتخاب چندگانه','jalali_date'=>'تاریخ شمسی','time'=>'ساعت','select'=>'فهرست','date'=>'تاریخ شمسی (فیلد قدیمی)','url'=>'پیوند','file'=>'فایل','stage'=>'مرحله'];
            @endphp
            <details class="card" style="margin:12px 0;padding:14px">
                <summary style="cursor:pointer"><strong>{{ $field->label }}</strong> <span class="tag">{{ $typeLabels[$field->type]??$field->type }}</span> <span class="muted">{{ $field->required?'الزامی':'اختیاری' }} · کلید: {{ $field->field_key }}</span></summary>
                <form method="post" action="{{ route('admin.project-forms.fields.update',[$form->id,$field->id]) }}" class="grid" style="margin-top:12px">
                    @csrf @method('PUT')
                    <label class="field">عنوان فیلد<input name="label" value="{{ $field->label }}" required></label>
                    <label class="field">کلید انگلیسی<input name="field_key" value="{{ $field->field_key }}" pattern="[A-Za-z0-9_-]+" required></label>
                    <label class="field">نوع فیلد
                        <select name="type">@foreach($typeLabels as $key=>$label)<option value="{{ $key }}" @selected($field->type===$key)>{{ $label }}</option>@endforeach</select>
                    </label>
                    <label class="field">گزینه‌ها<textarea name="options" rows="4" placeholder="هر گزینه در یک خط">{{ $choicesText }}</textarea></label>
                    <label class="field">متن راهنما<textarea name="help_text" rows="2" maxlength="500">{{ $helpText }}</textarea></label>
                    <label class="field">متن نمونه داخل فیلد<input name="placeholder" maxlength="190" value="{{ $placeholder }}"></label>
                    <label class="field">ترتیب نمایش<input type="number" name="sort_order" min="0" value="{{ $field->sort_order }}"></label>
                    <label class="field"><input type="checkbox" name="required" value="1" @checked($field->required)> الزامی</label>
                    <label class="field"><input type="checkbox" name="enabled" value="1" @checked($field->enabled)> نمایش در فرم نماینده</label>
                    <div class="admin-form-actions"><button class="btn" type="submit">ذخیرهٔ تغییرات</button></div>
                </form>
                <form method="post" action="{{ route('admin.project-forms.fields.delete',[$form->id,$field->id]) }}" onsubmit="return confirm('این فیلد حذف شود؟')">@csrf @method('DELETE')<button class="btn danger" type="submit">حذف فیلد</button></form>
            </details>
        @empty
            <p class="muted">هنوز فیلدی به فرم اضافه نشده است.</p>
        @endforelse
    </section>
</div>
<style>.field-choices[hidden]{display:none!important}</style>
<script>
(function(){var type=document.getElementById('newFieldType');var options=document.querySelector('.field-choices');function toggle(){if(options)options.hidden=!['radio','checkbox','select'].includes(type.value)}if(type){type.addEventListener('change',toggle);toggle();}})();
</script>
@endsection
