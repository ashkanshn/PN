@extends('layouts.srm',['title'=>'بازخورد و پشتیبانی'])
@section('content')
@php
    $statusLabels=['open'=>'باز','closed'=>'بسته','pending'=>'در انتظار'];
@endphp
<section class="card">
    <div class="row spread"><div><h2>درخواست‌های نمایندگان</h2><p class="muted">پیام‌های ارسالی نمایندگان را بررسی کنید، پاسخ دهید یا وضعیت گفتگو را تغییر دهید.</p></div><span class="tag">{{ number_format($rows->total()) }} درخواست</span></div>
    <div class="table-wrap"><table><thead><tr><th>موضوع</th><th>نماینده</th><th>وضعیت</th><th>آخرین به‌روزرسانی</th><th>گفتگو</th></tr></thead><tbody>
    @forelse($rows as $ticket)
        <tr><td>{{ $ticket->subject }}</td><td>{{ $ticket->representative_name }}<br><small class="muted" dir="ltr">{{ $ticket->mobile }}</small></td><td><span class="tag">{{ $statusLabels[$ticket->status]??$ticket->status }}</span></td><td>{{ $ticket->updated_at }}</td><td><a class="btn alt" href="{{ route($routePrefix.'.feedback.show',$ticket->id) }}">مشاهده و پاسخ</a></td></tr>
    @empty
        <tr><td colspan="5">هنوز درخواستی ارسال نشده است.</td></tr>
    @endforelse
    </tbody></table></div>
    <div class="pagination">{{ $rows->links() }}</div>
</section>
@endsection
