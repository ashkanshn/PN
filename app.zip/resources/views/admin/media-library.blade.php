@extends('layouts.srm',['title'=>'رسانه مدیریت'])
@section('content')
<div class="admin-stack">
    <section class="card"><div class="admin-section-heading"><div><h2>افزودن فایل به کتابخانه مدیریت</h2><p>این فایل‌ها از رسانه‌های بارگذاری‌شده توسط نمایندگان جدا نگهداری می‌شوند.</p></div></div><form method="post" enctype="multipart/form-data" action="{{ route('admin.media-library.upload') }}" class="row">@csrf<label class="field">انتخاب چند فایل<input type="file" name="files[]" multiple required accept=".jpg,.jpeg,.png,.gif,.webp,.mp4,.webm,.pdf,.zip,.doc,.docx,.xls,.xlsx"></label><button class="btn" type="submit">بارگذاری رسانه</button></form><small class="muted">حداکثر حجم هر فایل ۵۰ مگابایت است.</small></section>
    <section class="card"><div class="row spread"><div><h2>کتابخانه رسانه مدیریت</h2><p class="muted">فایل‌های ادمین در این بخش نمایش داده می‌شوند.</p></div><span class="tag">{{ number_format($rows->total()) }} فایل</span></div><div class="admin-media-grid">
        @forelse($rows as $media)<article class="admin-media-card">
            @if(str_starts_with($media->mime_type,'image/'))<a href="{{ route('admin.media-library.preview',$media->id) }}" target="_blank"><img src="{{ route('admin.media-library.preview',$media->id) }}" alt="{{ $media->original_name }}"></a>
            @elseif(str_starts_with($media->mime_type,'video/'))<video controls preload="metadata" src="{{ route('admin.media-library.preview',$media->id) }}"></video>
            @else<div class="admin-media-file-icon">{{ strtoupper(pathinfo($media->original_name,PATHINFO_EXTENSION)) }}</div>@endif
            <div class="admin-media-meta"><strong title="{{ $media->original_name }}">{{ $media->original_name }}</strong><small>محل استفاده: {{ $media->source_title }}</small><small>{{ number_format($media->file_size/1024,1) }} KB · {{ $media->created_at }}</small></div>
            <div class="row"><a class="btn alt" href="{{ route('admin.media-library.download',$media->id) }}" download>دانلود</a><form method="post" action="{{ route('admin.media-library.delete',$media->id) }}" onsubmit="return confirm('این فایل حذف شود؟')">@csrf @method('DELETE')<button class="btn danger" type="submit">حذف</button></form></div>
        </article>@empty<div class="card">هنوز فایلی در کتابخانه بارگذاری نشده است.</div>@endforelse
    </div><div class="pagination">{{ $rows->links() }}</div></section>
</div>
@endsection
