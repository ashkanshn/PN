@extends('layouts.srm',['title'=>'رسانه نمایندگان'])
@section('content')
@php($routePrefix=auth()->user()->role==='admin_staff'?'staff':'admin')
<section class="card"><div class="row spread"><div><h2>کتابخانه رسانه نمایندگان</h2><p class="muted">فایل‌هایی که نمایندگان در پرونده‌هایشان بارگذاری کرده‌اند.</p></div><span class="tag">{{ number_format($rows->total()) }} فایل</span></div>
    <form id="representativeMediaBulkForm" method="post" action="{{ route($routePrefix.'.representative-media.bulk-delete') }}" onsubmit="return confirm('رسانه‌های انتخاب‌شده حذف شوند؟')">@csrf<div class="admin-form-actions"><button class="btn danger" type="submit">حذف موارد انتخاب‌شده</button><label><input type="checkbox" id="selectAllRepresentativeMedia"> انتخاب همه این صفحه</label></div></form>
    <div class="admin-media-grid">
        @forelse($rows as $media)<article class="admin-media-card representative-media-card"><label class="representative-media-select"><input type="checkbox" name="ids[]" value="{{ $media->id }}" form="representativeMediaBulkForm" class="representative-media-check"> انتخاب</label>
            @if(str_starts_with($media->mime_type,'image/'))<a href="{{ route($routePrefix.'.representative-media.preview',$media->id) }}" target="_blank"><img src="{{ route($routePrefix.'.representative-media.preview',$media->id) }}" alt="{{ $media->original_name }}"></a>
            @elseif(str_starts_with($media->mime_type,'video/'))<video controls preload="metadata" src="{{ route($routePrefix.'.representative-media.preview',$media->id) }}"></video>
            @else<div class="admin-media-file-icon">{{ strtoupper(pathinfo($media->original_name,PATHINFO_EXTENSION)) }}</div>@endif
            <div class="admin-media-meta"><strong title="{{ $media->original_name }}">{{ $media->original_name }}</strong><small>{{ $media->representative_name }} · {{ $media->project_title??'بدون پروژه' }}</small><small>{{ number_format($media->file_size/1024,1) }} KB · {{ $media->created_at }}</small></div>
            <div class="row"><a class="btn alt" href="{{ route($routePrefix.'.representative-media.download',$media->id) }}" download>دانلود</a><form method="post" action="{{ route($routePrefix.'.representative-media.delete',$media->id) }}" onsubmit="return confirm('این رسانه حذف شود؟')">@csrf @method('DELETE')<button class="btn danger" type="submit">حذف</button></form></div>
        </article>@empty<div class="card">رسانه‌ای از سوی نمایندگان بارگذاری نشده است.</div>@endforelse
    </div><div class="pagination">{{ $rows->links() }}</div>
</section>
<script>document.getElementById('selectAllRepresentativeMedia')?.addEventListener('change',function(){document.querySelectorAll('.representative-media-check').forEach(function(box){box.checked=this.checked;},this);});</script>
@endsection
